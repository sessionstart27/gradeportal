<?php    
    include('config.php');

     $msg = "";

    if(isset($_POST['submit'])){
        $con = new mysqli('localhost', 'u588883585_iistph', 'Iist6801', 'u588883585_grading');

		$user = $con->real_escape_string($_POST['user']);
		$password = $con->real_escape_string($_POST['pass']);
        
        $sql = $con->query("SELECT * FROM userdata WHERE username='$user'");
        
        if ($sql->num_rows > 0) {
		    $data = $sql->fetch_array();
		    if (password_verify($password, $data['password'])) {
		        $msg = "You have been logged IN!";
                $_SESSION['level'] = $data['level'];
                $_SESSION['id'] = $data['username'];
                $_SESSION['name'] = $data['firstname'].' '.$data['lastname'];
                header('location:'.$data['level'].'');
            } else
			    $msg = "Please check your inputs not match!";
			    header('location:index.php?login=0');
        } else
            $msg = "Please check your inputs wala!";
            header('location:index.php?login=0');
	}

    if(isset($_SESSION['level'])){
        header('location:'.$_SESSION['level'].'');   
    }
   

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="image/ii.png" sizes="16x16" type="images/png">

    <title>IIST Grade Portal</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <!-- Custom styles for this template -->
    <link href="jumbotron.css" rel="stylesheet">
<style>

    .events-sect{
	max-width:100%; 
	padding:40px;
	background-color:#ffffff;
	color:#1d1d1d;
    background-image: url("image/bg2.png");
	width:100%;height:100%;
    background-repeat: no-repeat;
    background-size: cover;
}
    .global-container{
	max-width:95%;
	margin:0 auto;
	height:auto;
}
    .event-wrapper{
    max-width:100%;
    display:flex;
}
    .event-wrapper::-webkit-scrollbar {
    cursor: pointer;
    height: 8px;
    background-color: #cccc;
    border-radius: 100px;
    /* border: 1px solid #bbbb; */
}
    .events-content img{
	width:300px;
}
    /* scroll bar for the slide panels*/
    ::-webkit-scrollbar-thumb {
    background-color: whitesmoke;
    border-radius: 10px;
    border: 1px solid lightgray;
}

    /* Track */
::-webkit-scrollbar-track {
  border-radius: 10px;
}

* {
    box-sizing: border-box;
}
.events-content{
	flex: 0 0 auto;
    cursor: grab; 
	box-shadow:2px 1px 10px 1px #aaaaaa;
	width:300px;
    margin:20px;
    box-sizing:border;
    color:#1d1d1d;
}
.txt-cont {
    background-color: #ffffff;
}
    element.style {
    max-width: 100%;
    display: inline-block;
    padding: 20px;
    text-align: center;
    margin: 0 auto;
}
@media (max-width:424px){
    .global-container{
	max-width:100%;
	height:auto;
}   .events-sect{
	max-width:100%; 
	padding:20px;

}}
@media (max-width:375px){
    footer .homefooter p{
    font-size:7px;
    padding:2px; }}
@media only screen and (max-width:768px){
        h1{
           text-align:center;color:#1d1d1d;font-size:16px;
        }
       
    }
     @media only screen and (min-width:1024px){
        h1{
          text-align:center;padding:40px;color:#1d1d1d;font-size:30px;
        }
       
    }
      </style>
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button><img src="image/banner.png" height="49px" width="350px" style="margin-left:15px;float:left;" class="logo">
            <img src="image/banner2.png" class="logo1">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <form class="navbar-form navbar-right" role="form" action="index.php" method="POST">
            <div class="form-group">
                <?php if(isset($_GET['login'])): ?>
                    <label class="text-danger">Invalid User ID/Password</label>&nbsp;
                <?php endif; ?>
            </div>
            <div class="form-group">
              <input type="text" placeholder="User ID" class="form-control" name="user" autocomplete="off">
            </div>
            <div class="form-group">
              <input type="password" placeholder="Password" class="form-control" name="pass">
            </div>
            <button type="submit" class="btn btn-success" name="submit">Sign in</button>
          </form>
        </div><!--/.navbar-collapse -->
      </div>
    </nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
       
      </div>
    </div>
      <div class="jumbotron1">
      <div class="container">
        
      </div>
    </div>
    <section class="events-sect" id="eventsect">
			<div class="global-container" id="adjusth1">
				<h1><b>Learn More About the IIST Grade Portal </b></h1>
				<div class="event-wrapper" style="align-items:center;overflow-x:scroll;" >
					<br>
					<div class="events-content">
						<img src="image/2.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>IIST Grade Portal</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">An online grading system that will help students, teachers and the registrar in managing student grades and information. Users login credentials will be provided upon request in the registrar's office.<br><a href="event1.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
					
						<div class="events-content">
						<img src="image/3.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Teacher Access</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">Teachers will be able to upload and manage student grades by logging in to their account. Teachers can also view their subject load and monitor students performance online using the grade portal.<br><a href="event3.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
					
						<div class="events-content">
						<img src="image/4.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Student Access</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">IIST students may now access their grades without doing the hassle of going to school to inquire. With IIST Grade Portal they can login to their account and keep track on their grades in any devices online. <a href="event4.html" style="text-decoration: none;color: blue"></a></article>
						</div>
					</div>
										<div class="events-content">
						<img src="image/5.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Contacts</b></article>
							<article style="text-align:left;display:inline-block;max-width:100%;"><ul style="list-style-type:none;"><p><b>Phone:</b>  (046)471 - 2624</p>

                                <p><b>E-mail:</b>  iistedu2020@gmail.com</p>
                                
                                <p><b>Address:</b> Nueño Ave. Imus, Cavite</p><br><a href="event2.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
				</div>
			</div>
		</section>

        
    

      <footer style="background-color:#017;">
          <div  style="background-color:#017;padding:3px;">
        <p class="center" style="color:white;"><b>Copyright &copy; 2021. All Rights Reserved Imus Institute of Science and Technology</b></p>
        </div>
      </footer>
    <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
