<?php
     $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
     $val = $_GET['value'];

    $val_M = mysqli_real_escape_string($con,$val);
    
    $sql="SELECT teachid, email FROM teacher WHERE teachid='$val_M'";
    $result=mysqli_query($con, $sql);
    
    if(mysqli_num_rows($result)>0) {
        
        while($rows = mysqli_fetch_assoc($result)){
            echo "<p style='font-size:12px;font-weight:bold;'>Email: ".$rows['email']."</p>";
            
        }
    
    
       
    }
?>