<?php
    include('include/header.php');
    include('include/sidebar.php');
    $username = $_GET['username'];
    $name = $_GET['name'];
    $user_id = $_SESSION['name'];
    $msg = "";
    
  // This will be called once form is submitted
    if (isset($_POST["updateuser"]))
    {
        // Get all input fields
        $new_password = $con->real_escape_string($_POST['new']);
        $confirm_password = $con->real_escape_string($_POST['confirm']);
 
            // Check if password is same
            if ($new_password == $confirm_password)
            {
                // Change password
                $sql = "UPDATE userdata SET password = '" . password_hash($new_password, PASSWORD_DEFAULT) . "' WHERE username = '" . $username. "'";
                mysqli_query($con, $sql);  
                
                $act = "Updated password with UserID: $username";
                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $user_id.' changed '.$name.' password.';
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
                
                $msg = "<div class='alert alert-success'>
                            <strong>Updated password for user: ".$name." done!</strong>
                        </div>";
            
            }
            else
            {
                $msg = "<div class='alert alert-danger'>
                            <strong>The inserted password do not match!! Please try again.</strong>
                        </div>";
                
            }
             
       
    }
    
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">
                    <i class= "fa fa-cog fa-spin"></i> Settings <small>Update User Password</small>
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <i class="fa fa-users"></i> <a href="users.php">Users</a>
                    </li>
                    
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row" style="width:70%;margin:auto;">
            <div class="col-lg-12" style="width:70%;margin:auto;">
                <?php if ($msg != "") echo $msg; ?>
                <div class="alert alert-info">
                    <table>
                        <tr width="100"><strong>UPDATE PASSWORD FOR: </strong><br></tr>
                        <tr style="width:20px;"> <br></tr>
                        <tr>
                            <td width="100"><b>User ID:</b></td>                            
                            <td><i><?php echo $username; ?></i></td>
                        </tr>
                        <tr>
                            <td width="100"><b>Name:</b></td>                            
                            <td><i><?php echo $_GET['name']; ?></i></td>
                        </tr>
                    </table>     
                </div>
                <form action="" method="post">
                    <div class="form-group">
                        <input type="password" name="new" class="form-control" placeholder="New Password..." required>
                    </div>
                    <div class="form-group">
                        <input type="password" name="confirm" class="form-control" placeholder="Confirm Password..." required>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm" name="updateuser" style="float:right;">Update Password</button><br><br><br>
                </form>  
             </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');