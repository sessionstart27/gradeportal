<?php
include('PHPMailer/PHPMailerAutoload.php');
											
function Redirect_to($New_Location)
{header("Location:" . $New_Location);
    exit;
}

// call the contact() function if deadline1 is clicked
if (isset($_POST['deadline1'])) {
    contact();
}

function contact()
{
    if (isset($_POST["deadline1"])) {

        $name = $_GET["name"];
        $date = $_POST['prelim'];
        $status = $_POST['status'];
        $email = $_POST['email'];
        $access1 = $_POST['access_prelim'];
        
       
        $message = 'You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.';

        // Email Functionality

        date_default_timezone_set('Etc/UTC');

        $mail = new PHPMailer();

    	$mail->IsSMTP();
    	$mail->CharSet = 'UTF-8';
    
        $mail->Host       = "mail.smtp2go.com"; // SMTP server example
    	$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    	$mail->SMTPAuth   = true;                  // enable SMTP authentication
    	$mail->Port       = 2525;                    // set the SMTP port for the GMAIL server
    	$mail->Username   = "iistph"; 	// SMTP account username example
    	$mail->Password   = "Iist6801";        // SMTP account password example



        $mail->setFrom('schoolmail@iistph.com');
        $mail->addAddress($_POST['email']);

        // The subject of the message.
        $mail->Subject = 'Received Message From Admin ' . $name;

        $message = '<html><body>';

        $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

        $message .= "<tr style='background: #eee;'><td><strong>Access for:</strong> </td><td>" . strip_tags('Update Prelim Grades') . "</td></tr>";

        $message .= "<tr><td><strong>Access valid until:</strong> </td><td>" . strip_tags($date) . "</td></tr>";

        $message .= "<tr><td><strong>Message:</strong> </td><td>" . strip_tags('You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.') . "</td></tr>";

        $message .= "</table>";
        $message .= "</body></html>";

        $mail->Body = $message;

        $mail->isHTML(true);
        
        $result = $mail->Send();        // Send!  
        if ($result)
        {
            header('location:control.php?date='.$date.'&access1='.$access1.'&status='.$status.'');
        }
        else {
            echo "sending mail failed: " . $mail->ErrorInfo;
        }
        unset($mail);
        
       
    } //Ending of Submit Button If-Condition

}

// call the contact() function if deadline2 is clicked
if (isset($_POST['deadline2'])) {
    contact2();
}

function contact2()
{
    if (isset($_POST["deadline2"])) {

        $name = $_GET["name"];
        $date2 = $_POST['midterm'];
        $status2 = $_POST['status'];
        $email = $_POST['email'];
        $access2 = $_POST['access_midterm'];
        
       
        $message = 'You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.';

        // Email Functionality

        date_default_timezone_set('Etc/UTC');

        $mail = new PHPMailer();

    	$mail->IsSMTP();
    	$mail->CharSet = 'UTF-8';
    
        $mail->Host       = "mail.smtp2go.com"; // SMTP server example
    	$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    	$mail->SMTPAuth   = true;                  // enable SMTP authentication
    	$mail->Port       = 2525;                    // set the SMTP port for the GMAIL server
    	$mail->Username   = "iistph"; 	// SMTP account username example
    	$mail->Password   = "Iist6801";        // SMTP account password example



        $mail->setFrom('schoolmail@iistph.com');
        $mail->addAddress($_POST['email']);

        // The subject of the message.
        $mail->Subject = 'Received Message From Admin ' . $name;

        $message = '<html><body>';

        $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

        $message .= "<tr style='background: #eee;'><td><strong>Access for:</strong> </td><td>" . strip_tags('Update Midterm Grades') . "</td></tr>";

        $message .= "<tr><td><strong>Access valid until:</strong> </td><td>" . strip_tags($date2) . "</td></tr>";

        $message .= "<tr><td><strong>Message:</strong> </td><td>" . strip_tags('You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.') . "</td></tr>";

        $message .= "</table>";
        $message .= "</body></html>";

        $mail->Body = $message;

        $mail->isHTML(true);
        
        $result = $mail->Send();        // Send!  
        if ($result)
        {
            header('location:control.php?date2='.$date2.'&access2='.$access2.'&status2='.$status2.'');
        }
        else {
            echo "sending mail failed: " . $mail->ErrorInfo;
        }
        unset($mail);
        
       
    } //Ending of Submit Button If-Condition

}

// call the contact() function if deadline3 is clicked
if (isset($_POST['deadline3'])) {
    contact3();
}

function contact3()
{
    if (isset($_POST["deadline3"])) {

        $name = $_GET["name"];
        $date3 = $_POST['final'];
        $status3 = $_POST['status'];
        $email = $_POST['email'];
        $access3 = $_POST['access_final'];
        
       
        $message = 'You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.';

        // Email Functionality

        date_default_timezone_set('Etc/UTC');

        $mail = new PHPMailer();

    	$mail->IsSMTP();
    	$mail->CharSet = 'UTF-8';
    
        $mail->Host       = "mail.smtp2go.com"; // SMTP server example
    	$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    	$mail->SMTPAuth   = true;                  // enable SMTP authentication
    	$mail->Port       = 2525;                    // set the SMTP port for the GMAIL server
    	$mail->Username   = "iistph"; 	// SMTP account username example
    	$mail->Password   = "Iist6801";        // SMTP account password example



        $mail->setFrom('schoolmail@iistph.com');
        $mail->addAddress($_POST['email']);

        // The subject of the message.
        $mail->Subject = 'Received Message From Admin ' . $name;

        $message = '<html><body>';

        $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

        $message .= "<tr style='background: #eee;'><td><strong>Access for:</strong> </td><td>" . strip_tags('Update Final Grades') . "</td></tr>";

        $message .= "<tr><td><strong>Access valid until:</strong> </td><td>" . strip_tags($date3) . "</td></tr>";

        $message .= "<tr><td><strong>Message:</strong> </td><td>" . strip_tags('You may now access the update grade feature in our grade portal. You only have 1 day access. Make sure to check access validity.') . "</td></tr>";

        $message .= "</table>";
        $message .= "</body></html>";

        $mail->Body = $message;

        $mail->isHTML(true);
        
        $result = $mail->Send();        // Send!  
        if ($result)
        {
            header('location:control.php?date3='.$date3.'&access3='.$access3.'&status3='.$status3.'');
        }
        else {
            echo "sending mail failed: " . $mail->ErrorInfo;
        }
        unset($mail);
        
       
    } //Ending of Submit Button If-Condition

}
?>

