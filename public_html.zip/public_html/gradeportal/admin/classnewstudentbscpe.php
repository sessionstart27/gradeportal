<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/student_modelbscpe.php');
    include('data/class_model.php');
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $student = $student->getnewstudent($search);
    $studentsubject = $class->getstudentsubject();
    $classid = $_GET['classid'];
    
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select * from class where id=$classid");
    $rc = mysqli_fetch_array($rc);
    $subject = $rc['subject'];
    $semester = $rc['semester'];
    $teacher = $rc['teacher'];
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>CLASS STUDENTS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <?php if($semester=='1st Semester'){ ?>
                        <a href="class.php">Class Info</a>
                        <?php }else { ?>
                        <a href="class2.php">Class Info</a>
                        <?php }?>
                    </li>
                    <li class="active">
                        Class Students (Subject: <?php echo $subject; ?>)
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <form action="classnewstudentbscpe.php?classid=<?php echo $classid;?>" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search by UserID..." required autofocus>
                        <button type="submit" name="submitsearch" class="btn btn-success"><i class="fa fa-search"></i> Search</button> 
                        <a href="classstudent.php?classid=<?php echo $classid;?>" class="btn btn-primary">Master List</a>
                    </form>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">     
                <?php if($search){ ?>
                    
                        <table class="table table-striped">
                            <thead>
                                <tr class="alert-info">
                                    <th>Student ID</th>
                                    <th>Lastname</th>
                                    <th>Firstname</th>
                                    <th>Middlename</th>
                                    <th>Course</th>
                                    <th>Year</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_array($student)): ?>
                                <tr>
                                    <td><?php echo $row['studid']; ?></td>
                                    <td><?php echo $row['lastname']; ?></td>
                                    <td><?php echo $row['firstname']; ?></td>
                                    <td><?php echo $row['middlename']; ?></td>
                                    <td><?php echo $row['course']; ?></td>
                                    <td><?php echo $row['year']; ?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?dept=classnewstudentbscpe&studid=<?php echo $row['id']; ?>&classid=<?php echo $classid;?>&teacher=<?php echo $teacher;?>" method="post" enctype="multipart/form-data">
                                           <button type="submit" name="add2class"  class="btn btn-warning">Add to Class</button>
                                        </form></td>     
                                </tr>
                                <?php endwhile;?>
                                <?php if(mysqli_num_rows($student) < 1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                   
                <?php }else{ ?>
                        <?php if(isset($_GET['r'])): ?>
                            <?php if($_GET['r']=='success'){ ?>
                                <div class="alert alert-success">
                                    <strong>Student Added Successfully!</strong>
                                </div>
                            <?php }else if($_GET['r']=='duplicate'){ ?>
                                <div class="alert alert-warning">
                                    <strong>Student already on the list!</strong>
                                </div>
                            <?php } ?>
                        <?php endif;?>            
                        <table class="table table-striped">
                            <thead>
                                <tr class="alert-info">
                                    <th>Student ID</th>
                                    <th>Lastname</th>
                                    <th>Firstname</th>
                                    <th>Middlename</th>
                                    <th>Course</th>
                                    <th>Year</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_array($student)): ?>
                                <tr>
                                    <td><?php echo $row['studid']; ?></td>
                                    <td><?php echo $row['lastname']; ?></td>
                                    <td><?php echo $row['firstname']; ?></td>
                                    <td><?php echo $row['middlename']; ?></td>
                                    <td><?php echo $row['course']; ?></td>
                                    <td><?php echo $row['year']; ?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?dept=classnewstudentbscpe&studid=<?php echo $row['id']; ?>&classid=<?php echo $classid;?>&teacher=<?php echo $teacher;?>" method="post" enctype="multipart/form-data">
                                           <button type="submit" name="add2class"  class="btn btn-warning">Add to Class</button>
                                        </form>
                                        </td>     
                                </tr>
                                <?php endwhile;?>
                                <?php if(mysqli_num_rows($student) < 1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                    
                
                <?php } ?>
                    </div>
            </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');