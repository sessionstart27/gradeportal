<?php
     include('../config.php');
    include('data/student_modelbsa.php');
    
   if(isset($_POST['submitsearch'])){ 
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $student = $student->getstudent($search);
   }else{
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $student = $student->getstudentcourse($search);
   }
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">
    
    <title>Print Report</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        .wrapper {
            margin-top:40px !important;            
            border:0px solid #777;
            background:#fff;
            margin:0 auto;
            height: 100%;
            width: 92%;
            padding: 20px;
        }
        body {
            background:#ccc;  
        }
        img {
            max-height:150px;   
            max-width:500px;   
            margin-right:10px;
        }
        p{
            font-weight: bold;
            font-size: 16px;
        }
        @media print{
        #print,#search,#search1,#list{
            display:none;
        }
        }
         @page  
{ 
            size: auto;   /* auto is the initial value */ 

            /* this affects the margin in the printer settings */ 
            margin: 15mm 5mm 15mm 0mm;  
        }
        @page :first {
              margin-top: 0in; /*top margin for first page of paper*/
            }
        #print {
            width: 90px;
            height: 30px;
            font-size: 18px;
            background: green;
            border-radius: 4px;
            margin-left:8px;
            cursor:hand;
            color: white;
}
        .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
            border-top: none !important;   
        }
        
    </style>
    <script>
function printPage() {
    window.print();
}
</script>
</head>
<body>
    <div class="container wrapper">
        <div class="row">
            <div class="col-lg-12">
                
                <div class="text-center"> 
                    
                    <img src="../image/printlogo.png" height="60px;" width="440px">
                    <p style="font-size:14px;font-weight:lighter;">Nueno Ave., City of Imus</p>
                    <p  style="font-size:18px;">College of Accountancy <a href="printbsa.php" id="list">(Students List)</a></p>
                   
                    <p style="font-size:15px;">S.Y. <?php $year = date('Y'); ?><?php echo $year; ?>-<?php echo $year+1?></p>
                    <hr />
                    <form action="printbsa.php" method="post" style="float:left;" >
                        <div class="btn-group">
                        <input type="text" id="search" class="form-control" name="search" style="width:150px;" placeholder="Search Students...">
                        </div>
                        <button type="submit" id="search1" name="submitsearch" class="btn btn-success"><i class="fa fa-search"></i> Search</button> 
                        
                    </form><button type="submit" id="print" onclick="printPage()" style="float:right;margin-top:2px;margin-right:20px;"><i class="fa fa-print"></i>Print</button><br /><br />
                </div>               
            </div>
        </div> 
        
        
        
        <div class="row">
            <div class="col-lg-12">                

                <div class="">
                    <table class="table table-striped table-bordered">
                         <thead>
                            <tr>
                                <th>#</th>
                                <th>Student ID</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Middlename</th>
                                <th>Course</th>
                                <th>Year</th>
                                <th>Email</th>
                                <th>Contact No.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($student)): ?>                            
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><?php echo $row['studid'];?></td>
                                    <td><?php echo $row['lastname'];?></td>
                                    <td><?php echo $row['firstname'];?></td>
                                    <td><?php echo $row['middlename'];?></td>
                                    <td><?php echo $row['course'];?></td>
                                    <td><?php echo $row['year'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <td><?php echo $row['contact'];?></td>
                            <?php $c++; ?>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($student) < 1): ?>
                                <tr>
                                    <td colspan="7" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>        
            </div>
        </div>
        
        <br />
<br />
						<h5><strong>Prepared By:</strong></h5>	<br>
                        <h5 style="margin-top:-5px;margin-left:30px;"><i class="glyphicon glyphicon-user"></i> &ensp;<?php echo $_SESSION['name']; ?><br><br><?php echo date('F d, Y')?></h5>
                        
                       

        <br />
<br />
						
            
                        
    </div>
    
</body>

</html>