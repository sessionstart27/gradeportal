<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/teacher_model.php');
    
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $teacher = $teacher->getteacherlate($search);
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Late Submission of Grades </small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="grades.php">Grades Dashboard</a>
                    </li>
                    <li class="active">
                        <a href="latesub.php">Teacher's List</a>
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <a href="printlateteacher.php" target="_blank"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print List</button></a>  
                </div>
            </div>
        </div>
        <!--/.row -->
        <hr />   
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['r'])): ?>
                    <?php
                        $r = $_GET['r'];
                        if($r=='added'){
                            $class='success';   
                        }else if($r=='updated'){
                            $class='info';   
                        }else if($r=='deleted'){
                            $class='danger';   
                        }else if($r=='added an account'){
                            $class='success';   
                        }else{
                            $class='hide';
                        }
                    ?>
                    <div class="alert alert-<?php echo $class?> <?php echo $classs; ?>">
                        <strong>Teacher: <?php echo $_GET['n']; ?> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr class="alert-info">
                                <th>No.</th>
                                <th>Teacher ID</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Middlename</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($teacher)): ?>                            
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><?php echo $row['teachid'];?></td>
                                    <td><?php echo $row['lastname'];?></td>
                                    <td><?php echo $row['firstname'];?></td>
                                    <td><?php echo $row['middlename'];?></td>
                                    <td class="text-center">
                                        <a href="lateteachersub.php?id=<?php echo $row['teacher'];?>" title="Update Subject">View Subject</a> &nbsp;
                                </tr>
                            <?php $c++; ?>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($teacher) < 1): ?>
                                <tr>
                                    <td colspan="6" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/modal.php'); ?>
<?php include('include/footer.php'); ?>