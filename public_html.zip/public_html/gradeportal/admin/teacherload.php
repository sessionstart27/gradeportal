<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/teacher_model.php');
    include('data/data_model.php');
    
    $id = $_GET['id'];
    $teacher = $teacher->getteacherbyid($id);
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>TEACHER'S LOAD</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="teacher.php">Teachers</a>
                    </li>
                    <li class="active">
                        Teacher's Load
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php while($row = mysqli_fetch_array($teacher)): ?>
                <h4>Teacher ID : <?php echo $row['teachid']; ?></h4>
                <h4>Name : <?php echo $row['firstname'].' '.$row['lastname']; ?></h4>
                <?php endwhile; ?>
                <hr />
                   <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Semester</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Semester</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr class="alert alert-info">
                                <th>Subject</th>
                                <th class="text-center">Students</th>
                                <th class="text-center">Year Level Offered</th>
                                <th class="text-center">Semester</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                         mysqli_select_db($con,'u588883585_grading');
                        $r1 = mysqli_query($con,"select * from class where teacher=$id and semester='1st Semester' order by subject asc");
                        while($row = mysqli_fetch_array($r1)):?>
                            <tr>
                                <td><?php echo $row['subject']?></td>            
                                <td class="text-center"><a href="classstudent.php?classid=<?php echo $row['id']?>" target="_blank">View</a></td>     
                                <td class="text-center"><?php echo $row['year']?></td>
                                <td class="text-center"><?php echo $row['semester']?></td>

                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($r1) < 1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-danger"><strong>*** Empty!! ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                            
                            </div>
                        </div>
                  
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                 <thead>
                                <tr class="alert alert-info">
                                <th>Subject</th>
                                <th class="text-center">Students</th>
                                <th class="text-center">Year Level Offered</th>
                                <th class="text-center">Semester</th>
                                
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                            <?php
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                         mysqli_select_db($con,'u588883585_grading');
                        $r2 = mysqli_query($con,"select * from class where teacher=$id and semester='2nd Semester' order by subject asc");
                        while($row = mysqli_fetch_array($r2)):?>
                            <tr>
                                <td><?php echo $row['subject']?></td>            
                                <td class="text-center"><a href="classstudent.php?classid=<?php echo $row['id']?>" target="_blank">View</a></td>     
                                <td class="text-center"><?php echo $row['year']?></td>
                                <td class="text-center"><?php echo $row['semester']?></td>
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($r2) < 1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-danger"><strong>*** Empty!! ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                       
                            </div>
                            
                        </div>
             
      </div>
                
            
            </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');