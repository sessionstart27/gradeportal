<?php
     include('../config.php');
    include('data/student_modelbscs.php');
    include('data/data_model.php');
    
    $id = $_GET['id'];
    $student = $student->getstudentbyid($id);
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">
    
    <title>Print Report</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        .wrapper {
            margin-top:40px !important;            
            border:0px solid #777;
            background:#fff;
            margin:0 auto;
            height: 100%;
            width: 92%;
            padding: 20px;
        }
        body {
            background:#ccc;  
        }
        img {
            max-height:150px;   
            max-width:500px;   
            margin-right:10px;
        }
        p{
            font-weight: bold;
            font-size: 16px;
        }
        @media print{
        #print,#search,#search1,#list{
            display:none;
        }
        }
         @page  
{ 
            size: auto;   /* auto is the initial value */ 

            /* this affects the margin in the printer settings */ 
            margin: 15mm 5mm 15mm 0mm;  
        }
        @page :first {
              margin-top: 0in; /*top margin for first page of paper*/
            }
        #print {
            width: 90px;
            height: 30px;
            font-size: 18px;
            background: green;
            border-radius: 4px;
            margin-left:8px;
            cursor:hand;
            color: white;
}
        .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
            border-top: none !important;   
        }
        
    </style>
    <script>
function printPage() {
    window.print();
}
</script>
</head>
<body>
    <div class="container wrapper">
        <div class="row">
            <div class="col-lg-12">
                
                <div class="text-center"> 
                    
                    <img src="../image/printlogo.png" height="60px;" width="440px">
                    <p style="font-size:14px;font-weight:lighter;">Nueno Ave., City of Imus</p>
                    <p  style="font-size:18px;">COPY OF GRADES</p>
                    <p  style="font-size:16px;">College of Computer Studies</p>
                    <?php while($row = mysqli_fetch_array($student)): ?>
                    <p style="font-size:15px;">S.Y. <?php echo $row['school_year']; ?></p>

                    
                    <hr />
                    <button type="submit" id="print" onclick="printPage()" style="float:right;margin-top:2px;margin-right:20px;"><i class="fa fa-print"></i>Print</button>
                </div>               
            </div>
        </div> 
        
        
        
       <div class="row">
            <div class="col-lg-12">
              
                <h5><b>Student ID : <?php echo $row['studid']; ?></b></h5>
                <h5><b>Name : <?php echo $row['firstname'].' '.$row['lastname']; ?></b></h5>
                <?php endwhile; ?>
                
                <hr />
    <!-- stud grades -->
<?php
    include('data/grade.php');
    $firstsem = $grade->getsubject('1st Semester');    
    $secondsem = $grade->getsubject('2nd Semester');    
    
?>
   
               
               
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <h5><b>First Semester</b></h5>
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert alert-info">
                                    <th class="text-center">Subject Code</th>
                                    <th class="text-center">Subject Title</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                   
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($firstsem)): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td class="text-center"><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                        $remarks = 'PASSED';
                                        $class = 'text-success';
                                    }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }else{
                                        $remarks = 'INCOMPLETE';
                                        $class = 'text-danger';  
                                    }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                                
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($firstsem) < 1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                            
                        </div>
                  
                    <div class="tab-pane active" id="data2">
                        <br /><h5><b>Second Semester</b></h5>
                            <table class="table table-striped">
                                 <thead>
                                    <tr class="alert alert-info">
                                    <th class="text-center">Subject Code</th>
                                    <th class="text-center">Subject Title</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                    
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($secondsem)): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td class="text-center"><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                        $remarks = 'PASSED';
                                        $class = 'text-success';
                                    }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }else{
                                        $remarks = 'INCOMPLETE';
                                        $class = 'text-danger';  
                                    }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                                
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($secondsem) < 1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table> 
                        </div>
             
      </div>
           
<br />
<br />
						<h5><strong>Prepared By:</strong></h5>	<br>
                        <h5 style="margin-top:-5px;margin-left:30px;"><i class="glyphicon glyphicon-user"></i> &ensp;<?php echo $_SESSION['name']; ?><br><br><?php echo date('F d, Y')?></h5>
                        
                       

        <br />
<br />
						
            
                   
    </div>
        </div>
    </div>
    
</body>

</html>