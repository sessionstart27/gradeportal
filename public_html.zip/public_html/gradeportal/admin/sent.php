<?php
    include('PHPMailer/PHPMailerAutoload.php');

function Redirect_to($New_Location)
{header("Location:" . $New_Location);
    exit;
}

// call the contact() function if contact_btn is clicked
if (isset($_POST['contact_btn'])) {
    contact();
}

function contact()
{
    if (isset($_POST["contact_btn"])) {

        $name = $_GET["name"];
        $email = $_POST["email"];
        $message = $_POST["message"];

        // Email Functionality

        date_default_timezone_set('Etc/UTC');

        $mail = new PHPMailer();

    	$mail->IsSMTP();
    	$mail->CharSet = 'UTF-8';
    
        $mail->Host       = "mail.smtp2go.com"; // SMTP server example
    	$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    	$mail->SMTPAuth   = true;                  // enable SMTP authentication
    	$mail->Port       = 2525;                    // set the SMTP port for the GMAIL server
    	$mail->Username   = "iistph"; 	// SMTP account username example
    	$mail->Password   = "Iist6801";        // SMTP account password example



        $mail->setFrom('schoolmail@iistph.com');
        $mail->addAddress($_POST['email']);

        // The subject of the message.
        $mail->Subject = 'Received Message From Admin ' . $name;

        $message = '<html><body>';

        $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

        $message .= "<tr style='background: #eee;'><td><strong>From:</strong> </td><td>" . strip_tags($name) . "</td></tr>";

        $message .= "<tr><td><strong>Message</strong> </td><td>" . strip_tags($_POST['message']) . "</td></tr>";

        $message .= "</table>";
        $message .= "</body></html>";

        $mail->Body = $message;

        $mail->isHTML(true);
        
        $result = $mail->Send();        // Send!  
        if ($result)
        {
            header("Location:mailer.php?status=Email sent!");
        }
        else {
            echo "sending mail failed: " . $mail->ErrorInfo;
        }
        unset($mail);
        
       
    } //Ending of Submit Button If-Condition

}

?>