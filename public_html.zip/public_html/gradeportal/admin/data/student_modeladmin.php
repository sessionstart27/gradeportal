<?php
    $student = new Datastudent();
    if(isset($_GET['q'])){
        $function = $_GET['q'];
        $student->$function();
    }
    
    class Datastudent {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
       //incomplete students
        function getstudentbyclass($classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select student.id,student.studid,student.firstname,student.lastname,student.course,studentsubject.classid,studentsubject.prelim,studentsubject.midterm,studentsubject.final from studentsubject INNER JOIN student ON studentsubject.studid = student.id where studentsubject.classid='$classid' and (studentsubject.total='' or studentsubject.prelim='' or studentsubject.midterm='' or studentsubject.final='') order by student.lastname asc"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
        }
        
        //update students
        function getstudentbyclassupdate($classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select student.id,student.studid,student.firstname,student.lastname,student.course,student.year,studentsubject.classid,studentsubject.prelim,studentsubject.midterm,studentsubject.final from studentsubject INNER JOIN student ON studentsubject.studid = student.id where studentsubject.classid='$classid' order by student.lastname asc"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
        }
        //failed students
        function getstudentbyclassfail($classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select student.id,student.studid,student.firstname,student.lastname,student.course,studentsubject.classid,studentsubject.prelim,studentsubject.midterm,studentsubject.final from studentsubject INNER JOIN student ON studentsubject.studid = student.id where studentsubject.classid='$classid' and (studentsubject.total > 0 and studentsubject.total < 75) order by student.lastname asc"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
        }
        //search students
        function getstudentbysearch($classid,$search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select student.id,student.studid,student.firstname,student.lastname,student.course,student.year,studentsubject.classid,studentsubject.prelim,studentsubject.midterm,studentsubject.final from studentsubject INNER JOIN student ON studentsubject.studid = student.id where (studentsubject.classid like '%$search%' or student.firstname like '%$search%' or student.lastname like '%$search%' or student.studid like '%$search%') and studentsubject.classid='$classid' order by student.lastname asc"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;  
        }
        //get students' grade
        function getstudentgrade($studid,$classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from studentsubject where studid='$studid' and classid='$classid'";
            $r = mysqli_query($con,$q);
            if($row = mysqli_fetch_array($r)){
                $prelim = $row['prelim'];
                $midterm = $row['midterm'];
                $final = $row['final'];
                $status = $row['status'];
                
                $total = ($prelim * .30) + ($midterm * .30) + ($final * .40);
                
                $data = array(
                    'eqprelim' => $this->gradeconversion($prelim),
                    'eqmidterm' => $this->gradeconversion($midterm),
                    'eqfinal' => $this->gradeconversion($final),
                    'eqtotal' => $this->gradeconversion($total),
                    'prelim' => round($prelim),
                    'midterm' => round($midterm),
                    'final' => round($final),
                    'total' => round($total),
                    'status' => $status,
                );
            }
            
            return $data;
        }
        
        function getstudentbyid($studid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from student where id=$studid";   
            $r = mysqli_query($con,$q);
            $data = array();
            $data[] = mysqli_fetch_array($r);
            return $data;
        }
        
        function gradeconversion($grade){
            $grade = round($grade);
            if($grade==0){
                 $data = 0;
            }else{
                switch ($grade) {
                     case $grade > 98:
                         $data = number_format(1.00, 2);
                         break;
                     case 98:
                         $data = number_format(1.05, 2);
                         break;
                    case 97:
                         $data = number_format(1.10, 2);
                         break;
                    case 96:
                         $data = number_format(1.15, 2);
                         break;
                    case 95:
                         $data = number_format(1.20, 2);
                         break;
                    case 94:
                         $data = number_format(1.25, 2);
                         break;
                    case 93:
                         $data = number_format(1.30, 2);
                         break;
                    case 92:
                         $data = number_format(1.35, 2);
                         break;
                    case 91:
                         $data = number_format(1.40, 2);
                         break;
                    case 90:
                         $data = number_format(1.50, 2);
                         break;
                    case 89:
                         $data = number_format(1.60, 2);
                         break;
                    case 88:
                         $data = number_format(1.70, 2);
                         break;
                    case 87:
                         $data = number_format(1.80, 2);
                         break;
                    case 86:
                         $data = number_format(1.90, 2);
                         break;
                    case 85:
                         $data = number_format(2.00, 2);
                         break;
                    case 84:
                         $data = number_format(2.10, 2);
                         break;
                   case 83:
                         $data = number_format(2.20, 2);
                         break;
                    case 82:
                         $data = number_format(2.30, 2);
                         break;
                    case 81:
                         $data = number_format(2.40, 2);
                         break;
                    case 80:
                         $data = number_format(2.50, 2);
                         break;
                    case 79:
                         $data = number_format(2.60, 2);
                         break;    
                    case 78:
                         $data = number_format(2.70, 2);
                         break;   
                    case 77:
                         $data = number_format(2.80, 2);
                         break;   
                    case 76:
                         $data = number_format(2.90, 2);
                         break;   
                    case 75:
                         $data = number_format(3.00, 2);
                         break;  

                     default:
                         $data = number_format(5.00, 2);
                }
            }
            return $data;
        }
    }
?>