<?php
    $student = new Datastudentbsa();
    if(isset($_GET['q'])){
        $student->$_GET['q']();
    }
    class Datastudentbsa {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
        //create logs
        function logs($act){ 
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysqli_query($con,$q);
            return true;
        }
        
       //get all student info for student searching per dept
        function getstudent($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $q = "select * from student where course='bsa'and (studid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%' or year like '%$search%') order by lastname,firstname,middlename asc";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        //get all new student info for add to class
        function getnewstudent($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $classid = $_GET['classid'];
            $q = "select * from student where studid like '%$search%' and course='bsa' and id NOT IN (SELECT studid FROM studentsubject where classid=$classid) order by year,lastname,middlename,firstname";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        //get all student info in a class for classstudent.php
        function getstudentclass($search){
           $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
           $classid = $_GET['classid'];
           $q = "select * from student where studid like '%$search%' and id IN (SELECT studid FROM studentsubject where classid=$classid) ORDER BY lastname,firstname,middlename asc";
           $r = mysqli_query($con,$q);
            return $r;
        }
        
         //get all studentcourse info
        function getstudentcourse($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from student where course='BSA' order by lastname,firstname,middlename";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        //get class by ID
        function getstudentbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from student where id=$id";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        //add student
        function addstudent(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $studid = $_POST['studid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $major = $_POST['major'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $semester = $_POST['semester'];
            $sy = $_POST['school_year'];
            
            $connect = mysqli_connect("localhost", "root", "", "grading");
            $sql=mysqli_query($connect,"SELECT * FROM student where studid='$studid'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../bsa.php?r=has already an account&n='.$studid.'');
                exit;
            }else{
            $q = "insert into student values('','$studid','$fname','$mname','$lname','$course','$year','$major','$email','$contact','$semester','$sy')";
            mysqli_query($con,$q);
            $name = $fname.' '.$mname.' '.$lname;
            $act = "added new student $name";
            $this->logs($act);
            
            header('location:../bsa.php?r=added&n='.$name.'');
            }
        }
        
        //update student
        function updatestudent(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $id = $_GET['id'];
            $studid = $_POST['studid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $major = $_POST['major'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $semester = $_POST['semester'];
            $sy = $_POST['school_year'];
            $q = "update student set studid='$studid', firstname='$fname', middlename='$mname', lastname='$lname', course='$course', year='$year', major='$major', email='$email', contact='$contact', semester='$semester', school_year='$sy' where id=$id";
            mysqli_query($con,$q);
            
            $name = $fname.' '.$mname.' '.$lname;
            $act = "updated student $name";
            $this->logs($act);
            
            header('location:../bsa.php?r=updated&n='.$name.'');
        }
        //remove from class
        function removesubject(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $studid = $_GET['studid'];
            $classid = $_GET['classid'];
            mysqli_query($con,"delete from studentsubject where studid=$studid and classid=$classid");
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from student where id=$studid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_student = $tmp_row['firstname'].' '.$tmp_row['lastname'];
            
            $act = "remove student $tmp_student from class $tmp_class with the subject of $tmp_subject";
            $this->logs($act);
            
            header('location:../studentsubject.php?id='.$studid.'');
        }
    }
?>