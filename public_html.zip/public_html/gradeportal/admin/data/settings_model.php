<?php
session_start();
/*add student credentials*/
if(isset($_POST["create"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
        $dept = $_GET['dept'];
		$username = $_GET['studid'];
		$fname = $_GET['fname'];
		$lname = $_GET['lname'];
		$password = $_GET['studid'];
        $admin = $_SESSION['name'];
		
            $q = "select * from userdata where username='$username'";
            $r = mysqli_query($con,$q);
        if(mysqli_num_rows($r) < 1){
            $hash = password_hash($password, PASSWORD_BCRYPT);
			$con->query("INSERT INTO userdata (username,password,firstname,lastname,level) VALUES ('$username', '$hash', '$fname', '$lname', 'student')");

                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $admin.'(Admin) created new Student Account: '.$username;
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
               $name = $fname." ".$lname;
               header("Location:../$dept.php?note=Added New Student Account:&usern=$name");
         
        }else{
               header("Location:../$dept.php?note=Student Account Already Exist");
		}
	
}

/*add teacher credentials*/
if(isset($_POST["userTeacher"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
        $dept = $_GET['dept'];
		$username = $_GET['teachid'];
		$fname = $_GET['fname'];
		$lname = $_GET['lname'];
		$password = $_GET['teachid'];
        $admin = $_SESSION['name'];
		
            $q = "select * from userdata where username='$username'";
            $r = mysqli_query($con,$q);
        if(mysqli_num_rows($r) < 1){
            $hash = password_hash($password, PASSWORD_BCRYPT);
			$con->query("INSERT INTO userdata (username,password,firstname,lastname,level) VALUES ('$username', '$hash', '$fname', '$lname', 'teacher')");

                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $admin.'(Admin) created new Teacher Account: '.$username;
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
               $name = $fname." ".$lname;
               header("Location:../$dept.php?note=Added New Teacher Account for teacher:&name=$name");
         
        }else{
               header("Location:../$dept.php?note=Teacher Account Already Exist");
		}
	
}

/* Global Deletion*/
if(isset($_POST["delete"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $table = $_GET['table'];
            $course = $_GET['course'];
            $id = $_GET['id'];
            $q = "delete from $table where id=$id";
            $r = null;
            
            if($table=='student'){
                $q2 = "delete from studentsubject where studid=$id";
            }
            
            $tmp = mysqli_query($con,"select * from $table where id=$id");
            $tmp_row = mysqli_fetch_array($tmp);
            
            
            mysqli_query($con,$q);
            
            if($table=='subjectbsa'){
                $record = $tmp_row['code'];
                header('location:../subject.php?r=deleted&n='.$record.'');
                
            }else if($table=='class'){
                 $record = $tmp_row['subject'];
                 $sem = $tmp_row['semester'];
                if($sem=='1st Semester'){
                  header('location:../class.php?r=deleted&n='.$record.'');
                }else{
                  header('location:../class2.php?r=deleted&n='.$record.'');
                }
               
            }else if($table=='student' && $course=='bsa'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname; 
                header('location:../bsa.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bsba'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bsba.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bscs'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bscs.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bsed'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bsed.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bscpe'){
               $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bscpe.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bshrtm'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bshrtm.php?r=deleted&n='.$record.'');
               
            }else if($table=='teacher'){
               $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../teacher.php?r=deleted&n='.$record.'');
            }else if($table=='userdata'){
                $record = $tmp_row['username'];
                header('location:../users.php?r=deleted&user='.$record.'');
            }
            
            $act = "deleted $record from $table";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
}

/*add teacher function*/
if(isset($_POST["addTeacher"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $teachid = $_POST['teachid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $dept = $_POST['department'];
            
            
            $sql=mysqli_query($con,"SELECT * FROM teacher where teachid='$teachid'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../teacher.php?r=has already an account&n='.$teachid.'');
                exit;
            }else{
            $q = "insert into teacher values('','$teachid','$fname','$mname','$lname','$email','$contact','$dept')";
            mysqli_query($con,$q);
            $name = $fname.' '.$mname.' '.$lname;
            $act = "Added new teacher: ".$name;
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../teacher.php?r=added&n=$name");
            }
}

/*update teacher function*/
if(isset($_POST["editTeacher"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $id = $_GET['id'];
            $teachid = $_POST['teachid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $dept = $_POST['department'];
            
            $q = "update teacher set teachid='$teachid', firstname='$fname', middlename='$mname', lastname='$lname',email='$email', contact='$contact', department='$dept' where id=$id";
            mysqli_query($con,$q);
            
            $name = $fname.' '.$mname.' '.$lname;
            $act = "Updated data for teacher: ".$name;
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../teacher.php?r=updated&n=$name");
            
}

/*add subject function*/
if(isset($_POST["addsub"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $code = $_POST['code'];
            $title = $_POST['title'];
            $unit = $_POST['unit'];
            $year = $_POST['year_lvl'];
            $course = $_POST['course'];
            $sem = $_POST['semester'];
            
            $sql=mysqli_query($con,"SELECT * FROM subjectbsa where code='$code'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../subject.php?r=exist&n='.$code.'');
                exit;
            }else{
            $q = "insert into subjectbsa values('','$code','$title','$unit','$course','$year','$sem')";
            mysqli_query($con,$q);
            
            $act = "Added new subject: ".$code - $title;
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../subject.php?r=added&n=$title");
            }
}

/*update subject function*/
if(isset($_POST["updatesub"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $id = $_GET['id'];
            $code = $_POST['code'];
            $title = $_POST['title'];
            $unit = $_POST['unit'];
            $course = $_POST['course'];
            $year = $_POST['year_lvl'];
            $sem = $_POST['semester'];
            $q = "update subjectbsa set code='$code', title='$title',unit='$unit',course='$course', year='$year', semester='$sem' where id=$id";
            mysqli_query($con,$q);
            
            $act = "updated subject $code - $title";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../subject.php?r=updated&n=$title");
            
}

/*add class function*/
if(isset($_POST["addclass"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $class = $_GET['class'];
            $sem = $_GET['sem'];
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sy = $_POST['sy'];
            
            $sql=mysqli_query($con,"SELECT * FROM class where subject='$subject'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../'.$class.'.php?r=exist&n='.$subject.'');
                exit;
            }else{
            echo $q = "insert into class values('','$subject','$teacher','$course','$year','$sem','$sy')";
            mysqli_query($con,$q);
            $act = "created new class $subject of Sir/Ma'am $teacher";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            header('location:../'.$class.'.php?r=added&n='.$subject.'');
            }
            
}

/*update class function*/
if(isset($_POST["updateclass"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $id = $_GET['id'];
            $class = $_GET['class'];
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sem = $_POST['semester'];
            $sy = $_POST['sy'];
            
            $q = "update class set subject='$subject', teacher='$teacher', course='$course',year='$year', semester='$sem', sy='$sy' where id=$id";
            mysqli_query($con,$q);
            $act = "updated class $subject of $teacher";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            header('location:../'.$class.'.php?r=updated&n='.$subject.'');
}

/*set as new class teacher function*/
if(isset($_POST["newteacher"]))
{
       
            $classid = $_GET['classid'];
            $teachid = $_GET['teachid'];
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "update class set teacher=$teachid where id=$classid";
            mysqli_query($con,$q);
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from teacher where id=$teachid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_teacher = $tmp_row['firstname'].' '.$tmp_row['lastname'];
            
            $act = "assigned new teacher $tmp_teacher to class $tmp_class with the subject of $tmp_subject";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            
            header('location:../classteacher.php?classid='.$classid.'&teacherid='.$teachid.'');
            
}

/*Add to class(student) function*/
if(isset($_POST["add2class"]))
{
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            
            $classid = $_GET['classid'];
            $teacher = $_GET['teacher'];
            $studid = $_GET['studid'];
            $dept = $_GET['dept'];
            
            $q = "select * from studentsubject where studid=$studid and classid=$classid";
            $r = mysqli_query($con,$q);
            if(mysqli_num_rows($r) < 1){
                echo $q = "INSERT INTO studentsubject (studid,classid,teacher,status) VALUES ('$studid', '$classid', '$teacher','Enrolled');";
                mysqli_query($con,$q);
                header('location:../'.$dept.'.php?r=success&classid='.$classid.'&studid='.$studid.'');
            }else{
                header('location:../'.$dept.'.php?r=duplicate&classid='.$classid.'&studid='.$studid.'');
            }
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from student where id=$studid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_student = $tmp_row['firstname'].' '.$tmp_row['lastname'];
            
            $act = "add student $tmp_student to class $tmp_class with the subject of $tmp_subject";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            
}

/*Remove to class(student) function*/
if(isset($_POST["deletetoclass"]))
{
            $classid = $_GET['classid'];
            $studid = $_GET['studid'];
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "delete from studentsubject where studid=$studid and classid=$classid";
            mysqli_query($con,$q);
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from student where id=$studid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_student = $tmp_row['firstname'].' '.$tmp_row['lastname'];
            
            $act = "remove student $tmp_student from class $tmp_class with the subject of $tmp_subject";
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            
            header('location:../classstudent.php?r=success&classid='.$classid.'');
}
?>