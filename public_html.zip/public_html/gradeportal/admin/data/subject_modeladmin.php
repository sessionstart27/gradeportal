<?php
    $subject = new Datasubject();
    if(isset($_GET['q'])){
        $function = $_GET['q'];
        $subject->$function();
    }
    class Datasubject {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        //incomplete students
        function getsubject($sem){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid where class.semester='$sem' and studentsubject.total =' ' group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
          // failed grade subject
        function getallsubjectinc(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid  group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
        
         //failed students
        function getsubjectfail($sem){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid where class.semester='$sem' and (studentsubject.total > 0 and studentsubject.total < 75) group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
         // updategrade subject
        function getallsubject($sem){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid where class.semester='$sem' group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
         // failed grade subject
        function getallsubjectfail(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid  group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getallsubjectsearch($id){
             $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
             $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN studentsubject ON class.id = studentsubject.classid where class.id='$id' group by class.subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getsubjectbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from class where id=$id";   
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getsubjectbycode($code){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from subjectbsa where code='$code'";
            $r = mysqli_query($con,$q);
            $data = mysqli_fetch_array($r);
            return $data;
        }
    }
?>