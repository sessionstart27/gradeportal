<?php
    $class = new Dataclass();
    if(isset($_GET['q'])){
        $class->$_GET['q']();
    }
    class Dataclass {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
               header('location:../../');   
            }
        }
        
        //create logs
        function logs($act){  
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysqli_query($con,$q);
            return true;
        }
        
        //get all class1 info
        function getclass1($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
             $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code and (class.year like '%$search%' or class.subject like '%$search%' or class.course like '%$search%' or subjectbsa.title like '%$search%') where class.semester='1st Semester' order by subject asc";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
         //get all class2 info
        function getclass2($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code and (class.year like '%$search%' or class.subject like '%$search%' or class.course like '%$search%' or subjectbsa.title like '%$search%') where class.semester='2nd Semester' order by subject asc";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
           //get all 1st sem info
        function getclasssem1($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.semester='1st Semester' order by subject asc";
           
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
         //get all 2nd sem info
        function getclasssem2($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.semester='2nd Semester' order by subject asc";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        //get class by ID
        function getclassbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from class where id=$id";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        //add class1
        function addclass1(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sy = $_POST['sy'];
            
            $connect = mysqli_connect("localhost", "root", "", "grading");
            $sql=mysqli_query($connect,"SELECT * FROM class where subject='$subject'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../class2.php?r=exist&n='.$ubject.'');
                exit;
            }else{
            echo $q = "insert into class values('','$subject','$teacher','$course','$year','1st Semester','$sy')";
            mysqli_query($con,$q);
            $act = "created new class $subject of Sir/Ma'am $teacher";
            $this->logs($act);
            header('location:../class.php?r=added&n='.$subject.'');
            }
        }
        
        //add class2
        function addclass2(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sy = $_POST['sy'];
            
            $connect = mysqli_connect("localhost", "root", "", "grading");
            $sql=mysqli_query($connect,"SELECT * FROM class where subject='$subject'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../class2.php?r=exist&n='.$ubject.'');
                exit;
            }else{
            
            echo $q = "insert into class values('','$subject','$teacher','$course','$year','2nd Semester','$sy')";
            mysqli_query($con,$q);
            $act = "created new class $subject of Sir/Ma'am $teacher";
            $this->logs($act);
            header('location:../class2.php?r=added&n='.$subject.'');
            }
        }
        
        //update class1
        function updateclass1(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $id = $_GET['id'];
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sem = $_POST['semester'];
            $sy = $_POST['sy'];
            
            
            echo $q = "update class set subject='$subject', teacher='$teacher', course='$course',year='$year', semester='$sem', sy='$sy' where id=$id";
            mysqli_query($con,$q);
            $act = "updated class $subject of $teacher";
            $this->logs($act);
            header('location:../class.php?r=updated&n='.$subject.'');
        }
        
        //update class2
        function updateclass2(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $id = $_GET['id'];
            $subject = $_POST['subject'];
            $teacher = $_POST['teacher'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sem = $_POST['semester'];
            $sy = $_POST['sy'];
          
            
            echo $q = "update class set subject='$subject', teacher='$teacher', course='$course',year='$year', semester='$sem', sy='$sy' where id=$id";
            mysqli_query($con,$q);
            $act = "updated class $subject of $teacher";
            $this->logs($act);
            header('location:../class2.php?r=updated&n='.$subject.'');
        }
        
        //get all students in that class
        function getstudentsubject(){ 
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $classid = $_GET['classid'];
            $q = "select * from studentsubject where classid=$classid";
            $r = mysqli_query($con,$q);
            $result = array();
            while($row = mysqli_fetch_array($r)){
                $q2 = 'select * from student where id='.$row['studid'].'';
                $r2 = mysqli_query($con,$q2);
                $result[] = mysqli_fetch_array($r2);
            }
            return $result;
        }
        
        //add student to class
        function addstudent(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            $classid = $_GET['classid'];
            $teacher = $_GET['teacher'];
            $studid = $_GET['studid'];
            $dept = $_GET['dept'];
            $verify = $this->verifystudent($studid,$classid);
            if($verify){
                echo $q = "INSERT INTO studentsubject (studid,classid,teacher,status) VALUES ('$studid', '$classid', '$teacher','Enrolled');";
                mysqli_query($con,$q);
                header('location:../'.$dept.'.php?r=success&classid='.$classid.'&studid='.$studid.'');
            }else{
                header('location:../'.$dept.'.php?r=duplicate&classid='.$classid.'&studid='.$studid.'');
            }
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from student where id=$studid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_student = $tmp_row['fname'].' '.$tmp_row['lname'];
            
            $act = "add student $tmp_student to class $tmp_class with the subject of $tmp_subject";
            $this->logs($act);
        }
        //verify if he/she is enrolled
        function verifystudent($studid,$classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from studentsubject where studid=$studid and classid=$classid";
            $r = mysqli_query($con,$q);
            if(mysqli_num_rows($r) < 1){
                return true;
            }else{
                return false;   
            }
        }
        //remove student to the class
        function removestudent(){
            $classid = $_GET['classid'];
            $studid = $_GET['studid'];
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "delete from studentsubject where studid=$studid and classid=$classid";
            mysqli_query($con,$q);
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from student where id=$studid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_student = $tmp_row['fname'].' '.$tmp_row['lname'];
            
            $act = "remove student $tmp_student from class $tmp_class with the subject of $tmp_subject";
            $this->logs($act);
            
            header('location:../classstudent.php?r=success&classid='.$classid.'');
        }
        
        //update teacher
        function updateteacher(){
            $classid = $_GET['classid'];
            $teachid = $_GET['teachid'];
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "update class set teacher=$teachid where id=$classid";
            mysqli_query($con,$q);
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from teacher where id=$teachid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_teacher = $tmp_row['fname'].' '.$tmp_row['lname'];
            
            $act = "assign teacher $tmp_teacher to class $tmp_class with the subject of $tmp_subject";
            $this->logs($act);
            
            header('location:../classteacher.php?classid='.$classid.'&teacherid='.$teachid.'');
        }
        
    }
?>