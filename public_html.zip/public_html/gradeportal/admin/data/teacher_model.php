<?php
    $teacher = new Datateacher();
    if(isset($_GET['q'])){
        $teacher->$_GET['q']();
    }
    class Datateacher {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
         //create logs
        function logs($act){  
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysqli_query($con,$q);
            return true;
        }
        
        //get all teacher info
        function getteacher($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from teacher where teachid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%' order by teachid,lastname,middlename,firstname";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        //get all late teacher info
        function getteacherlate($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $deadline = mysqli_query($con,"select * from deadline");
            $deadline = mysqli_fetch_array($deadline);
            $deadline1 = $deadline['prelim'];
            $deadline2 = $deadline['midterm'];
            $deadline3 = $deadline['final'];
            date_default_timezone_set('Asia/Manila');
            $currentdate = date('Y-m-d');
            
            if($currentdate > $deadline1){
            $q = "select teacher.id,teacher.teachid,teacher.firstname,teacher.middlename,teacher.lastname,teacher.department,class.id,class.teacher,studentsubject.classid from class INNER JOIN studentsubject ON class.id = studentsubject.classid INNER JOIN teacher ON teacher.id = class.teacher where (teachid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%') and studentsubject.prelim = ' ' group by lastname"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
                
            }else if($currentdate > $deadline2){
            $q = "select teacher.id,teacher.teachid,teacher.firstname,teacher.middlename,teacher.lastname,teacher.department,class.id,class.teacher,studentsubject.classid from class INNER JOIN studentsubject ON class.id = studentsubject.classid INNER JOIN teacher ON teacher.id = class.teacher where (teachid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%') and studentsubject.midterm = ' ' group by lastname"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
                
            }else if($currentdate > $deadline3){
            $q = "select teacher.id,teacher.teachid,teacher.firstname,teacher.middlename,teacher.lastname,teacher.department,class.id,class.teacher,studentsubject.classid from class INNER JOIN studentsubject ON class.id = studentsubject.classid INNER JOIN teacher ON teacher.id = class.teacher where (teachid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%') and studentsubject.final = ' ' group by lastname"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
            }else{
                $q = "select teacher.id,teacher.teachid,teacher.firstname,teacher.middlename,teacher.lastname,teacher.department,class.id,class.teacher,studentsubject.classid from class INNER JOIN studentsubject ON class.id = studentsubject.classid INNER JOIN teacher ON teacher.id = class.teacher where (teachid like '%$search%' or firstname like '%$search%' or middlename like '%$search%' or lastname like '%$search%') and studentsubject.total = '-1' group by lastname"; 
            $r = mysqli_query($con,$q);
            if (!$r) { // add this check.
                die('Invalid query: ' . mysqli_error($db));
            }
            return $r;
            }
        }
        
        //get teacher by ID
        function getteacherbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from teacher where id=$id";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        //add teacher
        function addteacher(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $teachid = $_POST['teachid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $dept = $_POST['department'];
            
            $q = "insert into teacher values('','$teachid','$fname','$mname','$lname','$dept')";
            mysqli_query($con,$q);
            
            $name = $fname.' '.$mname.' '.$lname;
            $act = "Added new teacher $name";
            $this->logs($act);
            
            header('location:../teacher.php?r=added&n='.$name.'');
        }
        
        //update teacher
        function updateteacher(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $id = $_GET['id'];
            $teachid = $_POST['teachid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $dept = $_POST['department'];
            $q = "update teacher set teachid='$teachid', firstname='$fname', middlename='$mname', lastname='$lname', department='$dept' where id=$id";
            mysqli_query($con,$q);
            
            $name = $fname.' '.$mname.' '.$lname;
            $act = "Updated teacher $name";
            $this->logs($act);
            
            header('location:../teacher.php?r=updated&n='.$name.'');
        }
        
        //remove teacher from class
        function removesubject(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $classid = $_GET['classid'];
            $teachid = $_GET['teachid'];
            mysqli_query($con,"update class set teacher=null where id=$classid");
            header('location:../teacherload.php?id='.$teachid.'');
            
            $tmp = mysqli_query($con,"select * from class where id=$classid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_subject = $tmp_row['subject'];
            $tmp_class = $tmp_row['course'].' '.$tmp_row['year'].'-'.$tmp_row['section'];
            
            $tmp = mysqli_query($con,"select * from teacher where id=$teachid");
            $tmp_row = mysqli_fetch_array($tmp);
            $tmp_teacher = $tmp_row['firstname'].' '.$tmp_row['lastname'];
            
            $act = "remove teacher $tmp_teacher from class $tmp_class with the subject of $tmp_subject";
            $this->logs($act);
            
        }
        
    }
?>