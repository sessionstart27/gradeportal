<?php
    $studid = $_GET['studid'];
    $classid = $_GET['classid'];
    $term = $_GET['term'];
    $studno = $_GET['studno'];
    $grade = new Datagrade();
    if($term == 1){
        $grade->prelim($studid,$classid);   
    }
    class Datagrade {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
        function logs($act){  
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysqli_query($con,$q);
            return true;
        }
        
        function prelim($studid,$classid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $studno = $_GET['studno'];
            $prelim = $_POST['prelims'];   
            $midterm = $_POST['midterms'];    
            $final = $_POST['finals'];
            $status = $_POST['status'];
            $total = round(($prelim * .30) + ($midterm * .30) + ($final * .40));
            
            $q = "UPDATE `studentsubject` SET prelim=$prelim,midterm=$midterm,final=$final,total=$total, status='$status' where studid=$studid and classid=$classid";
            mysqli_query($con,$q); 
            
            $student = mysqli_query($con,"select * from student where id=$studid");
            $student = mysqli_fetch_array($student);
            $student = $student['firstname'].' '.$student['lastname'];
            
            $subject = mysqli_query($con,"select * from class where id=$classid");
            $subject = mysqli_fetch_array($subject);
            $subject = $subject['subject'];
            $ssid = $_GET['ssid'];
            
            $act = $ssid.' posted the grades of '.$student.' in '.$subject.'';
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            
            header('location:../update_grades.php?studid='.$studid.'&studno='.$studno.'&name='.$student.'&classid='.$classid.'&remark='.$status.'&status=Student Grade Updated');   
        }
        
        function createlog($studid,$classid,$term){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $student = mysqli_query($con,"select * from student where id=$studid");
            $student = mysqli_fetch_array($student);
            $student = $student['fname'].' '.$student['lname'];
            
            $subject = mysqli_query($con,"select * from class where id=$classid");
            $subject = mysqli_fetch_array($subject);
            $subject = $subject['subject'];
            
            $act = $_SESSION['id'].' posted the grades of '.$student.' in '.$subject.'';
            $this->logs($act);
            return true;
        }
    }
?>