<?php
    $data = new Data();
    if(isset($_GET['q'])){
        $data->$_GET['q']();
    }
    class Data {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
         //create logs
        function logs($act){   
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysqli_query($con,$q);
            return true;
        }
        
        //get all subjects
        function getsubject($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from subjectbsa where code like '%$search%' or title like '%$search%' or course like '%$search%' or semester like '%$search%' order by title asc";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        
        
        //get subject by ID
        function getsubjectbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from subjectbsa where id=$id";
            $r = mysqli_query($con,$q);
            
            return $r;
        }
        //add subject
        function addsubject(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $code = $_POST['code'];
            $title = $_POST['title'];
            $unit = $_POST['unit'];
            $year = $_POST['year'];
            $course = $_POST['course'];
            $sem = $_POST['semester'];
            $q = "insert into subjectbsa values('','$code','$title','$unit','$course','$year','$sem')";
            mysqli_query($con,$q);
            
            $act = "added new subject $code - $title";
            $this->logs($act);
            header('location:../subject.php?r=added&n='.$title.'');
        }
        
        //update subject
        function updatesubject(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $id = $_GET['id'];
            $code = $_POST['code'];
            $title = $_POST['title'];
            $unit = $_POST['unit'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $sem = $_POST['semester'];
            $q = "update subjectbsa set code='$code', title='$title',unit='$unit',course='$course', year='$year', semester='$sem' where id=$id";
            mysqli_query($con,$q);
            
            $act = "updated subject $code - $title";
            $this->logs($act);
            header('location:../subject.php?r=updated&n='.$title.'');
        }
        
        //GLOBAL DELETION
        function delete(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $table = $_GET['table'];
            $course = $_GET['course'];
            $id = $_GET['id'];
            $q = "delete from $table where id=$id";
            $r = null;
            
            if($table=='student'){
                $q2 = "delete from studentsubject where studid=$id";
            }
            
            $tmp = mysqli_query($con,"select * from $table where id=$id");
            $tmp_row = mysqli_fetch_array($tmp);
            
            
            mysqli_query($con,$q);
            
            if($table=='subjectbsa'){
                $record = $tmp_row['code'];
                header('location:../subject.php?r=deleted&n='.$record.'');
                
            }else if($table=='class'){
                 $record = $tmp_row['subject'];
                 $sem = $tmp_row['semester'];
                if($sem=='1st Semester'){
                  header('location:../class.php?r=deleted&n='.$record.'');
                }else{
                  header('location:../class2.php?r=deleted&n='.$record.'');
                }
               
            }else if($table=='student' && $course=='bsa'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname; 
                header('location:../bsa.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bsba'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bsba.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bscs'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bscs.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bsed'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bsed.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bscpe'){
               $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bscpe.php?r=deleted&n='.$record.'');
               
            }else if($table=='student' && $course=='bshrtm'){
                $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../bshrtm.php?r=deleted&n='.$record.'');
               
            }else if($table=='teacher'){
               $fname = $tmp_row['firstname'];
                $mname = $tmp_row['middlename'];
                $lname = $tmp_row['lastname'];
                $record = $fname.' '.$mname.' '.$lname;
                header('location:../teacher.php?r=deleted&n='.$record.'');
            }else if($table=='userdata'){
                $record = $tmp_row['username'];
                header('location:../users.php?r=deleted');
            }
                    
            
        }

    }
?>