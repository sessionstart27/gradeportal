<?php
session_start();
/*add student function*/
if(isset($_POST["addstudent"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $dept = $_GET['dept'];
            $studid = $_POST['studid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $major = $_POST['major'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $semester = $_POST['semester'];
            $sy = $_POST['school_year'];
            
            $sql=mysqli_query($con,"SELECT * FROM student where studid='$studid'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:../'.$dept.'.php?r=has already an account&n='.$studid.'');
                exit;
            }else{
            $q = "insert into student values('','$studid','$fname','$mname','$lname','$course','$year','$major','$email','$contact','$semester','$sy')";
            mysqli_query($con,$q);
            $name = $fname.' '.$mname.' '.$lname;
            $act = "added new student: ".$name;
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../$dept.php?r=added&n=$name");
            }
}

/*update student function*/
if(isset($_POST["updatestud"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            
            $id = $_GET['id'];
            $dept = $_GET['dept'];
            $studid = $_POST['studid'];
            $fname = $_POST['firstname'];
            $mname = $_POST['middlename'];
            $lname = $_POST['lastname'];
            $course = $_POST['course'];
            $year = $_POST['year'];
            $major = $_POST['major'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $semester = $_POST['semester'];
            $sy = $_POST['school_year'];
            
            
            $q = "update student set studid='$studid', firstname='$fname', middlename='$mname', lastname='$lname', course='$course', year='$year', major='$major', email='$email', contact='$contact', semester='$semester', school_year='$sy' where id=$id";
            mysqli_query($con,$q);
            
            $name = $fname.' '.$mname.' '.$lname;
            $act = "Updated data for student: ".$name;
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
           
            header("Location:../$dept.php?r=updated&n=$name");
            
}
?>