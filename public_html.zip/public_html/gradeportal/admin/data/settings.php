<?php
    $settings = new Datasettings();
    if(isset($_GET['q'])){
        $settings->$_GET['q']();
    }

    class Datasettings {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
         //create logs
        function logs($act){       
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A');
            echo $q = "insert into log values(null,'$date','$act')";   
            mysql_query($q);
            return true;
        }
        
        
        function getuser($search){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $user = $_SESSION['id'];
            $q = "select * from userdata where username !='$user' and username like '%$search%' order by lastname asc";
            $r = mysqli_query($con,$q);
            return $r;
        }
    }
?>