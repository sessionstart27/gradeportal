<?php
    include('../config.php');
    include('include/header.php');
    include('include/sidebar.php');
    $username = isset($_GET['username']) ? $_GET['username'] : $_SESSION['id'];
?>
<style>
    @media(max-width:768px){
        .x_content th, .x_content td{
            font-size:10px; 
            
            }
        #adjustble{
            width:70%;
            margin-left:15%;
            margin-right:15%;
        }
        #adjustsm h3{
            font-size:20px;
        }
        
        } 
    @media(min-width:1024px){
        #adjustble{
            width:50%;
            margin-left:25%;
            margin-right:25%;
        }
        #adjustpan{
            float:right;
        }
        #mfooter{
            margin-top:160px;
        }
    }
    #adjustsm h3{
        text-align:center;
    }
</style>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">
                    <i class= "fa fa-cog fa-spin"></i> Settings 
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                        Control Panel
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row">
            <div class="col-lg-12" id="adjustpanel">
         <!-- 1st div -->       
         <div class="table-responsive" style="-webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
                    padding:10px;margin-bottom:40px;margin-top:30px;border:1px solid lightgrey;border-radius:20px;" id="adjustble">
                            <div class="x_panel">
                                <div class="x_title" id="adjustsm">
                                    <h3>Prelim<br> <small>Submission of Grades</small></h3>
                                    
                                    
                                </div>	
                                <hr>
                                <div class="x_content">
                                    <table class="table table-striped" style="text-align:center;overflow-x:auto;">
                                        <thead>
                                <?php
                            
							$control_query= mysqli_query($con,"select * from deadline order by id DESC ") or die (mysqli_error());
							while ($row3= mysqli_fetch_array ($control_query) ){
							$id=$row3['id'];
                            $access1=$row3['access_prelim'];
							?>
                                            <tr>
                                                <th class="text-center">Deadline</th>
                                                <th class="text-center">Status</th>
                                                <?php  if($row3['prelim_stat'] == 'Unlock') { ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php }else{ ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
							
                                            <tr>
                                                <?php  if($row3['prelim_stat'] == 'Lock') { ?>
                                                <td><?php echo "NOT SET!";?> </td>
                                                <td><?php echo $row3['prelim_stat']; ?></td>
                                                <td>  <?php echo "None!";?> </td>
                                                <?php }else{ ?>
                                                <?php  if($row3['prelim_stat'] == 'Unlock' && $row3['access_prelim'] == 'None') { 
                                                ?>
                                                    <td><?php echo $row3['prelim']; ?></td>
                                                    <td><?php echo $row3['prelim_stat']; ?></td>
                                                    <td>  <?php echo "None!";?> </td>
                                                <?php }else if($row3['prelim_stat'] == 'Unlock' && $row3['access_prelim'] == 'Everyone') { 
                                                ?>
                                                    <td><?php echo $row3['prelim']; ?></td>
                                                   <td><?php echo $row3['prelim_stat']; ?></td>
                                                    <td>  <?php echo "Everyone!";?> </td>
                                                <?php }else{
                                                
                                                $q=mysqli_query($con,"select * from teacher where teachid='$access1'") or die(mysqli_error());
												$r=mysqli_fetch_array($q);  ?>
                                                    <td><?php echo $row3['prelim']; ?></td>
                                                    <td><?php echo $row3['prelim_stat']; ?></td>
                                                    <td>Ma'am/Sir <?php echo $r['lastname']; ?></td>   
                                                    <?php } ?>
                                                <?php } ?>
                                                
                                               
                                               
                                                <td>
													<a class="btn btn-primary" for="ViewAdmin" href="#deadline_prelim<?php echo $id; ?>" data-toggle="modal" data-target="#deadline_prelim<?php echo $id;?>">
														<i class="fa fa-edit"></i> Edit
													</a>
												</td>
											
									<!-- edit modal -->
									<div class="modal fade" id="deadline_prelim<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-edit"></i> Change Status / Prelim Deadline </h4>
										</div>
										<div class="modal-body">
												<?php
                                                
												$query2=mysqli_query($con,"select * from deadline where id='$id'")or die(mysqli_error());
												$row4=mysqli_fetch_array($query2);
												?>
												<form action="teachermailer.php?name=<?php echo $_SESSION['name']; ?>" method="post">
													<div class="form-group">
														<div class="control-group">
                                                        <div class="controls">
                                                        <div class="col-md-5">
                                                            <label>Status:</label>
                                                            <select name="status" value="<?php echo $row3['prelim_stat']; ?>" id="first-name2" class="form-control" required>
                                                                
                                                                <option <?php  if($row3['prelim_stat'] == 'Lock') echo "selected"?>>Lock</option>
                                                                <option <?php  if($row3['prelim_stat'] == 'Unlock') echo "selected"?>>Unlock</option>
                                                            </select><br>
                                                                
                                                                <label>Access to:</label>
                                                            <select name="access_prelim" class="form-control" required>
                                                                <option value="">Select Teacher</option>
                                                                <option value="None">None</option>
                                                                <option value="Everyone">Everyone</option>
                                                               <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                                    <option value="<?php echo $row['teachid']; ?>"> <?php echo $row['firstname'].' '.$row['lastname']; ?></option><?php endwhile; ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-5" id="adjustpan">
                                                                
                                                        <label>Set deadline:</label>
                                                        <input type="date" style="color:black;" value="<?php echo $row3['prelim']; ?>" name="prelim" class="form-control has-feedback-right" placeholder="prelim Deadline" aria-describedby="inputSuccess2Status4" required /><br>
                                                            
                                                                 
                                                        <label>Notify via email:</label>
                                                        <select name="email" class="form-control" required>
                                                            <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                        <option value="<?php echo $row['email']; ?>"> <?php echo $row['firstname'].' '.$row['lastname']; ?></option><?php endwhile; ?>
                                                        </select>   
                                                        </div>
                                                            

                                                        </div>
                                                    </div>
                                                        
													</div>
													<div class="modal-footer" id="mfooter">
													<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true"><i class="glyphicon glyphicon-remove icon-white"></i> No</button>
													<button type="submit" style="margin-bottom:5px;" name="deadline1" class="btn btn-primary"><i class="glyphicon glyphicon-ok icon-white"></i> Yes</button>
													</div>
												</form>
                                     <?php
										if (isset($_GET['date'])) {
										if (isset($_GET['status'])) {
										if (isset($_GET['access1'])) {
													
													$date = $_GET['date'];
                                                    $status = $_GET['status'];
                                                    $access1 = $_GET['access1'];
													
													{
														mysqli_query ($con," UPDATE deadline SET prelim='$date', prelim_stat='$status', access_prelim='$access1' ") or die (mysql_error());
													}
													{
														echo "<script>alert('Prelim Deadline Updated!'); window.location='control.php'</script>";
													}
														
													}}}
												?>
											
										</div>
										</div>
									</div>
									</div>
									 </tr>			
                                          
							<?php } ?>
                                       	 
                                        </tbody>
                                    </table>
                                </div>
								
                            </div>
                        </div>
                        
                <!-- 2nd div -->       
         <div class="table-responsive" style="-webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
              padding:10px;margin-bottom:40px;margin-top:30px;border:1px solid lightgrey;border-radius:20px;" id="adjustble">
                            <div class="x_panel">
                                <div class="x_title"  id="adjustsm">
                                    <h3>Midterm <br> <small>Submission of Grades</small></h3>
                                    
                                    
                                </div>	
                                <hr>
                                <div class="x_content">
                                    <table class="table table-striped" style="text-align:center;overflow-x:auto;">
                                        <thead>
                                           
                                <?php
							$control_query= mysqli_query($con,"select * from deadline order by id DESC ") or die (mysqli_error());
							while ($row3= mysqli_fetch_array ($control_query) ){
							$id=$row3['id'];
                            $access2=$row3['access_midterm'];
							?>
                                            <tr>
                                                <th class="text-center">Deadline</th>
                                                <th class="text-center">Status</th>
                                                <?php  if($row3['midterm_stat'] == 'Unlock') { ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php }else{ ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
							
                                            <tr>
                                               <?php  if($row3['midterm_stat'] == 'Lock') { ?>
                                                <td><?php echo "NOT SET!";?> </td>
                                                <td><?php echo $row3['midterm_stat']; ?></td>
                                                <td>  <?php echo "None!";?> </td>
                                                <?php }else{ ?>
                                                <?php  if($row3['midterm_stat'] == 'Unlock' && $row3['access_midterm'] == 'None') { 
                                                ?>  
                                                    <td><?php echo $row3['midterm']; ?></td>
                                                    <td><?php echo $row3['midterm_stat']; ?></td>
                                                    <td>  <?php echo "None!";?> </td>
                                                <?php }else if($row3['midterm_stat'] == 'Unlock' && $row3['access_midterm'] == 'Everyone') { 
                                                ?>
                                                    <td><?php echo $row3['midterm']; ?></td>
                                                   <td><?php echo $row3['midterm_stat']; ?></td>
                                                    <td>  <?php echo "Everyone!";?> </td>
                                                <?php }else{
                                                    $q=mysqli_query($con,"select * from teacher where teachid='$access2'") or die(mysqli_error());
												    $r=mysqli_fetch_array($q);  ?>
                                                    <td><?php echo $row3['midterm']; ?></td>
                                                    <td><?php echo $row3['midterm_stat']; ?></td>
                                                    <td>Ma'am/Sir <?php echo $r['lastname']; ?></td>   
                                                    <?php } ?>
                                                <?php } ?>
                                                
                                                <td>
													<a class="btn btn-primary" for="ViewAdmin" href="#deadline_midterm<?php echo $id; ?>" data-toggle="modal" data-target="#deadline_midterm<?php echo $id;?>">
														<i class="fa fa-edit"></i> Edit
													</a>
												</td>
									<!-- edit modal -->
									<div class="modal fade" id="deadline_midterm<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-edit"></i> Change Status / Midterm Deadline</h4>
										</div>
										<div class="modal-body">
												<?php
												$query2=mysqli_query($con,"select * from deadline where id='$id'")or die(mysqli_error());
												$row4=mysqli_fetch_array($query2);
												?>
												<form action="teachermailer.php?name=<?php echo $_SESSION['name']; ?>" method="post">
													<div class="form-group">
														<div class="control-group">
                                                        <div class="controls">
                                                            <div class="col-md-5">
                                                            <label>Status:</label>
                                                            <select name="status" value="<?php echo $row3['midterm_stat']; ?>" id="first-name2" class="form-control" required>
                                                                
                                                                <option <?php  if($row3['midterm_stat'] == 'Lock') echo "selected"?>>Lock</option>
                                                                <option <?php  if($row3['midterm_stat'] == 'Unlock') echo "selected"?>>Unlock</option>
                                                            </select>
														    <br>
                                                            <label>Access to:</label>
                                                            <select name="access_midterm" class="form-control" required>
                                                                <option value="">Select Teacher</option>
                                                                <option value="None">None</option>
                                                                <option value="Everyone">Everyone</option>
                                                               <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                                    <option value="<?php echo $row['teachid']; ?>"> <?php echo $row['firstname'].' '.$row['lastname']; ?></option>
                                                                <?php endwhile; ?>
                                                            </select>
                                                            </div>
                                                            <div class="col-md-5" id="adjustpan">
                                                                
                                                                <label>Set deadline:</label>
                                                                <input type="date" style="color:black;" value="<?php echo $row3['midterm']; ?>" name="midterm" class="form-control has-feedback-left" placeholder="Midterm Deadline" aria-describedby="inputSuccess2Status4" required /><br>
                                                            
                                                             
                                                        <label>Notify via E-mail:</label>
                                                        <select name="email" class="form-control" required>
                                                            <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                        <option value="<?php echo $row['email']; ?>"><?php echo $row['firstname'].' '.$row['lastname']; ?></option><?php endwhile; ?>
                                                        </select>   
                                                               
                                                            
                                                            </div>
                                                        </div>
                                                    </div>
                                                        
													</div>
													<div class="modal-footer" id="mfooter">
													<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true"><i class="glyphicon glyphicon-remove icon-white"></i> No</button>
													<button type="submit" style="margin-bottom:5px;" name="deadline2" class="btn btn-primary"><i class="glyphicon glyphicon-ok icon-white"></i> Yes</button>
													</div>
												</form>
												 <?php
        										if (isset($_GET['date2'])) {
        										if (isset($_GET['status2'])) {
        										if (isset($_GET['access2'])) {
													
													$date = $_GET['date2'];
                                                    $status = $_GET['status2'];
                                                    $access2 = $_GET['access2'];
													
													{
														mysqli_query ($con," UPDATE deadline SET midterm='$date', midterm_stat='$status', access_midterm='$access2' ") or die (mysql_error());
													}
													{
														echo "<script>alert('Midterm Deadline Updated!'); window.location='control.php'</script>";
													}
														
													}}}
												?>
											
										</div>
										</div>
									</div>
									</div>
												
                                            </tr>
							<?php } ?>
                                        </tbody>
                                    </table>
                                </div>
								
                            </div>
                        </div>
                <!-- 3rd div -->       
        <div class="table-responsive" style="-webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
              padding:10px;margin-bottom:40px;margin-top:30px;border:1px solid lightgrey;border-radius:20px;" id="adjustble">
                            <div class="x_panel">
                                <div class="x_title"  id="adjustsm">
                                    <h3>Finals <br><small>Submission of Grades</small></h3>
                                    
                                    
                                </div>	
                                <hr>
                                <div class="x_content">
                                    <table class="table table-striped" style="text-align:center;overflow-x:auto;">
                                        <thead>
                                <?php
							$control_query= mysqli_query($con,"select * from deadline order by id DESC ") or die (mysqli_error());
							while ($row3= mysqli_fetch_array ($control_query) ){
							$id=$row3['id'];
                            $access3=$row3['access_final'];
							?>
                                            <tr>
                                                <th class="text-center">Deadline</th>
                                                <th class="text-center">Status</th>
                                                <?php  if($row3['final_stat'] == 'Unlock') { ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php }else{ ?>
                                                <th class="text-center">Access to</th>
                                                <th class="text-center">Action</th>
                                                 <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
							
                                            <tr>
                                               <?php  if($row3['final_stat'] == 'Lock') { ?>
                                                <td><?php echo "NOT SET!";?> </td>
                                                <td><?php echo $row3['final_stat']; ?></td>
                                                <td>  <?php echo "None!";?> </td>
                                                <?php }else{ ?>
                                                <?php  if($row3['final_stat'] == 'Unlock' && $row3['access_final'] == 'None') { 
                                                ?>
                                                    <td><?php echo $row3['final']; ?></td>
                                                    <td><?php echo $row3['final_stat']; ?></td>
                                                    <td>  <?php echo "None!";?> </td>
                                                <?php }else if($row3['final_stat'] == 'Unlock' && $row3['access_final'] == 'Everyone') { 
                                                ?>
                                                    <td><?php echo $row3['final']; ?></td>
                                                   <td><?php echo $row3['final_stat']; ?></td>
                                                    <td>  <?php echo "Everyone!";?> </td>
                                                <?php }else{
                                                    $q=mysqli_query($con,"select * from teacher where teachid='$access3'") or die(mysqli_error());
												    $r=mysqli_fetch_array($q);  ?>
                                                    <td><?php echo $row3['final']; ?></td>
                                                    <td><?php echo $row3['final_stat']; ?></td>
                                                    <td>Ma'am/Sir <?php echo $r['lastname']; ?></td>   
                                                    <?php } ?>
                                                <?php } ?>
                                                
                                                
                                                
                                                <td>
													<a class="btn btn-primary" for="ViewAdmin" href="#deadline_finals<?php echo $id; ?>" data-toggle="modal" data-target="#deadline_finals<?php echo $id;?>">
														<i class="fa fa-edit"></i> Edit
													</a>
												</td>
									<!-- edit modal -->
									<div class="modal fade" id="deadline_finals<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-edit"></i> Change Status / Finals Deadline </h4>
										</div>
										<div class="modal-body">
												<?php
												$query2=mysqli_query($con,"select * from deadline where id='$id'")or die(mysqli_error());
												$row4=mysqli_fetch_array($query2);
												?>
												<form action="teachermailer.php?name=<?php echo $_SESSION['name']; ?>" method="post">
													<div class="form-group">
														<div class="control-group">
                                                        <div class="controls">
                                                            <div class="col-md-5">
                                                               <label>Status:</label>
                                                            <select name="status" value="<?php echo $row3['final_stat']; ?>" id="first-name2" class="form-control" required>
                                                                
                                                                <option <?php  if($row3['final_stat'] == 'Lock') echo "selected"?>>Lock</option>
                                                                <option <?php  if($row3['final_stat'] == 'Unlock') echo "selected"?>>Unlock</option>
                                                            </select>
														    <br>
                                                            <label>Access to:</label>
                                                            <select name="access_final" class="form-control" required>
                                                                <option value="">Select Teacher</option>
                                                                <option value="None">None</option>
                                                                <option value="Everyone">Everyone</option>
                                                               <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                                    <option value="<?php echo $row['teachid']; ?>"> <?php echo $row['firstname'].' '.$row['lastname']; ?></option>
                                                                <?php endwhile; ?>
                                                            </select>
                                                            </div>
                                                            <div class="col-md-5" id="adjustpan">
                                                                <label>Set deadline:</label>
                                                                <input type="date" style="color:black;" value="<?php echo $row3['final']; ?>" name="final" class="form-control has-feedback-left" placeholder="Final Deadline" aria-describedby="inputSuccess2Status4" required /><br>
                                                            
                                                          
                                                        <label>Notify via E-mail:</label>
                                                        <select name="email" class="form-control" required>
                                                            <?php 
                                                                    $r = mysqli_query($con,"select * from teacher");
                                                                    while($row = mysqli_fetch_array($r)):
                                                                ?>
                                                        <option value="<?php echo $row['email']; ?>"> <?php echo $row['firstname'].' '.$row['lastname']; ?></option><?php endwhile; ?>
                                                        </select>   
                                                            </div>
                                                        </div>
                                                    </div>
                                                        
													</div>
													<div class="modal-footer" id="mfooter">
													<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true"><i class="glyphicon glyphicon-remove icon-white"></i> No</button>
													<button type="submit" style="margin-bottom:5px;" name="deadline3" class="btn btn-primary"><i class="glyphicon glyphicon-ok icon-white"></i> Yes</button>
													</div>
												</form>
												 <?php
        										if (isset($_GET['date3'])) {
        										if (isset($_GET['status3'])) {
        										if (isset($_GET['access3'])) {
													
													$date = $_GET['date3'];
                                                    $status = $_GET['status3'];
                                                    $access3 = $_GET['access3'];
													
													{
														mysqli_query ($con," UPDATE deadline SET final='$date', final_stat='$status', access_final='$access3' ") or die (mysql_error());
													}
													{
														echo "<script>alert('Finals Deadline Updated!'); window.location='control.php'</script>";
													}
														
													}}}
												?>
												
										</div>
										</div>
									</div>
									</div>
												
                                            </tr>
							<?php } ?>
                                        </tbody>
                                    </table>
                                </div>
								
                            </div>
                        </div>
             </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');