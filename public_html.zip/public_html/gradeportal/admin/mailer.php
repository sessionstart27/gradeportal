<?php
    include('include/header.php');
    include('include/sidebar.php');


?>
<style>
    @media(max-width:768px){
        #mailer{
            width:90%;margin:auto;
            border-radius:15px;
                    
        }
        #mailer1{
            width:90%;margin:auto;
            background-color:white;
            border-radius:15px;
            -webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
            padding:25px;
            margin-bottom:40px;
            margin-top:30px;
            border:1px solid lightgrey;
        }
    }
    @media(min-width:1024px){
        #mailer{
            width:70%;margin:auto;
            border-radius:15px;;
        }
        #mailer1{
            width:70%;margin:auto;
            background-color:white;
            border-radius:15px;
            -webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
            padding:25px;
            margin-bottom:40px;
            margin-top:30px;
            border:1px solid lightgrey;
        }
    }
</style>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">
                    <i class= "fa fa-envelope"></i> Send E-mail
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <i class="fa fa-envelope"></i> <a href="#" style="color:gray;">Send message to users</a>
                    </li>
                    
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row" id="mailer">
            <div class="col-lg-12" id="mailer1">
                 <?php if(isset($_GET['status'])): ?>
                    <?php
                        $r = $_GET['status'];
                        if($r=='Email sent!'){
                            $class='success';   
                          
                        }else{
                            $r='Email sending failed!';
                            $class='danger';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
                
                <form name="Contact Form" method="post" action="sent.php?name=<?php echo $_SESSION['name']; ?>" >
                    <div
                      class="card-body z-depth-2"
                      style="background-color: white;"
                    >
                     
                      <!--Body-->
                      
                      <div class="md-form">
                        <input
                          type="email"
                          id="form2"
                          class="form-control"
                          name="email"
                          placeholder="Send to.."
                          required
                        />
                      </div><br>
                      <!--Textarea with icon prefix-->
                      <div class="md-form">
                        <textarea
                          type="text"
                          id="form8"
                          class="md-textarea form-control"
                          rows="3"
                          name="message"
                          placeholder="Message.."
                          required
                        ></textarea>
                      </div><br>
                      <div class="text-center mt-3">
                        <button
                          type="submit"
                           class="btn btn-success"
                          name="contact_btn"
                          style="float:right;"
                        >
                          Send E-mail
                        </button><br>
                      </div>
                    </div>
                  </form>

             </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');