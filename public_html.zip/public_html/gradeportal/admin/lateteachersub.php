<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/teacher_model.php');
    include('data/data_model.php');
    
    $id = $_GET['id'];
    $teacher = $teacher->getteacherbyid($id);
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Incomplete Subject Grades</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="grades.php">Grades Dashboard</a>
                    </li>
                    <li class="active">
                        <a href="latesub.php">Teacher's List</a>
                    </li>
                   <li class="active">
                        Incomplete Subjects
                    </li>
                    
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php while($row = mysqli_fetch_array($teacher)): ?>
                <h4>Teacher ID : <?php echo $row['teachid']; ?></h4>
                <h4>Name : <?php echo $row['firstname'].' '.$row['lastname']; ?></h4>
                <?php endwhile; ?>
                <hr />
                <div class="table-responsive" style="overflow-x:auto;background-color:white;">
                <table class="table table-striped">
                    <thead>
                        <tr style="color:white;background-color:#0067a7;">
                            <th>No.</th>
                            <th>Subject Code</th>
                            <th>Subject Title</th>
                            <th>Students</th>
                            <th>Course</th>
                            <th>Semester</th>
                            <th>School Year</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $c = 1; ?>
                        <?php   
                            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                                   mysqli_select_db($con,'u588883585_grading');
                            $r1 = mysqli_query($con,"select class.id,class.subject,class.course,class.sy,subjectbsa.title,class.semester from class INNER JOIN studentsubject ON studentsubject.classid = class.id INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.teacher=$id and studentsubject.total='' group by class.subject");
                            
                            while($row = mysqli_fetch_array($r1)):?>
                                    <tr>
                                        <td> <?php echo $c; ?></td>
                                        <td> <?php echo $row['subject']?></td> 
                                        <td> <?php echo $row['title']?></td>            
                                        <td>&ensp;<a href="inc_stud.php?classid=<?php echo $row['id'];?>" target="_blank">View</a></td>     
                                        <td> <?php echo $row['course']?></td>
                                        <td> <?php echo $row['semester']?></td>
                                        <td> <?php echo $row['sy']?></td>
                                        
                                    </tr>
                                    <?php $c++; ?>
                            <?php endwhile;
                        ?>
                        <?php if(mysqli_num_rows($r1) < 1): ?>
                                <tr>
                                    <td colspan="7" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        
                    </tbody>
                </table>    
            </div>
            </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');