<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_modeladmin.php');
    include('data/student_modeladmin.php'); 
    
    $mysubject = $subject->getallsubjectinc(); 
    $classid = isset($_GET['classid']) ? $_GET['classid'] : null;    
    $search = isset($_POST['search']) ? $_POST['search'] : null;    
    if(isset($_POST['search'])){
        $classid = $_POST['search'];   
        $mystudent = $student->getstudentbysearch($classid,$search);
    }else{
        $mystudent = $student->getstudentbyclass($classid);
    }
if($classid!=''){
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select class.id,class.subject,class.teacher,class.course,class.year,teacher.firstname,teacher.lastname, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN teacher ON class.teacher = teacher.id where class.id=$classid");
    $rc = mysqli_fetch_array($rc);
    $title = $rc['title'];
    $teacher = $rc['firstname'].' '.$rc['lastname'];
}else{
    $title =" ";
}

?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>MY STUDENTS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="grades.php">Grades Dashboard</a>
                    </li>
                    <li>
                        <a href="incomplete.php">Incomplete Grades</a>
                    </li>
                   
                    <li class="active">
                         Class Students (Subject: <?php echo $title; ?>)
                        
                    </li>
                </ol>
            </div>
        </div>
        
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['status'])): ?>
                    <?php
                        $r = $_GET['status'];
                        if($r=='Student Grade Added'){
                            $class='success';   
                          
                        }else if($r=='Edit Grade Feature not Allowed. Please contact Administrator'){
                            $class='danger';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <div class="form-inline form-padding">
                    <a href=" "><button type="button" name="submit" class="btn btn-primary" style="font-weight:bolder;">Teacher: <?php echo $teacher;?></button></a>
                    <a href="print_inc.php?classid=<?php echo $classid; ?>" target="_blank"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print Preview</button></a>            
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">                

                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr class="alert-info">
                                <th>No.</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th class="text-center">Prelim</th>
                                <th class="text-center">Midterm</th>
                                <th class="text-center">Finals</th>
                                <th class="text-center">FINAL GRADE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($mystudent)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>    
                                            <td><?php echo $row['studid']; ?></td>    
                                            <td><?php echo $row['lastname'].', '.$row['firstname']; ?></td>  
                                            <td><?php echo $row['course']; ?></td>    
                                            <form action="data/grade_model.php?term=1&studid=<?php echo $row['id'];?>&classid=<?php echo $classid; ?>" method="POST">
                                            <?php $grade = $student->getstudentgrade($row['id'],$classid); ?>

                                            <td class="text-center"><?php echo $grade['prelim'];?></td>
                                
                                            <td class="text-center"><?php echo $grade['midterm'];?></td>  
                                            
                                            <td class="text-center"><?php echo $grade['final'];?></td>    
                                                
                                            <td class="text-center"><?php echo $grade['total'];?></td>    
                                            
                                              </form>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($mystudent) < 1): ?>
                                        <tr><td colspan="9" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                        
                    </table>
                </div>        
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');