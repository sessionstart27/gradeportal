<?php
    include('include/header.php');
    include('include/sidebar.php');
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                   <small style="color:black;">LOGS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                        Logs
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">           
             <div class="col-lg-12">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-clock-o fa-fw"></i> Latest Log Activity</h3>
                    </div>
                    <div class="panel-body">
                        <div class="list-group">
                            <?php 
                            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                                   mysqli_select_db($con,'u588883585_grading');
                            $r = mysqli_query($con,"select * from log order by id desc limit 0,100");?>

                            <?php while($row = mysqli_fetch_array($r)): ?>       
                            <a href="#" class="list-group-item">
                                <span class="badge"><?php echo $row['date']?></span>
                                <i class="fa fa-fw fa-tasks"></i> <?php echo $row['activity']?>
                            </a>                                   
                            <?php endwhile; ?>
                        </div>        
                    </div>
                </div>
            </div>           
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');