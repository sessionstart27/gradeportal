<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/settings.php');
    
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $user = $settings->getuser($search);
?>

<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">
                  <i class= "fa fa-cog fa-spin"></i>  Settings <small>Users</small>
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active"><i class="fa fa-users"></i> <a href="users.php">Users</a></li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['r']) && $_GET['r']=='deleted'): ?>
                    <div class="alert alert-danger">
                        <strong>Account: <?php $_GET['user']; ?> successfully removed!</strong>
                    </div>
                <?php endif; ?>
                <div class="form-inline form-padding">
                    <form action="users.php" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search by User ID">
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                                                                 
                    </form>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive" style="overflow-x:auto;background-color:white;">
                    <table class="table table-striped table-bordered">
                        <thead><tr style="color:white;background-color:#0067a7;">
                            <th>User ID</th>    
                            <th>Name</th>    
                            <th>Level</th>    
                            <th class="text-center">Password</th>    
                            <th class="text-center">Remove</th>    
                        </tr></thead>
                        <tbody>
                        <?php while($row = mysqli_fetch_array($user)): ?>
                            <tr>
                                <td><?php echo $row['username'];?></td>
                                <td><?php echo $row['lastname'].', '.$row['firstname'];?></td>
                                <td><?php echo $row['level'];?></td>
                                <td class="text-center"><a href="usersettings.php?username=<?php echo $row['username'];?>&name=<?php echo $row['firstname'].' '.$row['lastname'];?>">Update</a></td>
                                <td class="text-center"><form action="data/settings_model.php?table=userdata&id=<?php echo $row['id']?>" method="post">
                                    <button type="submit"  title="Remove" style="background: none;
                                        border:none;" name="delete"><i class="fa fa-times-circle fa-2x text-danger confirmation"></i></button> 
                                        </form>
                            </tr>
                        <?php endwhile; ?>
                        <?php if(mysqli_num_rows($user) < 1): ?>
                                <tr>
                                    <td colspan="5" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>  
            </div>
        </div>
    </div>
    <!-- /.container-fluid -

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');