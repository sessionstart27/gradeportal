<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/student_modelbsa.php');
    include('data/class_model.php');
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $student = $student->getstudentclass($search);
    $studentsubject = $class->getstudentsubject();
    $classid = $_GET['classid'];
    
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select * from class where id=$classid");
    $rc = mysqli_fetch_array($rc);
    $subject = $rc['subject'];
    $semester = $rc['semester'];
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>CLASS STUDENTS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                         <?php if($semester=='1st Semester'){ ?>
                        <a href="class.php">Class Info</a>
                        <?php }else { ?>
                        <a href="class2.php">Class Info</a>
                        <?php }?>
                    </li>
                    <li class="active">
                        Class Students (Subject: <?php echo $subject; ?>)
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <form action="classstudent.php?classid=<?php echo $classid;?>" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search by Student ID..." required autofocus>
                        <button type="submit" name="submitsearch" class="btn btn-success"><i class="fa fa-search"></i> Search</button> 
                        
                        <div class="dropdown" style="display:inline-block">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Add Student
                        <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li class="divider"></li>
                            <li><a href="classnewstudent.php?classid=<?php echo $classid;?>">College of Accountancy</a></li>
                            <li class="divider"></li>
                            <li><a href="classnewstudentbsba.php?classid=<?php echo $classid;?>">College of Business Administration</a></li>
                            <li class="divider"></li>
                            <li><a href="classnewstudentbscs.php?classid=<?php echo $classid;?>">College of Computer Studies</a></li>
                            <li class="divider"></li>
                            <li><a href="classnewstudentbsed.php?classid=<?php echo $classid;?>">College of Education, Arts & Sciences</a></li>
                            <li class="divider"></li>
                            <li><a href="classnewstudentbscpe.php?classid=<?php echo $classid;?>">College of Engineering</a></li>
                            <li class="divider"></li>
                            <li><a href="classnewstudentbshrtm.php?classid=<?php echo $classid;?>">College of Hospitality & Tourism Management!</a></li>
                            <li class="divider"></li>
                        </ul>
                        </div>
                        <a href="classstudent.php?classid=<?php echo $classid;?>" class="btn btn-primary">Master List</a>
                        
               
                    </form>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">     
                <?php if($search){ ?>
                    
                        <table class="table table-striped">
                            <thead>
                                <tr class="alert-info">
                                    <th>ID</th>
                                    <th>Student ID</th>
                                    <th>Lastname</th>
                                    <th>Firstname</th>
                                    <th>Middlename</th>
                                    <th>Course</th>
                                    <th>Major</th>
                                    <th>Year</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $c = 1; ?>
                                <?php while($row = mysqli_fetch_array($student)): ?>
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><?php echo $row['studid']; ?></td>
                                    <td><?php echo $row['lastname']; ?></td>
                                    <td><?php echo $row['firstname']; ?></td>
                                    <td><?php echo $row['middlename']; ?></td>
                                    <td><?php echo $row['course']; ?></td>
                                    <td><?php echo $row['major']; ?></td>
                                    <td><?php echo $row['year']; ?></td>
                                   <td class="text-center">
                                       <form action="data/settings_model.php?studid=<?php echo $row['id']; ?>&classid=<?php echo $classid;?>" method="post">
                                        
                                        <button type="submit"  title="Delete Class" style="background: none;
                                        border:none;" name="deletetoclass"><i class="fa fa-times-circle fa-2x text-danger confirmation"></i></button> 
                                        </form></td>     
                                </tr>
                                <?php $c++; ?>
                                <?php endwhile;?>
                                <?php if(mysqli_num_rows($student) < 1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                   
                <?php }else{ ?>
                        <?php if(isset($_GET['r'])): ?>
                            <?php if($_GET['r']=='success'){ ?>
                                <div class="alert alert-success">
                                    <strong>Student Removed Successfully!</strong>
                                </div>
                            <?php }else if($_GET['r']=='duplicate'){ ?>
                                <div class="alert alert-warning">
                                    <strong>Something is wrong! Please try again.</strong>
                                </div>
                            <?php } ?>
                        <?php endif;?>            
                        <table class="table table-striped">
                            <thead>
                                <tr class="alert-info">
                                <th>ID</th>
                                <th>Student ID</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Middlename</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>Year</th>
                                <th class="text-center">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $c = 1; ?>
                                <?php while($row = mysqli_fetch_array($student)): ?>
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><?php echo $row['studid']; ?></td>
                                    <td><?php echo $row['lastname']; ?></td>
                                    <td><?php echo $row['firstname']; ?></td>
                                    <td><?php echo $row['middlename']; ?></td>
                                    <td><?php echo $row['course']; ?></td>
                                    <td><?php echo $row['major']; ?></td>
                                    <td><?php echo $row['year']; ?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?studid=<?php echo $row['id']; ?>&classid=<?php echo $classid;?>" method="post">
                                        
                                        <button type="submit"  title="Delete Class" style="background: none;
                                        border:none;" name="deletetoclass"><i class="fa fa-times-circle fa-2x text-danger confirmation"></i></button> 
                                        </form>
                                        </td>     
                                </tr>
                                <?php $c++; ?>
                                <?php endwhile;?>
                                <?php if(!$studentsubject): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-danger"><strong>*** EMPTY ***</strong></td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>                       
                    
                
                <?php } ?>
                    </div>
            </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');