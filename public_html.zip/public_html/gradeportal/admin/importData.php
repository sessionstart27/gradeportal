<?php

/*---- Upload CSV File ---*/
$con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error('u588883585_grading'));
       mysqli_select_db($con,'u588883585_grading');
$dept = $_GET['dept'];
if(isset($_POST["import"]))
{
 if($_FILES['file']['name'])
 {
  $filename = explode(".", $_FILES['file']['name']);
  if($filename[1] == 'csv')
  {
   $header= 1;
   $handle = fopen($_FILES['file']['tmp_name'], "r");
   while(($data = fgetcsv($handle, 10000, ",")) !== FALSE)

   {
        if($header== 1)
        {
            $header++;
            continue;
        }
       
                $studid = mysqli_real_escape_string($con, $data[0]);  
                $fname = mysqli_real_escape_string($con, $data[1]);
                $mname = mysqli_real_escape_string($con, $data[2]);  
                $lname = mysqli_real_escape_string($con, $data[3]);
                $course = mysqli_real_escape_string($con, $data[4]);  
                $year = mysqli_real_escape_string($con, $data[5]);
                $major = mysqli_real_escape_string($con, $data[6]);  
                $email = mysqli_real_escape_string($con, $data[7]);
                $contact = mysqli_real_escape_string($con, $data[8]);  
                $semester = mysqli_real_escape_string($con, $data[9]);
                $sy = mysqli_real_escape_string($con, $data[10]);  
            
            $sql=mysqli_query($con,"SELECT * FROM student where studid='$studid'");
            if(mysqli_num_rows($sql)>0)
            {
                header('location:'.$dept.'.php?studid='.$studid.'&s=Already Exist!');
                exit;
            }else{
                $query = "INSERT into student(studid, firstname, middlename, lastname, course, year, major, email, contact, semester, school_year) values('$studid','$fname','$mname','$lname','$course','$year','$major','$email','0$contact','$semester','$sy')";
                mysqli_query($con, $query);
                header('location:'.$dept.'.php?msg=Student List Uploaded Successfully.');
            }
   }
   fclose($handle);
  
   header('location:'.$dept.'.php?msg=Student List Uploaded Successfully.');
  }else
  {
   
   header('location:'.$dept.'.php?msg=Please Select .CSV File only');
  }
 }
}
?>