<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/teacher_model.php');
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $teacher = $teacher->getteacher($search);
    $classid = $_GET['classid'];

    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
    $teacherid = $_GET['teacherid'];
    $rt = mysqli_query($con,"select * from teacher where id=$teacherid");
    $rs = mysqli_fetch_array($rt);
    $teacherbyid = $rs['firstname'].' '.$rs['lastname'];
    
    $rc = mysqli_query($con,"select * from class where id=$classid");
    $rc = mysqli_fetch_array($rc);
    $subject = $rc['subject'];
    $semester = $rc['semester'];
    
    
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>CLASS TEACHER</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <?php if($semester=='1st Semester'){ ?>
                        <a href="class.php">Class Info</a>
                        <?php }else { ?>
                        <a href="class2.php">Class Info</a>
                        <?php }?>
                    </li>
                    <li class="active">
                        Class Teacher
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <form action="classteacher.php?classid=<?php echo $classid;?>&teacherid=<?php echo $teacherid; ?>" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search by ID # or Name..." required autofocus>
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                         
                    </form>
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-info">
                    <table>
                        <tr>
                            <td width="100"><strong>SUBJECT</strong></td>                            
                            <td><?php echo $subject; ?></td>
                        </tr>
                        <tr>
                            <td width="100"><strong>TEACHER</strong></td>                            
                            <td><?php echo $teacherbyid; ?></td>
                        </tr>
                    </table>     
                </div>
                <div class="table-responsive" style="overflow-x:auto;background-color:white;">     
                <?php if($search): ?>
                    
                        <table class="table table-striped">
                            <thead>
                                <tr style="color:white;background-color:#0067a7;">
                                    <th>Teacher ID</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_array($teacher)): ?>
                                <tr>
                                    <td><?php echo $row['teachid']; ?></td>
                                    <td><?php echo $row['firstname']; ?></td>
                                    <td><?php echo $row['lastname']; ?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?teachid=<?php echo $row['id']; ?>&classid=<?php echo $classid;?>" method="post" enctype="multipart/form-data">
                                           <button type="submit" name="newteacher"  class="btn btn-warning">Update Class Teacher</button>
                                        </form>
                                        </td>     
                                </tr>
                                <?php endwhile;?>
                                <?php if(mysqli_num_rows($teacher) < 1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-danger"><strong>*** NO RESULT ***</strong></td>
                                    </tr>
                                <?php endif;?>
                            </tbody>
                        </table>
                   
                <?php endif; ?>
                    </div>                
            </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');