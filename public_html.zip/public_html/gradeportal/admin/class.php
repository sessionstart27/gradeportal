<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/class_model.php');

$que = mysqli_query($con,"select * from s_year where current_stat='Yes'");
$row = mysqli_fetch_array($que);
$s_year = $row['school_year'];

  
if(isset($_POST['submitsearch'])){ 
    $search = isset($_POST['search']) ? $_POST['search']: $s_year;
    $class = $class->getclass1($s_year,$search);
   }else{

    $search = isset($_POST['search']) ? $_POST['search']: $s_year;
    $class = $class->getclasssem1($s_year,$search);
}
  
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small style="color:black;">CLASS INFORMATION</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                       <a href="class.php">Class (1st Semester)</a> 
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <form action="class.php" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search Class Info...">
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                                
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addclass1">Add Class</button>
                        <div class="dropdown" style="display:inline-block">
                        <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Select Semester
                        <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li class="divider"></li>
                            <li><a href="class.php">1st Semester</a></li>
                            <li class="divider"></li>
                            <li><a href="class2.php">2nd Semester</a></li>
                           <li class="divider"></li>
                        </ul>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--/.row -->
        <hr />   
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['r'])): ?>
                    <?php
                        $r = $_GET['r'];
                        if($r=='added'){
                            $classs='success';   
                        }else if($r=='updated'){
                            $classs='info';   
                        }else if($r=='exist'){
                            $classs='danger';   
                        }else if($r=='deleted'){
                            $classs='danger';   
                        }else if($r=='notmatched'){
                            $classs='danger';
                        }else{
                            $classs='hide';
                        }
                    ?>
                    <div class="alert alert-<?php echo $classs?> <?php echo $classs; ?>">
                        <strong>Subject Code: <?php echo $_GET['n']; ?> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                
                <div class="table-responsive" style="overflow-x:auto;background:white;">
                    <table class="table table-striped">
                        <thead>
                            <tr style="color:white;background-color:#0067a7;">
                                <th>ID</th>
                                <th class="text-center">Subject Code</th>
                                <th class="text-center">Subject Title</th>
                                <th class="text-center">Teacher</th>
                                <th class="text-center">Students</th>
                                <th class="text-center">Class</th>
                                <th class="text-center">Year</th>
                                <th class="text-center">S.Y.</th>
                                <th colspan="2" width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($class)): ?>                            
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td class="text-center"><?php echo $row['subject'];?></td>
                                    <td class="text-center"><?php echo $row['title'];?></td>
                                    <td class="text-center"><a href="classteacher.php?classid=<?php echo $row['id'];?>&teacherid=<?php echo $row['teacher'];?>" title="update teacher">View</a></td>
                                    <td class="text-center"><a href="classstudent.php?classid=<?php echo $row['id'];?>" title="update students" title="add student">View</a></td>
                                    <td class="text-center"><?php echo $row['course'];?></td>
                                    <td class="text-center"><?php echo $row['year'];?></td>                                
                                    <td class="text-center"><?php echo $row['sy'];?></td>
                                    <td class="text-center">                                                                               
                                        <a href="editclass.php?type=class1&id=<?php echo $row['id']?>" title="update class"><i class="fa fa-edit fa-2x text-primary"></i></a></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?table=class&id=<?php echo $row['id']?>" method="post" style="float:right;">
                                        
                                        <button type="submit"  title="Delete Class" style="background: none;
                                        border:none;" name="delete"><i class="fa fa-times-circle fa-2x text-danger confirmation"></i></button> 
                                        </form></td>
                                </tr>
                            <?php $c++; ?>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($class) < 1): ?>
                                <tr>
                                    <td colspan="9" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/modal.php'); ?>
<?php include('include/footer.php'); ?>