<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/data_model.php');
    include('data/class_model.php');
    include('data/student_modelbsa.php');
    include('data/teacher_model.php');
    $id = $_GET['id'];
    $subject = $data->getsubjectbyid($id);
    $class = $class->getclassbyid($id);
    $student = $student->getstudentbyid($id);
    $teacher = $teacher->getteacherbyid($id);

?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>EDIT</small>
                </h1>
                <?php 
                    $edit = new Edit();
                    $type = $_GET['type'];
                    if($type=='subject'){
                        $edit->editsubject($subject);
                    }else if($type=='class1'){
                        $edit->editclass1($class);
                    }else if($type=='class2'){
                        $edit->editclass2($class);
                    }else if($type=='bsa'){
                        $edit->editstudent($student);   
                    }else if($type=='teacher'){
                        $edit->editteacher($teacher);   
                    }
                ?>
            </div>
        </div>
        <!-- /.row -->

       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    

<?php include('include/footer.php');

class Edit {
    
    function editsubject($subject){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <a href="subject.php">Subject</a>
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
        <div class="modal-body">
            <?php while($row = mysqli_fetch_array($subject)): ?>
            <form action="data/data_model.php?q=updatesubject&id=<?php echo $row['id'];?>" method="post">
            
                <div class="form-group">
                    <label>Code</label>
                    <input type="text" class="form-control" value="<?php echo $row['code']; ?>" name="code" placeholder="subject code" />
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" class="form-control" value="<?php echo $row['title']; ?>" name="title" placeholder="subject title" />
                </div>
                <div class="form-group">
                    <label>No. Of Units</label>
                    <input type="number" min="1" max="6" class="form-control" value="<?php echo $row['unit']; ?>" name="unit" placeholder="no. of units" />
                </div>
                <div class="form-group">
                    <label>Year Level Offered</label>
                    <select name="year_lvl" class="form-control" required>
                        <option value="<?php echo $row['year_lvl']; ?>"><?php echo $row['year_lvl']; ?></option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <select name="semester" class="form-control" required>
                        <option value="<?php echo $row['semester']; ?>"><?php echo $row['semester']; ?></option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <a href="subject.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
            <?php endwhile; ?>
            </form>
        </div>
        
<?php    }
    
    function editclass1($class){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <?php 
                   $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                   $id = $_GET['id'];
                   $rc = mysqli_query($con,"select * from class where id='$id'");
                   $rc = mysqli_fetch_array($rc);
                   $semester = $rc['semester'];
                ?>  
                        <?php if($semester=='1st Semester'){ ?>
                        <a href="class.php">Class Info</a>
                        <?php }else { ?>
                        <a href="class2.php">Class Info</a>
                        <?php }?>
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
        <div class="modal-body">
            <?php while($row = mysqli_fetch_array($class)): ?>
            <form action="data/settings_model.php?class=class&id=<?php echo $row['id']?>" method="post">
                <div class="form-group">  
                    <select name="subject" class="form-control" required>
                        <option value="">Select Subject...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                        $r = mysqli_query($con,"select * from subjectbsa");
                        while($re = mysqli_fetch_array($r)):
                    ?>  
                        <option <?php  if($row['subject'] == $re['code']) echo "selected"?> value="<?php echo $re['code']; ?>"><?php echo $re['code']; ?> - (<?php echo $re['title']; ?>)</option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">  
                    <select name="teacher" class="form-control" required>
                        <option value="">Select Teacher...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                        $r = mysqli_query($con,"select * from teacher");
                        while($re = mysqli_fetch_array($r)):
                    ?>  
                        <option <?php  if($row['teacher'] == $re['id']) echo "selected"?> value="<?php echo $re['id']; ?>"><?php echo $re['firstname'].' '.$re['lastname']; ?></option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Class...</option>
                        <option <?php  if($row['course'] == 'All Courses (Minor)') echo "selected"?>>All Courses (Minor)</option>
                        <option <?php  if($row['course'] == 'BSA') echo "selected"?>>BSA</option>
                        <option <?php  if($row['course'] == 'BSBA') echo "selected"?>>BSBA</option>
                        <option <?php  if($row['course'] == 'BSCS/BSIT') echo "selected"?>>BSCS/BSIT</option>
                        <option <?php  if($row['course'] == 'BSEE/BSSE/ABCom') echo "selected"?>>BSEE/BSSE/ABCom</option>
                        <option <?php  if($row['course'] == 'BSCpE/BSECE') echo "selected"?>>BSCpE/BSECE</option>
                        <option <?php  if($row['course'] == 'BSHRM/BSTM') echo "selected"?>>BSHRM/BSTM</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option <?php  if($row['year'] == '1st Year') echo "selected"?>>1st Year</option>
                        <option <?php  if($row['year'] == '2nd Year') echo "selected"?>>2nd Year</option>
                        <option <?php  if($row['year'] == '3rd Year') echo "selected"?>>3rd Year</option>
                        <option <?php  if($row['year'] == '4th Year') echo "selected"?>>4th Year</option>
                        <option <?php  if($row['year'] == '5th Year') echo "selected"?>>5th Year</option>
                        <option <?php  if($row['year'] == 'Mixed(1st - 5th year)') echo "selected"?>>Mixed(1st - 5th year)</option>
                    </select>
                </div>
                <div class="form-group">
                    <input name="semester" class="form-control" readonly value="<?php echo $row['semester']; ?>"/>
                </div>
                <div class="form-group">
                    <select name="sy" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=2; $c > 0; $c--): ?>
                        <?php $sy = ($year).'-'.($year+1); ?>
                        <option <?php  if($row['sy'] == $sy) echo "selected"?>><?php echo $sy;?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <a href="class.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary" name="updateclass"><i class="fa fa-check"></i> Update</button>
            </form>
            <?php endwhile; ?>
        </div>
    <?php
    }
    
     function editclass2($class){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <?php 
                   $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                   $id = $_GET['id'];
                   $rc = mysqli_query($con,"select * from class where id='$id'");
                   $rc = mysqli_fetch_array($rc);
                   $semester = $rc['semester'];
                ?>  
                        <?php if($semester=='1st Semester'){ ?>
                        <a href="class.php">Class Info</a>
                        <?php }else { ?>
                        <a href="class2.php">Class Info</a>
                        <?php }?>
              
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
        <div class="modal-body">
            <?php while($row = mysqli_fetch_array($class)): ?>
            <form action="data/settings_model.php?class=class2&id=<?php echo $row['id']?>" method="post">
                <div class="form-group">  
                    <select name="subject" class="form-control" required>
                        <option value="">Select Subject...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                        $r = mysqli_query($con,"select * from subjectbsa");
                        while($re = mysqli_fetch_array($r)):
                    ?>  
                        <option <?php  if($row['subject'] == $re['code']) echo "selected"?> value="<?php echo $re['code']; ?>"><?php echo $re['code']; ?> - (<?php echo $re['title']; ?>)</option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">  
                    <select name="teacher" class="form-control" required>
                        <option value="">Select Teacher...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                        $r = mysqli_query($con,"select * from teacher");
                        while($re = mysqli_fetch_array($r)):
                    ?>  
                        <option <?php  if($row['teacher'] == $re['id']) echo "selected"?> value="<?php echo $re['id']; ?>"><?php echo $re['firstname'].' '.$re['lastname']; ?></option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Class...</option>
                        <option <?php  if($row['course'] == 'All Courses (Minor)') echo "selected"?>>All Courses (Minor)</option>
                        <option <?php  if($row['course'] == 'BSA') echo "selected"?>>BSA</option>
                        <option <?php  if($row['course'] == 'BSBA') echo "selected"?>>BSBA</option>
                        <option <?php  if($row['course'] == 'BSCS/BSIT') echo "selected"?>>BSCS/BSIT</option>
                        <option <?php  if($row['course'] == 'BSEE/BSSE/ABCom') echo "selected"?>>BSEE/BSSE/ABCom</option>
                        <option <?php  if($row['course'] == 'BSCpE/BSECE') echo "selected"?>>BSCpE/BSECE</option>
                        <option <?php  if($row['course'] == 'BSHRM/BSTM') echo "selected"?>>BSHRM/BSTM</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option <?php  if($row['year'] == '1st Year') echo "selected"?>>1st Year</option>
                        <option <?php  if($row['year'] == '2nd Year') echo "selected"?>>2nd Year</option>
                        <option <?php  if($row['year'] == '3rd Year') echo "selected"?>>3rd Year</option>
                        <option <?php  if($row['year'] == '4th Year') echo "selected"?>>4th Year</option>
                        <option <?php  if($row['year'] == '5th Year') echo "selected"?>>5th Year</option>
                        <option <?php  if($row['year'] == 'Mixed(1st - 5th year)') echo "selected"?>>Mixed(1st - 5th year)</option>
                    </select>
                </div>
                <div class="form-group">
                    <input name="semester" class="form-control" readonly value="<?php echo $row['semester']; ?>"/>
                </div>
                <div class="form-group">
                    <select name="sy" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=2; $c > 0; $c--): ?>
                        <?php $sy = ($year).'-'.($year+1); ?>
                        <option <?php  if($row['sy'] == $sy) echo "selected"?>><?php echo $sy;?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <a href="class.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary" name="updateclass"><i class="fa fa-check"></i> Update</button>
            </form>
            <?php endwhile; ?>
        </div>
    <?php
    }
    
    function editstudent($student){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <a href="bsa.php">Student's List(Accountancy)</a>
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
        <div class="modal-body">
            <?php while($row = mysqli_fetch_array($student)): ?>
            <form action="data/student_modelbsa.php?q=updatestudent&id=<?php echo $row['id'];?>" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="studid" value="<?php echo $row['studid']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="fname" value="<?php echo $row['fname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="mname" value="<?php echo $row['mname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lname" value="<?php echo $row['lname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="course" readonly value="<?php echo $row['course']; ?>" />
                </div>
                 <div class="form-group">
                    <select name="year" class="form-control">
                        <option value="<?php echo $row['year']; ?>"><?php echo $row['year']; ?></option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <a href="bsa.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
            </form>
            </form>
            <?php endwhile; ?>
        </div>

    <?php    
    }
    
    function editteacher($teacher){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <a href="studentlist.php">Teacher's List</a>
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
        <div class="modal-body">
            <?php while($row = mysqli_fetch_array($teacher)): ?>
            <form action="data/teacher_model.php?q=updateteacher&id=<?php echo $row['id'];?>" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="teachid" value="<?php echo $row['teachid']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="fname" value="<?php echo $row['fname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lname" value="<?php echo $row['lname']; ?>" />
                </div>
        </div>
        <div class="modal-footer">
            <a href="teacherlist.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
            </form>
            <?php endwhile; ?>
        </div>

    <?php    
    }
}

?>