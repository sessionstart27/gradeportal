<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_modeladmin.php');
    include('data/student_modeladmin.php'); 

    $id = $_GET['classid'];
    $mysubject = $subject->getallsubjectsearch($id); 
    $classid = isset($_GET['classid']) ? $_GET['classid'] : null;    
    $search = isset($_POST['search']) ? $_POST['search'] : null;    
    if(isset($_POST['search'])){
        $classid = $_POST['subject'];   
        $mystudent = $student->getstudentbysearch($classid,$search);
    }else{
        $mystudent = $student->getstudentbyclassupdate($classid);
    }
if($classid!=''){
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
     mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.id=$classid");
    $rc = mysqli_fetch_array($rc);
    $title = $rc['title'];
}else{
    $title =" ";
}

?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>UPDATE STUDENT GRADES</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="grades.php">Grades Dashboard</a>
                    </li>
                    <li class="active">
                     <a href="updategrade_subj.php">Subjects</a>
                    </li>
                   
                    <li class="active">
                         Class Students (Subject: <?php echo $title; ?>)
                        
                    </li>
                </ol>
            </div>
        </div>
        
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
              <?php if(isset($_GET['status'])): ?>
                <?php if(isset($_GET['remark'])): ?>
                <?php if(isset($_GET['studno'])): ?>
                    <?php
                        $r = $_GET['status'];
                        $re = $_GET['remark'];
                        $studno = $_GET['studno'];
                        if($r=='Student Grade Updated' && $re=='Enrolled'){
                            $class='success';   
                          
                        }else if($r=='Student Grade Updated' && $re=='Officially Dropped'){
                            $class='hide';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong> <?php echo $r; ?> for Student ID: <?php echo $studno; ?> <?php echo $_GET['name']; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($_GET['remark'])): ?>
                <?php if(isset($_GET['studno'])): ?>
                    <?php
                        $re = $_GET['remark'];
                        $studno = $_GET['studno'];
                        if($re=='Officially Dropped'){
                            $class='danger';   
                          
                        }else{
                            $class='hide';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong>Student <?php echo $studno; ?> : <?php echo $re; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <?php endif; ?>

                <div class="form-inline form-padding">
                    <form action="update_grades.php?classid=<?php echo $classid?>" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search by ID or Name">
                        <select name="subject" class="form-control" required>
                            <option value="">Select Subject...</option>                            
                            <?php while($row = mysqli_fetch_array($mysubject)): ?>
                                <option value="<?php echo $row['id']?>" <?php if($row['id']==$classid) echo 'selected'; ?>><?php echo $row['subject'];?></option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                     
                        <a href="printstud_admin.php?classid=<?php echo $classid; ?>" target="_blank"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print Preview</button></a>            
                    </form>
                   
                </div>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li>
                        <?php
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                            $deadline = mysqli_query($con,"select * from deadline");
                            $deadline = mysqli_fetch_array($deadline);
                            $deadline1 = $deadline['prelim'];
                            $deadline2 = $deadline['midterm'];
                            $deadline3 = $deadline['final'];
                            $stat1 = $deadline['prelim_stat'];
                            $stat2 = $deadline['midterm_stat'];
                            $stat3 = $deadline['final_stat'];
                            date_default_timezone_set('Asia/Manila');
                            $currentdate = date('Y-m-d');
                        ?>
                         <?php if($currentdate <= $deadline1 && $stat1 =='Unlock'){ ?>
                            <strong style="color:red;"> NOTE:</strong> &ensp; <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Prelim grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline1; ?></strong>, any alteration of student grade will not be allowed after the deadline!  
                            <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong>
                        
                            <?php }else if($currentdate <= $deadline2 && $stat2 =='Unlock'){ ?>
                            <strong style="color:red;"> NOTE:</strong> &ensp; <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Midterm grades <strong>On or Before </strong><strong style="color:red;font-size:18px; "><?php echo $deadline2; ?></strong>, any alteration of student grade will not be allowed after the deadline!  
                            <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong>
                        
                        
                            <?php }else if($currentdate <= $deadline3 && $stat3 =='Unlock'){ ?>
                             <strong style="color:red;"> NOTE:</strong> &ensp; <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Final grades <strong>On or Before</strong> <strong style="color:red;font-size:18px;"><?php echo $deadline3; ?></strong>, any alteration of student grade will not be allowed after the deadline!
                            <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong>
                        
                            <?php }else{ ?>
                            <strong style="color:red;"> NOTE:</strong> &ensp; <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit student grade <strong>On or Before</strong> the deadline, any alteration of student grade will not be allowed!
                            <br>
                            &emsp;<strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong>
                        <?php } ?> 
                         
                
                    </li>
                    
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">                

                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr class="alert-info">
                                <th>No.</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course & Year</th>
                                <th class="text-center">Prelim</th>
                                <th class="text-center">Midterm</th>
                                <th class="text-center">Final</th>
                                <th class="text-center">FINAL GRADE</th>
                                <th class="text-center">Equivalent</th>
                                <th class="text-center">Remarks</th>
                                <th class="text-center">Submit Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($mystudent)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>    
                                            <td><?php echo $row['studid']; ?></td>    
                                            <td><?php echo $row['lastname'].', '.$row['firstname']; ?></td>  
                                            <td><?php echo $row['course'].'- '.$row['year']; ?></td>    
                                            <form action="data/grade_modeladmin.php?term=1&studid=<?php echo $row['id'];?>&classid=<?php echo $classid; ?>&studno=<?php echo $row['studid']; ?>&ssid=<?php echo $_SESSION['name']; ?>" method="POST">
                                            <?php $grade = $student->getstudentgrade($row['id'],$classid); ?>
                                             
                                            <?php
                                            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                                            mysqli_select_db($con,'u588883585_grading');
                                            $deadline = mysqli_query($con,"select * from deadline");
                                            $deadline = mysqli_fetch_array($deadline);
                                            $deadline1 = $deadline['prelim'];
                                            $deadline2 = $deadline['midterm'];
                                            $deadline3 = $deadline['final'];
                                            $stat1 = $deadline['prelim_stat'];
                                            $stat2 = $deadline['midterm_stat'];
                                            $stat3 = $deadline['final_stat'];
                                            date_default_timezone_set('Asia/Manila');
                                            $currentdate = date('Y-m-d');
                                            ?>
                                                
                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['prelim'];?>" name="prelims"/></td>

                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['midterm'];?>" name="midterms"/></td>    
                                           
                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['final'];?>" name="finals"/></td>   
                                            
                                            <td class="text-center"><?php echo $grade['total'];?></td> 
                                            <td class="text-center"><?php echo $grade['eqtotal']; ?></td>
                                            <td class="text-center">
                                            
                                            <select name="status" class="form-control">
                                                <option <?php  if($grade['status'] == 'Enrolled') echo "selected"?>>Enrolled</option>
                                                <option <?php  if($grade['status'] == 'Officially Dropped') echo "selected"?>>Officially Dropped</option>
                                            </select>
                                            </td>   
                                            <td class="text-center"><button type="submit" class="btn btn-success">Submit</button>
                                            </td>    </form>
                                   
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($mystudent) < 1): ?>
                                        <tr><td colspan="9" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                        
                    </table>
                </div>        
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');