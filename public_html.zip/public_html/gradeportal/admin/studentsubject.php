<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/student_modelbsa.php');
    include('data/data_model.php');
    
    $id = $_GET['id'];
    $student = $student->getstudentbyid($id);
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>STUDENT SUBJECT</small><a href="printgradebsa.php?id=<?php echo $_GET['id'];?>" target="_blank" style="float:right;"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print Copy of Grades</button></a>
                </h1>
                
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="bsa.php">Students</a>
                    </li>
                    <li class="active">
                        Student Subject
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php while($row = mysqli_fetch_array($student)): ?>
                <h4>Student ID : <?php echo $row['studid']; ?></h4>
                <h4>Name : <?php echo $row['firstname'].' '.$row['lastname']; ?></h4>
                <h4>School Year : <?php echo $row['school_year']; ?></h4>
                <?php endwhile; ?>
                
                <hr />
    <!-- stud grades -->
<?php
    include('data/grade.php');
    $firstsem = $grade->getsubject('1st Semester');    
    $secondsem = $grade->getsubject('2nd Semester');    
    
?>
   
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Semester</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Semester</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert alert-info">
                                    <th class="text-center">Subject Code</th>
                                    <th class="text-center">Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Finals</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($firstsem)): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td class="text-center"><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['status'] == 'Enrolled'){
                                if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                    $remarks = 'PASSED';
                                    $class = 'text-success';
                                }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                    $remarks = 'FAILED';
                                    $class = 'text-danger';  
                                }else{
                                    $remarks = 'No Submitted Grades';
                                    $class = 'text-danger';  
                                }
                            }else{
                                    $remarks = 'OFFICIALLY DROPPED';
                                    $class = 'text-danger';  
                                }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($firstsem) < 1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger"><strong>*** Empty ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                            
                            </div>
                        </div>
                  
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                 <thead>
                                    <tr class="alert alert-info">
                                    <th class="text-center">Subject Code</th>
                                    <th class="text-center">Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Final</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($secondsem)): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td class="text-center"><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['status'] == 'Enrolled'){
                                if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                    $remarks = 'PASSED';
                                    $class = 'text-success';
                                }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                    $remarks = 'FAILED';
                                    $class = 'text-danger';  
                                }else{
                                    $remarks = 'No Submitted Grades';
                                    $class = 'text-danger';  
                                }
                            }else{
                                    $remarks = 'OFFICIALLY DROPPED';
                                    $class = 'text-danger';  
                                }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($secondsem) < 1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger"><strong>*** Empty ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                       
                            </div>
                            
                        </div>
             
      </div>
                
               
            </div>
        </div>
       

 <hr>
    </div>
    <!-- /.container-fluid -->
    
</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');