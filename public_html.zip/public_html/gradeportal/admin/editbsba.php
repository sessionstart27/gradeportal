<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/data_model.php');
    include('data/class_model.php');
    include('data/student_modelbsba.php');
    include('data/teacher_model.php');
    $id = $_GET['id'];
    $subject = $data->getsubjectbyid($id);
    $class = $class->getclassbyid($id);
    $student = $student->getstudentbyid($id);
    $teacher = $teacher->getteacherbyid($id);
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small style="color:black;">EDIT Info</small>
                </h1>
                <?php 
                    $edit = new Edit();
                    $type = $_GET['type'];
                    if($type=='subject'){
                        $edit->editsubject($subject);
                    }else if($type=='class'){
                        $edit->editclass($class);
                    }else if($type=='bsba'){
                        $edit->editstudent($student);   
                    }else if($type=='teacher'){
                        $edit->editteacher($teacher);   
                    }
                ?>
            </div>
        </div>
        <!-- /.row -->

       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    

<?php include('include/footer.php');

class Edit {
    
    function editstudent($student){ ?>
        <ol class="breadcrumb">
            <li>
                <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
            </li>
            <li>
                <a href="bsba.php">Student's List(Business Administration)</a>
            </li>
            <li class="active">
                Edit
            </li>
        </ol>
        <hr />
            <?php while($row = mysqli_fetch_array($student)): ?>
            <form action="data/student_model.php?dept=bsba&id=<?php echo $row['id'];?>" method="post">
        <div class="modal-body" style="width:50%;margin-left:25%;margin-right:25%; width:60%;margin:0 auto;-webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
            padding:25px;
            margin-bottom:40px;
            margin-top:30px;
            border:1px solid lightgrey;
            border-radius:20px;
            background-color:white;">
            
                <div class="form-group">
                    <input type="text" class="form-control" name="studid" value="<?php echo $row['studid']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" value="<?php echo $row['firstname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" value="<?php echo $row['middlename']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" value="<?php echo $row['lastname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="course" readonly value="<?php echo $row['course']; ?>" />
                </div>
                 <div class="form-group">
                    <select name="year" class="form-control">
                        <option value="<?php echo $row['year']; ?>"><?php echo $row['year']; ?></option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="major" class="form-control">
                        <option value="<?php echo $row['major']; ?>"><?php echo $row['major']; ?></option>
                        <option value="Operations Mgt">Operations Management</option>
                        <option value="Marketing Mgt">Marketing Management</option>
                        <option value="HRDM">Human Resource Development Management</option>
                        <option value="Financial Mgt">Financial Management</option>
                        <option value="Mgt Accounting">Management Accounting</option>
                        <option value="Banking">Banking</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" value="<?php echo $row['email']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="contact" value="<?php echo $row['contact']; ?>" />
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control">
                        <option value="<?php echo $row['semester']; ?>"><?php echo $row['semester']; ?></option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="school_year" readonly value="<?php echo $row['school_year']; ?>" />
                </div>
                
            <?php endwhile; ?>
            <div class="modal-footer">
            <a href="bsba.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" class="btn btn-primary" name="updatestud"><i class="fa fa-check"></i> Update</button>
            
        </div>
            </form>
        </div>
        
    <?php    
    }
    
    
}

?>