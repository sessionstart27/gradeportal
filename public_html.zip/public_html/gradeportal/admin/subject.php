<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/data_model.php');
    
    $search = isset($_POST['search']) ? $_POST['search']: null;
    $subject = $data->getsubject($search);
?>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small style="color:black;">SUBJECT</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                        <a href="subject.php">Subject</a>
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding">
                    <form action="subject.php" method="post">
                        <input type="text" class="form-control" name="search" placeholder="Search Subject...">
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                                
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addsubject">Add Subject</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/.row -->
        <hr />   
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['r'])): ?>
                    <?php
                        $r = $_GET['r'];
                        if($r=='added'){
                            $class='success';   
                        }else if($r=='updated'){
                            $class='info';   
                        }else if($r=='deleted'){
                            $class='danger';   
                        }else if($r=='exist'){
                            $class='danger';   
                        }else{
                            $class='hide';
                        }
                    ?>
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong>Subject: <?php echo $_GET['n']; ?> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                
                <div class="table-responsive" style="overflow-x:auto;background:white;">
                    <table class="table table-striped">
                        <thead>
                            <tr style="color:white;background-color:#0067a7;">
                                <th>#</th>
                                <th>Subject Code</th>
                                <th>Subject Title</th>
                                <th class="text-center">Units</th>
                                <th class="text-center">Course</th>
                                <th class="text-center">Semester</th>
                                <th class="text-center">Remove</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($subject)): ?>                            
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><a href="editbsa.php?type=subject&id=<?php echo $row['id']?>"><?php echo $row['code'];?></a></td>
                                    <td><?php echo $row['title'];?></td>
                                    <td class="text-center"><?php echo $row['unit'];?></td>
                                    <td class="text-center"><?php echo $row['course'];?></td>
                                    <td class="text-center"><?php echo $row['semester'];?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?table=subjectbsa&id=<?php echo $row['id']?>" method="post">
                                        
                                        <button type="submit"  title="Remove" style="background: none;
                                        border:none;" name="delete"><i class="fa fa-times-circle fa-lg text-danger confirmation"></i></button> 
                                        </form>
                                        
                                </tr>
                            <?php $c++; ?>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($subject) < 1): ?>
                                <tr>
                                    <td colspan="7" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/modal.php'); ?>
<?php include('include/footer.php'); ?>