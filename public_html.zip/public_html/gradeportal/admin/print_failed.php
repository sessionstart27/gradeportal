<?php

    include('../config.php');
    include('data/subject_modeladmin.php');
    include('data/student_modeladmin.php');
    $classid = $_GET['classid'];
    $mysubject = $subject->getsubjectbyid($classid);
    
    $mystudent = $student->getstudentbyclassfail($classid);
    
    if($classid!=''){
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
           mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select class.id,class.subject,class.teacher,class.course,class.year,teacher.firstname,teacher.lastname, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code INNER JOIN teacher ON class.teacher = teacher.id where class.id=$classid");
    $rc = mysqli_fetch_array($rc);
    $title = $rc['title'];
    $teacher = $rc['firstname'].' '.$rc['lastname'];
}else{
    $title =" ";
}

?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">
    
    <title>Print Report</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        .wrapper {
            margin-top:40px !important;            
            border:0px solid #777;
            background:#fff;
            margin:0 auto;
            height: 100%;
            width: 92%;
            padding: 20px;
        }
        body {
            background:#ccc;  
        }
        img {
            max-height:150px;   
            max-width:500px;   
            margin-right:10px;
        }
        p{
            font-weight: bold;
            font-size: 16px;
        }
        @media print{
        #print{
            display:none;
        }
        }
        @page  
{ 
            size: auto;   /* auto is the initial value */ 

            /* this affects the margin in the printer settings */ 
            margin: 15mm 5mm 15mm 0mm;  
        }
        @page :first {
              margin-top: 0in; /*top margin for first page of paper*/
            }
        #print {
            width: 90px;
            height: 30px;
            font-size: 18px;
            background: green;
            border-radius: 4px;
            margin-left:8px;
            cursor:hand;
            color: white;
}
        .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
            border-top: none !important;   
        }
        
    </style>
    <script>
function printPage() {
    window.print();
}
</script>
</head>
<body>
    <div class="container wrapper">
        <div class="row">
            <div class="col-lg-12">
                
                <div class="text-center"> 
                    
                    <img src="../image/printlogo.png" height="60px;" width="440px">
                    <p style="font-size:14px;font-weight:lighter;">Nueno Ave., City of Imus</p>
                    <p style="font-size:20px;">Failed Students' List</p>
                    <button type="submit" id="print" onclick="printPage()" style="float:right;margin-top:-30px;margin-right:40px;"><i class="fa fa-print"></i>Print</button>
                    <hr />
                    <?php while($row = mysqli_fetch_array($mysubject)): ?>
                    <?php $mysubjectname = $subject->getsubjectbycode($row['subject']); ?>
                    <table class="table">
                        <tr>
                            <td style="width:13%;text-align:left;"><strong>SUBJECT:</strong></td>
                            <td style="width:*;text-align:left;"><?php echo $mysubjectname['title'];?> (<?php echo $row['subject'];?>)
                                </td>
                            <td style="width:14%;text-align:left;"><strong>DATE:</strong></td>
                            <td style="width:23%;text-align:left;"><?php echo date('F d, Y')?></td>
                        </tr>
                        <tr>
                            <td class="text-left"><strong>NO. OF UNITS:</strong></td>
                            <td class="text-left"><?php echo $mysubjectname['unit'];?> Unit(s)</td>
                            <td class="text-left"><strong>Semester / S.Y. :</strong></td>
                            <td class="text-left"><?php echo $row['semester'];?> / <?php echo $row['sy'];?></td>
                        </tr>
                    </table>                    
                    <?php endwhile; ?>
                </div>               
            </div>
        </div> 
        
        
        
        <div class="row">
            <div class="col-lg-12">                

                <div class="">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th class="text-center">Prelim</th>
                                <th class="text-center">Midterm</th>
                                <th class="text-center">Finals</th>
                                <th class="text-center">FINAL GRADE</th>
                                <th class="text-center">Remarks</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                    <?php $c=1; ?>
                    <?php while($row = mysqli_fetch_array($mystudent)): ?>
                        <tr>
                                            <td><?php echo $c; ?></td>    
                                            <td><?php echo $row['studid']; ?></td>    
                                            <td><?php echo $row['lastname'].', '.$row['firstname']; ?></td>  
                                            <td><?php echo $row['course']; ?></td>    
                                            <form action="data/grade_model.php?term=1&studid=<?php echo $row['id'];?>&classid=<?php echo $classid; ?>" method="POST">
                                            <?php $grade = $student->getstudentgrade($row['id'],$classid); ?>

                                            <td class="text-center"><?php echo $grade['prelim'];?></td>
                                
                                            <td class="text-center"><?php echo $grade['midterm'];?></td>  
                                            
                                            <td class="text-center"><?php echo $grade['final'];?></td>    
                                                
                                            <?php
                                            $var = 0;
                                            if($grade['total']>=75){ ?>
                                                <td class="text-center" style="vertical-align: middle;color:black;"><?php echo $grade['total']; ?></td>
                                            <?php }else if($grade['total']>=61 && $grade['total']<75){?>
                                                <td class="text-center" style="vertical-align: middle;color:red;"><?php echo $grade['total']; ?></td>
                                            <?php }else if($grade['total']<=60){?>
                                                <td class="text-center" style="vertical-align: middle;color:red;"><?php echo "<i>n/a</i>"; ?></td>
                                           <?php } else{
                                                hide;
                                           }?>
                                
                                <?php
                                            if($grade['status'] == 'Enrolled'){
                                                 if($grade['eqtotal']>0.0 && $grade['eqtotal']<=3.0){
                                                    $remarks = 'PASSED';
                                                    $class = 'text-success';
                                                }else if($grade['eqtotal']>3.0 && $grade['eqtotal']<=5.0){
                                                    $remarks = 'FAILED';
                                                    $class = 'text-danger';  
                                                }else{
                                                    $remarks = 'FAILED';
                                                    $class = 'text-danger';  
                                                }
                                            }else{
                                                    $remarks = 'OFFICIALLY DROPPED';
                                                    $class = 'text-danger';  
                                                }
                                            ?>
                                            <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                              </form>
                                        </tr>
                    <?php $c++; ?>
                    <?php endwhile; ?>              
                     <?php if(mysqli_num_rows($mystudent) < 1): ?>
                        <tr><td colspan="9" class="text-center text-danger"><strong>*** No Result ***</strong></td></tr>
                    <?php endif; ?>
                        </tbody>
                    </table>
                </div>        
            </div>
        </div>
        
        <br />
<br />
						<h5><strong>Signatories:</strong></h5>	<br>
                       <div style="margin-top:-5px;margin-left:80px;width:80%;text-align:center;">
                        
                        <table class="table" border="0">
                        <tr>
                            <td style="width:50%;"><strong><u><?php echo strtoupper($teacher);?></u></strong></td> 
                            <td style="width:50%;"><strong>_____________________</strong></td>
                        </tr>
                        <tr>
                            <td><strong><i>Instructor</i></strong></td>  
                            <td><strong><i>Department Head</i></strong></td>
                        </tr>
                        <tr>
                            <td><strong><i><br> </i></strong></td>  
                            <td><strong><i><br> </i></strong></td>
                        </tr>
                        <tr>
                            <td style="width:55%;"><strong><u>DR. LOIDA R. STA. MARIA</u></strong></td>
                            <td style="width:50%;"><strong><u>MRS. CORAZON RAMOS</u></strong></td> 
                        </tr>
                        <tr>
                            <td><strong><i>Vice President for Academic Affairs</i></strong></td> 
                            <td><strong><i>College Registrar</i></strong></td>
                        </tr>
                        
                        </table> 
                        </div>	

        
    </div>
    
</body>

</html>