<?php
    include('include/header.php');
    include('include/sidebar.php');

?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Message Details</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                         <a href="">Message Details</a>
                    </li>
                   
                    
                </ol>
            </div>
        </div>
        
       
    
        <div class="row">
           
        <div class="modal-body" style="width:60%;margin:0 auto;">
           <?php
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
           mysqli_select_db($con,'u588883585_grading');
    $id = $_GET['id'];

    $query1 ="UPDATE `request` SET `admin_viewed` = 'read' WHERE `id` = $id;";
    $result = mysqli_query($con,$query1) or trigger_error(mysqli_error().$query1);

    $query = "SELECT * from `request` where `id` = '$id';";
    $re = mysqli_query($con,$query) or trigger_error(mysqli_error().$query);
    while($i=mysqli_fetch_array($re)):
            
       ?>
       
      
             <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <h5><i><?php echo date('F j, Y, g:i a',strtotime($i['date_approved'])) ?></i></h5><br/> 
                </div>
                <div class="form-group">
                     <?php
                if($i['status']=='Approved'){
                    echo "<p style='text-align:justify;text-indent:15px;'>Dr. Loida R Sta. Maria (VPAA) <em style='color:steelblue;font-style: normal;'>Approved</em> the request of Mr./Mrs.: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']).". For the ".ucfirst($i['subject_title'])." subject.</p>";
                }else if($i['status']=='Denied'){
                    echo "<p style='text-align:justify;text-indent:15px;'>Dr. Loida R Sta. Maria (VPAA) <em style='color:red;font-style: normal;'>Denied</em> the request of Mr./Mrs.: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']).". For the ".ucfirst($i['subject_title'])." subject.</p>";
                }else{
                    echo "<p style='text-align:justify;text-indent:15px;'>Waiting for approval: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']).". For the ".ucfirst($i['subject_title'])." subject.</p>";
                }
    
    ?>
                </div>
                
                
        <div class="modal-footer" style="padding-right:0px;">
            <a href="index.php"><button type="button" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</button></a>
            
           
        </div>
        </form>
    <?php

?>
<?php endwhile; ?>

            </div>
        
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
    

<!-- /#page-wrapper -->    
<?php include('include/footer.php');


