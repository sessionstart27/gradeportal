<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_modeladmin.php');
    $firstsem = $subject->getsubjectfail('1st Semester');    
    $secondsem = $subject->getsubjectfail('2nd Semester');    
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Failed Grades</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="grades.php">Grades Dashboard</a>
                    </li>
                    <li class="active">
                        Failed Students' Grades
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row">
            <div class="col-lg-12">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Sem</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Sem</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert-info">
                                        <th>No.</th>
                                        <th>Subject Code</th>
                                        <th>Subject Title</th>
                                        <th>Year</th>
                                        <th class="text-center">Students</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 1; ?>
                                    <?php while($row = mysqli_fetch_array($firstsem)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>
                                            <td><?php echo $row['subject']; ?></td>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['year']; ?></td>
                                            <td class="text-center"><a href="failed_stud.php?classid=<?php echo $row['id'];?>">View Students</a></td>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($firstsem) < 1): ?>
                                        <tr><td colspan="6" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert-info">
                                        <th>No.</th>
                                        <th>Subject Code</th>
                                        <th>Subject Title</th>
                                        <th>Year</th>
                                        <th class="text-center">Students</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 1; ?>
                                    <?php while($row = mysqli_fetch_array($secondsem)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>
                                            <td><?php echo $row['subject']; ?></td>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['year']; ?></td>
                                            <td class="text-center"><a href="failed_stud.php?classid=<?php echo $row['id'];?>">View Students</a></td>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($secondsem) < 1): ?>
                                        <tr><td colspan="6" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>   
            </div>
        </div>
        <!-- /.row -->
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');