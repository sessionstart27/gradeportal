<?php
ob_start();
    include('include/header.php');
    include('include/sidebar.php');
    include('data/student_modelbscs.php');
    
    $que = mysqli_query($con,"select * from s_year where current_stat='Yes'");
    $row = mysqli_fetch_array($que);
    $current_sy = $row['school_year'];

    $s_year = isset($_POST['s_year']) ? $_POST['s_year'] : $current_sy;
    $search = isset($_POST['search']) ? $_POST['search'] : null;
    
   if(isset($_POST['submitsearch'])){ 
    $student = $student->getstudent($s_year,$search);
   }else{
    $student = $student->getstudentcourse($search);
   }
?>
<!-- Show/hide CSV upload form -->
<script>
function formToggle(ID){
    var element = document.getElementById(ID);
    if(element.style.display === "none"){
        element.style.display = "inline-block";
    }else{
        element.style.display = "none";
    }
}
</script>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">           
                <ul style="list-style-type:none">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-left:-30px;"> College of Computer Studies 
                    <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="divider"></li>
                        <li><a href="bsa.php">College of Accountancy</a></li>
                        <li class="divider"></li>
                        <li><a href="bsba.php">College of Business Administration</a></li>
                        <li class="divider"></li>
                        <li><a href="bscs.php">College of Computer Studies</a></li>
                        <li class="divider"></li>
                        <li><a href="bsed.php">College of Education, Arts & Sciences</a></li>
                        <li class="divider"></li>
                        <li><a href="bscpe.php">College of Engineering</a></li>
                        <li class="divider"></li>
                        <li><a href="bshrtm.php">College of Hospitality & Tourism Management!</a></li>
                        <li class="divider"></li>
                        <li><a href="bssw.php">College of Social Work</a></li>
                        <li class="divider"></li>
                    </ul>
                </li>
                </ul>
                    
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                        <a href="bscs.php">STUDENT'S LIST</a>
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="form-inline form-padding" style="float:left;line-height:40px;">
                    <form action="bscs.php" method="post">
                        <input type="text" style="width:20%;" class="form-control" name="search" placeholder="Search Students...">
                        <select name="s_year" class="form-control" required>
                            <option value="<?php echo $current_sy;?>" style="color:blue;font-weight:bold;"><?php echo $current_sy;?></option>                            
                            <?php $que = mysqli_query($con,"select * from s_year order by school_year DESC");
                             while($row = mysqli_fetch_array($que)): ?>
                                <option value="<?php echo $row['school_year']?>" <?php if($row['school_year']==$s_year) echo 'selected'; ?>><?php echo $row['school_year'];?></option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i> Search</button> 
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addstudent"><i class="fa fa-user"></i> Add Student</button>
                        <a href="javascript:void(0);" class="btn btn-success" onclick="formToggle('importFrm');"><i class="fa fa-upload"></i> Batch Upload</a> 
                        <a href="printbscs.php?s_year=<?php echo $s_year;?>" target="_blank"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print List</button></a><br>
                    </form>
                </div> <br>
            </div>
            <div class="col-lg-12">
                <!-- CSV file upload form --><br>
                <div class="form-inline form-padding" id="importFrm" style="display: none;">
                    <form action="importData.php?dept=bscs" method="post" enctype="multipart/form-data">
                       <input type="file" name="file" class="form-control" />
                       <button type="submit" name="import" class="btn btn-success"><i class="fa fa-upload"></i> Import</button>
                        <p style="line-height:40px;margin-bottom:-10px;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>
                           Please use<strong> .csv file </strong> to upload student list. 
                            <br></p>
                    </form>
                </div>
                </div>
        </div>
        <!--/.row -->
        <hr />   
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['r'])): ?>
                    <?php
                        $r = $_GET['r'];
                        if($r=='added'){
                            $class='success';   
                        }else if($r=='updated'){
                            $class='info';   
                        }else if($r=='deleted'){
                            $class='danger';   
                        }else if($r=='added an account'){
                            $class='success';   
                        }else if($r=='has already an account'){
                            $class='danger';   
                        }else{
                            $class='hide';
                        }
                    ?>
                    <div class="alert alert-<?php echo $class?> <?php echo $classs; ?>">
                        <strong>Student: <?php echo $_GET['n']; ?> <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <?php if(isset($_GET['s'])): ?>
                    <?php
                        $s = $_GET['s'];
                        if($s=='Already Exist!'){
                            $class='danger';   
                        }else{
                            $class='hide';
                        }
                    ?>
            </div>
            <div class="alert alert-<?php echo $class?> <?php echo $classs; ?>">
                        <strong>Student ID: <?php echo $_GET['studid']; ?> <?php echo $s; ?>!</strong>    
                </div>
                <?php endif; ?>
    <?php if(isset($_GET['msg'])): ?>
                    <?php
                        $m = $_GET['msg'];
                        if($m=='Student List Uploaded Successfully.'){
                            $class='success';   
                          
                        }else if($m=='Please Select .CSV File only'){
                            $class='danger';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                    <br>
                  <div class="alert alert-<?php echo $class?> <?php echo $class; ?>" style="margin-bottom:-5px;">
                        <strong> <?php echo $m; ?>!</strong>    
                </div>
                     <?php endif; ?><br>
            <?php if(isset($_GET['note'])): ?>
                    <?php
                        $n = $_GET['note'];
                        if($n=='Added New Student Account:'){
                            $class='success';   
                          
                        }else if($n=='Student Account Already Exist'){
                            $class='danger';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                    <br>
                 <div class="alert alert-<?php echo $class?> <?php echo $class; ?>" style="margin-bottom:-5px;">
                        <strong> <?php echo $n; ?> <?php echo $_GET['usern']; ?><?php if ($_GET['name'] != "") echo ": ". $_GET['name']; ?> !</strong>    
                </div>
                     <?php endif; ?> <br>         
        </div>
        <div class="row">
            <div class="col-lg-12">
                
                <div class="table-responsive" style="overflow-x:auto;background-color:white;">
                    <table class="table table-striped">
                        <thead>
                            <tr style="color:white;background-color:#0067a7;">
                                <th>#</th>
                                <th>Student ID</th>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Middlename</th>
                                <th>Course</th>
                                <th>Year</th>
                                <th>Email</th>
                                <th>Contact No.</th>
                                <th colspan="3" width="10%" class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($student)): ?>                            
                                <tr>
                                    <td><?php echo $c;?></td>
                                    <td><a href="editbscs.php?type=bscs&id=<?php echo $row['id']?>" title="Update Student"><?php echo $row['studid'];?></a></td>
                                    <td><?php echo $row['lastname'];?></td>
                                    <td><?php echo $row['firstname'];?></td>
                                    <td><?php echo $row['middlename'];?></td>
                                    <td><?php echo $row['course'];?></td>
                                    <td><?php echo $row['year'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <td><?php echo $row['contact'];?></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?dept=bscs&studid=<?php echo $row['studid'];?>&fname=<?php echo $row['firstname'];?>&lname=<?php echo $row['lastname'];?>" method="post" style="float:left;">
                                        
                                        <button type="submit" title="Create Login" class="confirmacc" style="background: none;
                                        border:none;" name="create"><i class="fa fa-key fa-2x text-warning"></i></button> 
                                        </form></td>
                                    <td class="text-center">
                                        <a href="studentsubjectbscs.php?id=<?php echo $row['studid'];?>&s_year=<?php echo $row['school_year'];?>" title="View Subjects"><i class="fa fa-bar-chart-o fa-2x text-success"></i></a></td>
                                    <td class="text-center">
                                        <form action="data/settings_model.php?table=student&course=bscs&id=<?php echo $row['id']?>" method="post" style="float:right;">
                                        
                                        <button type="submit"  title="Remove" style="background: none;
                                        border:none;" name="delete"><i class="fa fa-times-circle fa-2x text-danger confirmation"></i></button> 
                                        </form></td>
                                </tr>
                            <?php $c++; ?>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($student) < 1): ?>
                                <tr>
                                    <td colspan="8" class="bg-danger text-danger text-center">*** EMPTY ***</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/modal.php'); ?>
<?php include('include/footer.php'); ?>