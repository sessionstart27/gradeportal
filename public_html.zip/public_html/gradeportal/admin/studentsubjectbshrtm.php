<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/student_modelbshrtm.php');
    include('data/data_model.php');
    include('data/grade.php');
    
    $studid = $_GET['id'];
    $s_year = isset($_POST['s_year']) ? $_POST['s_year'] : $_GET['s_year'];
    
    $que = mysqli_query($con,"select * from s_year where current_stat='Yes'");
    $row = mysqli_fetch_array($que);
    $current_sy = $row['school_year'];
    
    $student = $student->getstudentbyid($s_year,$studid);

    if(isset($_POST['submitsearch'])){ 
        
        $s_year = $_POST['s_year'];
        $firstsem = $grade->getsubject($studid,$s_year,'1st Semester');    
        $secondsem = $grade->getsubject($studid,$s_year,'2nd Semester');
    }
        $firstsem = $grade->getsubject($studid,$s_year,'1st Semester');    
        $secondsem = $grade->getsubject($studid,$s_year,'2nd Semester');

?>
<style>
    label{
        border: 1px solid lightgray;padding:8px;border-radius:10px;
    }
    @media(max-width:425px){
        label{
            display: flex;
            font-size: 12px;
            text-align: center;
        }
        #subjprint{
            display: none;
        }
        select{
            margin-left: 5px;
            margin-right: 5px;
        }
    }
    
    @media(max-width:1024px){
        #searchsy{
            margin-bottom: 80px;
        }
    }
</style>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>STUDENT SUBJECT</small>
                    <a href="printgradebshrtm.php?id=<?php echo $_GET['id'];?>&s_year=<?php echo $s_year;?>" target="_blank" style="float:right;"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print Copy of Grades</button></a>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="bshrtm.php">Students</a>
                    </li>
                    <li class="active">
                        Student Subject
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
         <div class="col-lg-12" id="searchsy">
             <?php $que = mysqli_query($con,"select * from student where studid='$studid' and school_year='$s_year'");
             while($row = mysqli_fetch_array($que)): ?>
                <h5><b> &ensp;Name :</b> <?php echo $row['firstname'].' '.$row['lastname']; ?></h5>
                <h5><b>&ensp;Student ID :</b> <?php echo $row['studid']; ?></h5>
                <?php endwhile; ?>
               
             <div class="form-inline form-padding" style="float:left;">
                    <form action="studentsubjectbshrtm.php?id=<?php echo $studid;?>" method="post">
                        <b>&ensp;School Year: </b>
                        <select name="s_year" class="form-control" required>
                            <option value="<?php echo $current_sy;?>" style="color:blue;font-weight:bold;"><?php echo $current_sy;?></option>
                            <?php $que = mysqli_query($con,"select * from student where studid='$studid'");
                             while($row = mysqli_fetch_array($que)): ?>
                                <option value="<?php echo $row['school_year']?>" <?php if($row['school_year']==$s_year) echo 'selected'; ?>><?php echo $row['school_year'];?></option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i></button>
                    </form>
                </div>
            </div>

            <div class="col-lg-12">
                <hr />
                <!-- stud grades -->

   
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Semester</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Semester</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content" style="background-color:white;border-radius:0px 15px 15px 15px;padding:15px; ">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive" style="overflow-x:auto;">
                            <table class="table table-striped">
                                <thead>
                                    <tr style="color:white;background-color:#0067a7;">
                                    <th>Subject Code</th>
                                    <th>Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Finals</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($firstsem)): ?>
                            <tr>
                                <td><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['studid'],$row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                        $remarks = 'PASSED';
                                        $class = 'text-success';
                                    }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }else{
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($firstsem) < 1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger"><strong>*** Empty ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                            
                            </div>
                        </div>
                  
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                 <thead>
                                    <tr style="color:white;background-color:#0067a7;">
                                    <th>Subject Code</th>
                                    <th>Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Finals</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th class="text-center">Remarks</th>
                                    <th class="text-center">Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($secondsem)): ?>
                            <tr>
                                <td><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['studid'],$row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                        $remarks = 'PASSED';
                                        $class = 'text-success';
                                    }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }else{
                                        $remarks = 'FAILED';
                                        $class = 'text-danger';  
                                    }
                                ?>
                                <td class="text-center <?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td class="text-center"><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($secondsem) < 1): ?>
                        <tr>
                        <td colspan="10" class="text-center text-danger"><strong>*** Empty ***</strong></td>
                        </tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                       
                            </div>
                            
                        </div>
             
      </div>
            </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');