<?php
session_start();
    include('include/header.php');
    include('include/sidebar.php');

	if (isset($_POST['submit'])) {
		$con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
        mysqli_select_db($con,'u588883585_grading');

		$username = $con->real_escape_string($_POST['username']);
		$fname = $con->real_escape_string($_POST['firstname']);
		$lname = $con->real_escape_string($_POST['lastname']);
		$password = $con->real_escape_string($_POST['password']);
		$cPassword = $con->real_escape_string($_POST['cPassword']);
        
        $msg = "";
        $admin = $_SESSION['name'];
		
            $q = "select * from userdata where username='$username'";
            $r = mysqli_query($con,$q);
        if(mysqli_num_rows($r) < 1){
            if($password == $cPassword){
            $hash = password_hash($password, PASSWORD_BCRYPT);
			$con->query("INSERT INTO userdata (username,password,firstname,lastname,level) VALUES ('$username', '$hash', '$fname', '$lname', 'admin')");

                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $admin.'(Admin) created new Admin Account: '.$username;
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
                $class='success';
                $msg = "Admin Account Created!";
            }else{
                $class='danger';   
                $msg = "Password do not match!";
            }
        }else{
                $class='danger';   
               $msg = "Admin Account Already Exist!";
		}
	}
?>
<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header">
                    <i class= "fa fa-cog fa-spin"></i> Settings <small> Add / Create Admin Account</small>
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <i class="active"></i> <a href="addadmin.php" style="color:gray;">Add Admin Account</a>
                    </li>
                    <li>
                        <a href="addvpaa.php">Add VPAA Account</a>
                    </li>
                    
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row" style="width:70%;margin:auto;">
            <div class="col-lg-12" style="width:70%;margin:auto;">
                
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong><?php if ($msg != "") echo $msg . "<br>"; ?></strong>    
                    </div>
                
             
            <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
                   
                <div class="form-group">
                   <input class="form-control" name="firstname" type="text" placeholder="Firstname...">
					</div>
                <div class="form-group">
                   <input class="form-control" name="lastname" type="text" placeholder="Lastname...">
					</div>
                <div class="form-group">
                    <input class="form-control" minlength="3" name="username" placeholder="Username/ID...">
                    </div>
                <div class="form-group">
                    <input class="form-control" minlength="4" name="password" type="password" placeholder="Password...">
					</div>
                <div class="form-group">
                    <input class="form-control" minlength="4" name="cPassword" type="password" placeholder="Confirm Password..."><br>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm" name="submit" style="float:right;">Add Admin Account</button><br><br>
                </form>  
            </div>
        </div>
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');