<!-- add modal for subject -->
<div class="modal fade" id="addsubject" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add Subject</h3>
        </div>
        <div class="modal-body">
            <form action="data/settings_model.php" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="code" placeholder="subject code" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="title" placeholder="subject title" />
                </div>
                <div class="form-group">
                    <input type="number" min="1" max="5" class="form-control" name="unit" placeholder='no. of units' required />
                </div>
                <div class="form-group">
                    <select name="year_lvl" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option>All Courses (Minor)</option>
                        <option>BSA</option>
                        <option>BSBA</option>
                        <option>BSCS/BSIT</option>
                        <option>BSEE/BSSE/ABCom</option>
                        <option>BSCpE/BSECE</option>
                        <option>BSHRM/BSTM</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addsub"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for class1 info -->
<div class="modal fade" id="addclass1" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add Class Info</h3>
        </div>
        <div class="modal-body">
             
            <form action="data/settings_model.php?class=class&sem=1st Semester" method="post">
                <div class="form-group">  
                    <select name="subject" class="form-control" required>
                        <option value="">Select Subject...</option>
                       <?php 
                            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                            mysqli_select_db($con,'u588883585_grading');
                        
                            $r = mysqli_query($con,"select * from subjectbsa where semester='1st Semester' and code NOT IN (SELECT subject FROM class) order by title");
                            while($row = mysqli_fetch_array($r)):
                        ?>
                            <option value="<?php echo $row['code']; ?>"> <?php echo $row['title']; ?> - (<?php echo $row['course']; ?>) (<?php echo $row['year']; ?>)</option>
                        <?php endwhile; ?>
                      
                    </select>
                </div>
                    
                
                <div class="form-group">  
                    <select name="teacher" class="form-control" required>
                        <option value="">Select Teacher...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                            mysqli_select_db($con,'u588883585_grading');
                        $r2 = mysqli_query($con,"select * from teacher");
                        while($row = mysqli_fetch_array($r2)):
                    ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['firstname'].' '.$row['lastname']; ?></option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Class...</option>
                        <option>All Courses (Minor)</option>
                        <option>BSA</option>
                        <option>BSBA</option>
                        <option>BSCS/BSIT</option>
                        <option>BSEE/BSSE/ABCom</option>
                        <option>BSCpE/BSECE</option>
                        <option>BSHRM/BSTM</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year level...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                        <option>5th Year</option>
                        <option>Mixed(1st - 5th year)</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="sy" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addclass"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for class2 info -->
<div class="modal fade" id="addclass2" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add Class Info</h3>
        </div>
        <div class="modal-body">
            <form action="data/settings_model.php?class=class2&sem=2nd Semester" method="post">
                <div class="form-group">  
                    <select name="subject" class="form-control" required>
                        <option value="">Select Subject...</option>
                       <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                            mysqli_select_db($con,'u588883585_grading');
                            $r = mysqli_query($con,"select * from subjectbsa where semester='2nd Semester' and code NOT IN (SELECT subject FROM class) order by title");
                            while($row = mysqli_fetch_array($r)):
                         
                    ?>
                            <option value="<?php echo $row['code']; ?>"> <?php echo $row['title']; ?> - (<?php echo $row['course']; ?>) (<?php echo $row['year']; ?>)</option>
                        <?php endwhile; ?>
                      
                    </select>
                </div>
                    
                
                <div class="form-group">  
                    <select name="teacher" class="form-control" required>
                        <option value="">Select Teacher...</option>
                    <?php 
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                            mysqli_select_db($con,'u588883585_grading');
                        $r2 = mysqli_query($con,"select * from teacher");
                        while($row = mysqli_fetch_array($r2)):
                    ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['firstname'].' '.$row['lastname']; ?></option>
                    <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Class...</option>
                        <option>All Courses (Minor)</option>
                        <option>BSA</option>
                        <option>BSBA</option>
                        <option>BSCS/BSIT</option>
                        <option>BSEE/BSSE/ABCom</option>
                        <option>BSCpE/BSECE</option>
                        <option>BSHRM/BSTM</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year level...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                        <option>5th Year</option>
                        <option>Mixed(1st - 5th year)</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="sy" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addclass"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for BSCS student -->
<div class="modal fade" id="addstudent" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bscs" method="post">
                 <table><tr> <td style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSCS">BS Computer Science</option>
                        <option value="BSIT">BS Information Technology</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for bsa student -->
<div class="modal fade" id="addstudentbsa" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bsa" method="post">
               <table><tr> <td style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSA">BS Accountancy</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
               <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            
        </div></form>
    </div>
  </div>
</div>

<!-- add modal for bsba student -->
<div class="modal fade" id="addstudentbsba" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bsba" method="post">
                 <table><tr> <td colspan="3" style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div></td></tr>
                <tr>
                <td style="width:300px;">
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSBA">BS Business Administration</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="major" class="form-control" required>
                        <option value="">Select Major...</option>
                        <option value="Operations Mgt">Operations Management</option>
                        <option value="Marketing Mgt">Marketing Management</option>
                        <option value="HRDM">Human Resource Development Management</option>
                        <option value="Financial Mgt">Financial Management</option>
                        <option value="Mgt Accounting">Management Accounting</option>
                        <option value="Banking">Banking</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for bsed student -->
<div class="modal fade" id="addstudentbsed" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bsed" method="post">
               <table><tr> <td colspan="3" style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div></td></tr>
                <tr>
                <td style="width:300px;">
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSEE">BS Elementary Education</option>
                        <option value="BSSE">BS Secondary Education</option>
                        <option value="ABCom">Bachelor of Arts in Communication</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="major" class="form-control" required>
                        <option value="">Select Major...</option>
                        <option value="Special Education">Special Education</option>
                        <option value="Early Childhood">Early Childhood Education</option>
                        <option value="English">English</option>
                        <option value="Filipino">Filipino</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Physical Science">Physical Science</option>
                        <option value="Biological Science">Biological Science</option>
                        <option value=" ">N/A</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for bscpe student -->
<div class="modal fade" id="addstudentbscpe" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bscpe" method="post">
                <table><tr> <td style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSCpE">BS Computer Engineering</option>
                        <option value="BSECE">BS Electronics & Communication Engineering</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                        <option>5th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- add modal for bshrtm student -->
<div class="modal fade" id="addstudentbshrtm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-sm" style="width:600px;">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Student</h3>
        </div>
        <div class="modal-body">
            <form action="data/student_model.php?dept=bshrtm" method="post">
                <table><tr> <td style="width:300px;"><div class="form-group">
                    <input type="text" class="form-control" name="studid" placeholder="student ID" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <select name="course" class="form-control" required>
                        <option value="">Select Course...</option>
                        <option value="BSHRM">BS Hotel & Restaurant Management</option>
                         <option value="BSTM">BS Tourism Management</option>
                    </select>
                </div>
                </td>
                <td style="width:20px;">  </td>
                <td style="width:300px;">
                <div class="form-group">
                    <select name="year" class="form-control" required>
                        <option value="">Select Year...</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="semester" class="form-control" required>
                        <option value="">Select Semester...</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="school_year" class="form-control" required>
                        <option value="">Select S.Y.</option>
                        <?php $year = date('Y'); ?>
                        <?php for($c=3; $c > 0; $c--): ?>
                        <option value="<?php echo $year; ?>-<?php echo $year+1?>"><?php echo $year; ?>-<?php echo $year+1?></option>
                        <?php $year--; ?>
                        <?php endfor; ?>
                    </select>
                </div>
                </td></tr></table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addstudent"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>



<!-- add modal for teacher -->
<div class="modal fade" id="addteacher" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Add Teacher</h3>
        </div>
        <div class="modal-body">
            <form action="data/settings_model.php?" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="teachid" placeholder="teacher ID" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="firstname" placeholder="firstname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="middlename" placeholder="middlename" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="lastname" placeholder="lastname" required/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="email" required/>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" name="contact" placeholder="contact" required/>
                </div>
                <div class="form-group">
                    <select name="department" class="form-control" required>
                        <option value="">Select Department...</option>
                        <option>Accountancy</option>
                        <option>Business Administration</option>
                        <option>Computer Studies</option>
                        <option>Engineering</option>
                        <option>Education, Arts & Sciences</option>
                        <option>Hospitality & Tourism Management</option>
                    </select>
                </div>
                
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="addTeacher"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>

<!-- modal for request -->
<div class="modal fade" id="request" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user"></i> Request Approval</h3>
        </div>
        <div class="modal-body">
            <form action="data/teacher_model.php?q=addteacher" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" name="teacher" placeholder="teacher's name" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subjtitle" placeholder="subject title" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subjcode" placeholder="subject code" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="request" placeholder="request" required/>
                </div>
                <button type="submit" name="submit1" class="btn btn-success"><i class="fa fa-upload"></i> Attach File</button>
                
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add</button>
            </form>
        </div>
    </div>
  </div>
</div>