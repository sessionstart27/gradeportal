<?php 
    include('../config.php'); 
    $level = isset($_SESSION['level']) ? $_SESSION['level']: null;
    if($level == null){
        header('location:../index.php');
    }else if($level != 'admin'){
        header('location:../'.$level.'');
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>  

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../image/ii.png" sizes="16x16" type="images/png">
    
    <title>Admin Panel - Online Grading System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  <style>
         
.dropdown-item{
    color:steelblue;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    text-decoration: none;
}
 .dropdown-item:hover {
    color:gray;
    text-decoration: none;
}
        
    .dropdown-menu {
    height: auto;
    max-height: 180px;
    overflow-x: hidden;
}
    .dropdown-menu::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 4px;        
}    
    .dropdown-menu::-webkit-scrollbar-thumb {
    border-radius: 3px;
    background-color: lightgray;
    -webkit-box-shadow: 0 0 1px rgba(255,255,255,.75);        
}

#sicon{
    background-color:blue;
    font-size:xx-small;
    position: absolute;
    padding:6px;
    top: 5px;
    right: -1px;
}
    </style>   
  
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <img src="banner.png" height="48px" width="350px" style="margin-left:15px;float:left;" class="logo">
                <img src="banner2.png" class="logo1">
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">                
                
            <li class="dropdown" style="float:right;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Welcome back,  <?php echo $_SESSION['name']; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="mailer.php"><i class= "fa fa-envelope"></i> Send e-mail</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
                
            <li class="nav-item dropdown">
            <a class="nav-link" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php
                $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                mysqli_select_db($con,'u588883585_grading');
                $re = mysqli_query($con,"SELECT count(*) from `request` where admin_viewed = 'unread' and status != 'Waiting for Approval'") or die( mysqli_error());
                $countr = mysqli_fetch_array($re);
                
                if($countr > 0){
                    
                ?>
                
            
                    <i class="fa fa-bell" style="font-size:18px;"></i>
                <span class="badge badge-light" id="sicon"><?php echo $countr[0]; ?></span>
              <?php
                }
                    ?>
              </a> 
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="padding:10px; width:300px;">
                <?php
                $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                mysqli_select_db($con,'u588883585_grading');
                $query = mysqli_query($con,"select * from `request` where status != 'Waiting for Approval' order by `date_approved` DESC LIMIT 0,20");
                

                while($i=mysqli_fetch_array($query)):
                ?>
              <a style ="
                         <?php
                            if($i['admin_viewed'] == 'unread'){
                                echo "font-weight:bold;";
                                echo "font-size:14px;";
                            }else{
                                echo "color:gray";
                            }
                         ?>
                         " class="dropdown-item" href="messageApproval.php?id=<?php echo $i['id'] ?>">
                <small><i><?php echo date('F j, Y, g:i a',strtotime($i['date_approved'])) ?></i></small><br/>
                  <?php 
                  
                if($i['status']=='Approved'){
                    echo "VPAA Approved the request of: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']);
                }else if($i['status']=='Denied'){
                    echo "VPAA Denied the request of: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']);
                }else{
                    echo "Waiting for approval: ".ucfirst($i['teacher_name']) ."'s ".ucfirst($i['request']);
                }
                ?>
                
              <div class="divider"></div>
              <?php endwhile; ?>
              <?php if(mysqli_num_rows($query) < 1): 
                echo"<p style='text-align:center;color:red;'>*** No Available Message ***</p>"; ?>
                <div class="divider"></div>
              <?php endif; ?>
                </a> 
               
            </div>
          </li>
    
            </ul>
          