<?php
    include('include/header.php');
    include('include/sidebar.php');  

    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error('u588883585_grading'));
     mysqli_select_db($con,'u588883585_grading');
     
    $que = mysqli_query($con,"select * from s_year where current_stat='Yes'");
    $row = mysqli_fetch_array($que);
    $current_sy = $row['school_year'];
     
    $r1 = mysqli_query($con,"select count(*) from student where course='BSA' and school_year='$current_sy'");
    $count1 = mysqli_fetch_array($r1);

    $r2 = mysqli_query($con,"select count(*) from student where course='BSBA' and school_year='$current_sy'");
    $count2 = mysqli_fetch_array($r2);

    $r3 = mysqli_query($con,"select count(*) from student where (course='BSCS' and school_year='$current_sy') or (course='BSIT' and school_year='$current_sy')");
    $count3 = mysqli_fetch_array($r3);

    $r4 = mysqli_query($con,"select count(*) from student where (course='BSSE'  and school_year='$current_sy') or (course='BSEE' and school_year='$current_sy') or (course='ABCom' and school_year='$current_sy')");
    $count4 = mysqli_fetch_array($r4);

    $r5 = mysqli_query($con,"select count(*) from student where (course='BSCpE' and school_year='$current_sy') or (course='BSECE' and school_year='$current_sy')");
    $count5 = mysqli_fetch_array($r5);

    $r6 = mysqli_query($con,"select count(*) from student where (course='BSHRM' and school_year='$current_sy') or (course='BSTM' and school_year='$current_sy')");
    $count6 = mysqli_fetch_array($r6);
    
    $r7 = mysqli_query($con,"select count(*) from student where (course='BSSW' and school_year='$current_sy')");
    $count7 = mysqli_fetch_array($r7);

?>
<style>
    @media(max-width:1024px){
        .adjust-sm{
            width:80%;
            float:right;
        }
       
    }
   
    
   
</style>
<div id="page-wrapper" style="background:url(../image/abstract.png);">    
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                Admin Panel    <small> IIST Grade Portal </small>
                   
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard - Statistics Overview
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/bsa.jpg" height="70px" width="70px" style="border-radius:50px;">
                                
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count1[0]; ?></div>
                                <div class="adjust-sm"><p style="font-size:20px;">College of Accountancy</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bsa.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                               <img src="../image/bscpe.jpg" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count2[0]; ?></div>
                                <div><p style="font-size:20px;">College of Business Administration</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bsba.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/bsba.jpg" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count3[0]; ?></div>
                                <div><p style="font-size:20px;">College of Computer Studies</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bscs.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/study.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count4[0]; ?></div>
                                <div><p style="font-size:20px;">College of Education, Arts & Sciences</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bsed.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/bscs.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count5[0]; ?></div>
                                <div class="adjust-sm"><p style="font-size:20px;">College of Engineering</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bscpe.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/student1.jpg" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count6[0]; ?></div>
                                <div><p style="font-size:20px;">College of Hospitality & Tourism Mngmt.</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bshrtm.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/bsed.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count7[0]; ?></div>
                                <div><p style="font-size:20px;">College of Social Work</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="bssw.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>

        </div>
        <!-- /.row -->



    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');