<?php
    include('include/header.php');
    include('include/sidebar.php');  
    
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
          mysqli_select_db($con,'u588883585_grading');
    $r1 = mysqli_query($con,'select count(DISTINCT teacher) from studentsubject where total=" "');
    $count1 = mysqli_fetch_array($r1);

    $r2 = mysqli_query($con,'select count(*) from student where course="BSBA"');
    $count2 = mysqli_fetch_array($r2);
    
    $r3 = mysqli_query($con,'select count(DISTINCT classid) from studentsubject where total=" "');
    $count3 = mysqli_fetch_array($r3);

    $r4 = mysqli_query($con,'select count(DISTINCT studid) from studentsubject where total>0 && total<75');
    $count4 = mysqli_fetch_array($r4);

    

?>
<style>
    @media(max-width:1024px){
        .adjust-sm{
            width:70%;
            float:right;
        }
       
    }
</style>
<div id="page-wrapper">    
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                Grades <small> Dashboard </small>
                   
                </h1>
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="glyphicon glyphicon-tasks"></i><a href="grades.php"> Overview</a>
                    </li>
                    <li class="active">
                         
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            
            <div class="col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/lateteacher.jpg" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count1[0]; ?></div>
                                <div><p style="font-size:20px;">Late Submission of Grades (Teacher)</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="latesub.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/update.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><br></div>
                                <div class="adjust-sm"><p style="font-size:20px;">Update Student Grades</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="updategrade_subj.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/inc.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count3[0]; ?></div>
                                <div><p style="font-size:20px;">Incomplete Grades (Per Subject)</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="incomplete.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/students.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count4[0]; ?></div>
                                <div class="adjust-sm"><p style="font-size:20px;">Failed Students List</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="failed.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.row -->



    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');