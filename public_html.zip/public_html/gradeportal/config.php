<?php
if(!isset($_SESSION)) 
    { 
    session_start();
    $host = 'localhost';
    $user = 'u588883585_iistph';
    $password = 'Iist6801';
    $db = 'u588883585_grading';

    $con = mysqli_connect($host,$user,$password) or die(mysqli_error($db));
    mysqli_select_db($con,$db);
    
    
}
?>
