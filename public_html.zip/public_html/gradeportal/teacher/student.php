<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_model.php');
    include('data/student_model.php'); 
    
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
             
    $mysubject = $subject->getallsubject($id); 
    $classid = isset($_GET['classid']) ? $_GET['classid'] : null;    
    $search = isset($_POST['search']) ? $_POST['search'] : null;    
    if(isset($_POST['search'])){
        $classid = $_POST['search'];   
        $mystudent = $student->getstudentbysearch($classid,$search);
    }else{
        $mystudent = $student->getstudentbyclass($classid);
    }
if($classid!=''){
    $rc = mysqli_query($con,"select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.id=$classid");
    $rc = mysqli_fetch_array($rc);
    $title = $rc['title'];
}else{
    $title =" ";
}

?>
<style>
        @media (max-width:425px){
        #printer{
            display:none;
        }
    }
</style>
<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small style="color:black;">MY STUDENTS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="subject.php">My Subjects</a>
                    </li>
                   
                    <li class="active">
                         Class Students (Subject: <?php echo $title; ?>)
                        
                    </li>
                </ol>
            </div>
        </div>
        
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <?php if(isset($_GET['status'])): ?>
                    <?php
                        $r = $_GET['status'];
                        if($r=='Student Grade Updated'){
                            $class='success';   
                          
                        }else if($r=='Edit Grade Feature not Allowed. Please contact Administrator'){
                            $class='danger';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong> <?php echo $r; ?> <?php echo $_GET['studno']; ?> : <?php echo $_GET['name']; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <div class="form-inline form-padding" style="float:left;line-height:40px;">
                    <form action="student.php?classid=<?php echo $classid?>" method="post">
                        
                        <select name="search" class="form-control" required>
                            <option value="">Select Subject...</option>                            
                            <?php while($row = mysqli_fetch_array($mysubject)): ?>
                                <option value="<?php echo $row['id']?>" <?php if($row['id']==$classid) echo 'selected'; ?>><?php echo $row['subject'];?></option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>                       
                        <a href="print.php?classid=<?php echo $classid; ?>" target="_blank" id="printer"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Print Preview</button></a>
                       
                         <a href="request.php?classid=<?php echo $classid; ?>&title=<?php echo $title; ?>" target="_blank"><button type="button" name="submit" class="btn btn-success"><i class="fa fa-print"></i> Request Approval</button></a>
                    </form>
                    
                </div>
                <br>
             
               
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li>
                        <?php
                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                        mysqli_select_db($con,'u588883585_grading');
                            $deadline = mysqli_query($con,"select * from deadline");
                            $deadline = mysqli_fetch_array($deadline);
                            $deadline1 = $deadline['prelim'];
                            $deadline2 = $deadline['midterm'];
                            $deadline3 = $deadline['final'];
                            $stat1 = $deadline['prelim_stat'];
                            $stat2 = $deadline['midterm_stat'];
                            $stat3 = $deadline['final_stat'];
                            $access1 = $deadline['access_prelim'];
                            $access2 = $deadline['access_midterm'];
                            $access3 = $deadline['access_final'];
                            date_default_timezone_set('Asia/Manila');
                            $currentdate = date('Y-m-d');
                        ?>
                         <?php if($currentdate <= $deadline1 && $stat1 =='Unlock'){ ?>
                                <?php if($currentdate <= $deadline1 && $access1 == $_SESSION['id']){ ?>
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;">
                                    <strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Prelim grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline1; ?></strong>, any alteration of student grade will not be allowed after the deadline!  </p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong> </p>
                                            
                                <?php } elseif($currentdate <= $deadline1 && $access1 == 'Everyone'){ ?>
                                    <strong style="color:red;"> NOTE:</strong> <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Prelim grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline1; ?></strong>, any alteration of student grade will not be allowed after the deadline!</p>  
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong> </p>
                                            
                                <?php }else{ ?>
                                                
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp;Submit student grade <strong>On or Before</strong> the set deadline, any alteration of student grade will not be allowed!</p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong></p>
                                <?php } ?>  
                        
                            
                        
                            <?php }else if($currentdate <= $deadline2 && $stat2 =='Unlock'){ ?>
                            <?php if($currentdate <= $deadline2 && $access2 == $_SESSION['id']){ ?>
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Midterm grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline2; ?></strong>, any alteration of student grade will not be allowed after the deadline!</p>  
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong> </p>
                                            
                                <?php } elseif($currentdate <= $deadline2 && $access2 == 'Everyone'){ ?>
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Midterm grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline2; ?></strong>, any alteration of student grade will not be allowed after the deadline!  </p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong> </p>
                                            
                                <?php }else{ ?>
                                                
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit student grade <strong>On or Before</strong> the set deadline, any alteration of student grade will not be allowed!</p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong></p>
                                <?php } ?>  
                        
                        
                            <?php }else if($currentdate <= $deadline3 && $stat3 =='Unlock'){ ?>
                             <?php if($currentdate <= $deadline3 && $access3 == $_SESSION['id']){ ?>
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Final grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline3; ?></strong>, any alteration of student grade will not be allowed after the deadline!  </p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong> </p>
                                            
                                <?php } elseif($currentdate <= $deadline3 && $access3 == 'Everyone'){ ?>
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit Final grades <strong>On or Before </strong> <strong style="color:red;font-size:18px;"><?php echo $deadline3; ?></strong>, any alteration of student grade will not be allowed after the deadline! </p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong></p>
                                            
                                <?php }else{ ?>
                                                
                                    <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp; Submit student grade <strong>On or Before</strong> the set deadline, any alteration of student grade will not be allowed!</p>
                                    <p style="text-align:justify;"><strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong></p>
                                <?php } ?>  
                        
                            <?php }else{ ?>
                            <strong style="color:red;"> NOTE:</strong><p style="text-align:justify;">
                            <strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong>&emsp;Submit student grade <strong>On or Before</strong> the set deadline, any alteration of student grade will not be allowed!</p>
                             <p style="text-align:justify;">
                            <strong style="color:red;" class="glyphicon glyphicon-exclamation-sign"> </strong> &emsp;Input Grades must be absolute grades which ranges from <strong> 50 - 100.</strong></p>
                        <?php } ?> 
                         
                
                    </li>
                    
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">                

                <div class="table-responsive" style="overflow-x:auto;width:100%;background-color:white;padding:12px;">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr style="color:white;background-color:#0067a7;">
                                <th>No.</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th class="text-center">Prelim</th>
                                <th class="text-center">Midterm</th>
                                <th class="text-center">Final</th>
                                <th class="text-center">FINAL GRADE</th>
                                <th class="text-center">Equivalent</th>
                                <th class="text-center">Submit Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c = 1; ?>
                            <?php while($row = mysqli_fetch_array($mystudent)): ?>
                                        <tr>
                                            <td style="vertical-align: middle;"><?php echo $c; ?></td>    
                                            <td style="vertical-align: middle;"><?php echo $row['studid']; ?></td>    
                                            <td style="vertical-align: middle;"><?php echo $row['lastname'].', '.$row['firstname']; ?></td>  
                                            <td style="vertical-align: middle;"><?php echo $row['course']; ?></td>    
                                            <form action="data/grade_model.php?term=1&studid=<?php echo $row['id'];?>&classid=<?php echo $classid; ?>&studno=<?php echo $row['studid']; ?>&ssid=<?php echo $_SESSION['name']; ?>" method="POST">
                                            <?php $grade = $student->getstudentgrade($row['id'],$classid); ?>
                                             
                                            <?php
                                            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                                            mysqli_select_db($con,'u588883585_grading');
                                            $id = $_SESSION['id'];
                                            $deadline = mysqli_query($con,"select * from deadline");
                                            $deadline = mysqli_fetch_array($deadline);
                                            $deadline1 = $deadline['prelim'];
                                            $deadline2 = $deadline['midterm'];
                                            $deadline3 = $deadline['final'];
                                            $stat1 = $deadline['prelim_stat'];
                                            $stat2 = $deadline['midterm_stat'];
                                            $stat3 = $deadline['final_stat'];
                                            $access1 = $deadline['access_prelim'];
                                            $access2 = $deadline['access_midterm'];
                                            $access3 = $deadline['access_final'];
                                            date_default_timezone_set('Asia/Manila');
                                            $currentdate = date('Y-m-d');
                                            ?>
                                                
                                    <?php if($currentdate <= $deadline1 && $stat1 =='Unlock'){ ?>
                                                <?php if($currentdate <= $deadline1 && $access1 == $_SESSION['id']){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['prelim'];?>" name="prelims" style="width:auto;"/></td>
                                            
                                                <?php } else if($currentdate <= $deadline1 && $access1 == 'Everyone'){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['prelim'];?>" name="prelims" style="width:auto;"/></td>
                                            
                                                <?php }else{ ?>
                                                
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['prelim'];?>" name="prelims" style="width:auto;" readonly/></td>
                                                <?php } ?>  
                                                
                                            <?php }else{ 
                                            $q = "update deadline set prelim_stat='Lock', access_prelim='None'";
                                            mysqli_query($con,$q);?>
                                                
                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['prelim'];?>" name="prelims" style="width:auto;" readonly/></td>
                                            <?php } ?>  
                                                
                                            
                                            
                                    <?php  if($currentdate <= $deadline2 && $stat2 =='Unlock'){ ?>  
                                                <?php if($currentdate <= $deadline2 && $access2 == $_SESSION['id']){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['midterm'];?>" name="midterms" style="width:auto;"/></td>
                                                
                                                <?php } else if($currentdate <= $deadline2 && $access2 == 'Everyone'){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['midterm'];?>" name="midterms" style="width:auto;"/></td>
                                            
                                                 <?php }else{ ?>
                                                
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['midterm'];?>" name="midterms" style="width:auto;" readonly/></td>  
                                                <?php } ?>  
                                                
                                            <?php }else{
                                            $q = "update deadline set midterm_stat='Lock', access_midterm='None'";
                                            mysqli_query($con,$q);?>
                                                
                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['midterm'];?>" name="midterms" style="width:auto;" readonly/></td>  
                                            <?php } ?>  
                                                
                                                
                                    <?php  if($currentdate <= $deadline3 && $stat3 =='Unlock'){ ?>
                                                <?php if($currentdate <= $deadline3 && $access3 == $_SESSION['id']){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['final'];?>" name="finals" style="width:auto;"/></td>  
                                                
                                                <?php } else if($currentdate <= $deadline3 && $access3 == 'Everyone'){ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['final'];?>" name="finals" style="width:auto;"/></td>  
                                            
                                               <?php }else{ ?>
                                                <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['final'];?>" name="finals" style="width:auto;" readonly/></td>    
                                                <?php } ?>     
                                                
                                    <?php }else{
                                            $q = "update deadline set final_stat='Lock', access_final='None'";
                                            mysqli_query($con,$q);?>
                                                   
                                            <td class="text-center"><input type="number" min=0 max=100 class="form-control" value="<?php echo $grade['final'];?>" name="finals" style="width:auto;" readonly/></td>    
                                            <?php } ?>  
                                            
                                    <!-- end of restriction part -->
                                    <!-- start on total & equivalent part/ div -->
                                    <?php
                                    $var = 0;
                                    if($grade['total']>=75){ ?>
                                        <td class="text-center" style="vertical-align: middle;color:black;"><?php echo $grade['total']; ?></td>
                                    <?php }else if($grade['total']>=61 && $grade['total']<75){?>
                                        <td class="text-center" style="vertical-align: middle;color:red;"><?php echo $grade['total']; ?></td>
                                    <?php }else if($grade['total']<=60){?>
                                        <td class="text-center" style="vertical-align: middle;color:red;"><?php echo "<i>n/a</i>"; ?></td>
                                   <?php } else{
                                        hide;
                                   }?>
                                            
                                    <?php
                                    $var = 0;
                                    if($grade['total']>=75){ ?>
                                        <td class="text-center" style="vertical-align: middle;color:black;"><?php echo $grade['eqtotal']; ?></td>
                                    <?php }else if($grade['total']>=61 && $grade['total']<75){?>
                                        <td class="text-center" style="vertical-align: middle;color:red;"><?php echo $grade['eqtotal']; ?></td>
                                    <?php }else if($grade['total']<=60){?>
                                        <td class="text-center" style="vertical-align: middle;color:red;"><?php echo "<i>n/a</i>"; ?></td>
                                   <?php } else{
                                        hide;
                                   }?>        
                                            <td class="text-center"><button type="submit" class="btn btn-success">Submit</button>
                                            </td>    </form>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($mystudent) < 1): ?>
                                        <tr><td colspan="10" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                        
                    </table>
                </div>        
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');