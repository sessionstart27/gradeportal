<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_model.php');
    
    $que = mysqli_query($con,"select * from s_year where current_stat='Yes'");
    $row = mysqli_fetch_array($que);
    $current_sy = $row['school_year'];

    $s_year = isset($_POST['s_year']) ? $_POST['s_year'] : $current_sy;
    $search = isset($_POST['search']) ? $_POST['search'] : null;
    
   if(isset($_POST['submitsearch'])){ 
    $firstsem = $subject->getsubject('1st Semester',$id,$s_year);    
    $secondsem = $subject->getsubject('2nd Semester',$id,$s_year);    
   }

    $firstsem = $subject->getsubject('1st Semester',$id,$s_year);    
    $secondsem = $subject->getsubject('2nd Semester',$id,$s_year);        
?>
<style>
    label{
        border: 1px solid lightgray;padding:8px;border-radius:10px;
    }
    @media(max-width:425px){
        label{
            display: flex;
            font-size: 12px;
            text-align: center;
        }
        #subjprint{
            display: none;
        }
        select{
            margin-left: 5px;
            margin-right: 5px;
        }
    }
    
    @media(max-width:1024px){
        #searchsy{
            margin-bottom: 80px;
        }
    }
</style>

<div id="page-wrapper" style="background:url(../image/abstract.png);">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small style="color:black;">MY SUBJECTS</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li class="active">
                        My Subjects
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
         <div class="row">
            <div class="col-lg-12" id="searchsy">
             <div class="form-inline form-padding" style="float:left;">
                    <form action="subject.php" method="post">
                        <label>School Year: 
                        <select name="s_year" class="form-control" required>
                            <option value="" style="color:blue;font-weight:bold;"><?php echo $current_sy;?></option>
                            <?php $que = mysqli_query($con,"select DISTINCT(sy) from class where teacher='$id'");
                             while($row = mysqli_fetch_array($que)): ?>
                                <option value="<?php echo $row['sy']?>" <?php if($row['sy']==$s_year) echo 'selected'; ?>><?php echo $row['sy'];?></option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" name="submitsearch" class="btn btn-primary"><i class="fa fa-search"></i></button></label> &emsp;<a href="printsubj.php?s_year=<?php echo $s_year; ?>" target="_blank"><button type="button" name="submit" id="subjprint" class="btn btn-success"><i class="fa fa-print"></i> Print List</button></a><br>
                    </form>
                </div>
            </div>
            <div class="col-lg-12"><hr>

                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Semester</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Semester</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content" style="background-color:white;border-radius:0px 15px 15px 15px;padding:15px; ">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive" style="overflow-x:auto;">
                            <table class="table table-striped">
                                <thead>
                                    <tr style="color:white;background-color:#0067a7;">
                                        <th>No.</th>
                                        <th>Subject Code</th>
                                        <th>Subject Title</th>
                                        <th>Year Level</th>
                                        <th>School Year</th>
                                        <th class="text-center">Students</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 1; ?>
                                    <?php while($row = mysqli_fetch_array($firstsem)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>
                                            <td><?php echo $row['subject']; ?></td>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['year']; ?></td>
                                            <td><?php echo $row['sy']; ?></td>
                                            <td class="text-center"><a href="student.php?classid=<?php echo $row['id'];?>">View Students</a></td>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($firstsem) < 1): ?>
                                        <tr><td colspan="7" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr style="color:white;background-color:#0067a7;">
                                        <th>No.</th>
                                        <th>Subject Code</th>
                                        <th>Subject Title</th>
                                        <th>Year Level</th>
                                        <th>School Year</th>
                                        <th class="text-center">Students</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $c = 1; ?>
                                    <?php while($row = mysqli_fetch_array($secondsem)): ?>
                                        <tr>
                                            <td><?php echo $c; ?></td>
                                            <td><?php echo $row['subject']; ?></td>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['year']; ?></td>
                                            <td><?php echo $row['sy']; ?></td>
                                            <td class="text-center"><a href="student.php?classid=<?php echo $row['id'];?>">View Students</a></td>
                                        </tr>
                                    <?php $c++; ?>
                                    <?php endwhile; ?>
                                    <?php if(mysqli_num_rows($secondsem) < 1): ?>
                                        <tr><td colspan="7" class="text-center text-danger"><strong>*** EMPTY ***</strong></td></tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>   
            </div>
        </div>
        <!-- /.row -->
       


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');