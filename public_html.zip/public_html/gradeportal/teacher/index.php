<?php
    include('include/header.php');
    include('include/sidebar.php');

    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
    $tmp = $_SESSION['id'];
    $q = "select * from teacher where teachid='$tmp'";
    $r = mysqli_query($con,$q);
    $result = mysqli_fetch_array($r);
    $teachid = $result[0];

    $r1 = mysqli_query($con,"select count(DISTINCT classid) from studentsubject where teacher=$teachid");
    $count1 = mysqli_fetch_array($r1);

    $r2 = mysqli_query($con,"select * from class where teacher=$teachid");
    $students = 0;
    while($row = mysqli_fetch_array($r2)){
        $id = $row['id'];   
        $r3 = mysqli_query($con,"select count(*) from studentsubject where classid=$id");
        $count3 = mysqli_fetch_array($r3);
        $students = $students + $count3[0];
    }

?>
<div id="page-wrapper" style="background:url(../image/abstract.png);height:550px;">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
           
            <div class="col-lg-12">
                <h1 class="page-header">
                    Dashboard <small>Statistics Overview</small>
                </h1>
               
                <ol class="breadcrumb">
                    <li class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </li>
                </ol>
            </div>
   
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                               <img src="../image/subject.jpg" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $count1[0];?></div>
                                <div><p style="font-size:20px;">Subjects!</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="subject.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <img src="../image/student.png" height="70px" width="70px" style="border-radius:50px;">
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $students; ?></div>
                                <div><p style="font-size:20px;">Students!</p></div>
                            </div>
                        </div>
                    </div>
                    <a href="student.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right fa-2x"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>            
        </div>
        <!-- /.row -->
        

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');