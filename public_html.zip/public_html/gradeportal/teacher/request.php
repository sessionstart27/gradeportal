<?php
    include('include/header.php');
    include('include/sidebar.php');
    include('data/subject_model.php');
    include('data/student_model.php'); 
    include('../vpaa/updownload.php');
    
    $mysubject = $subject->getallsubject($id); 
    $classid = isset($_GET['classid']) ? $_GET['classid'] : null;    
    $search = isset($_POST['search']) ? $_POST['search'] : null;    
    if(isset($_POST['search'])){
        $classid = $_POST['search'];   
        $mystudent = $student->getstudentbysearch($classid,$search);
    }else{
        $mystudent = $student->getstudentbyclass($classid);
    }
if($classid!=''){
    $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
    $rc = mysqli_query($con,"select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.id=$classid");
    $rc = mysqli_fetch_array($rc);
    $title = $rc['title'];
    $code = $rc['subject'];
}else{
    $title =" ";
}

?>
<style>
    @media(max-width:768px){
        #contains{
            width:90%;margin:auto;
        }
        #contains2{
            width:90%;margin:auto;
        }
    }
     @media(min-width:1024px){
        #contains{
            width:70%;margin:auto;
        }
        #contains2{
            width:70%;margin:auto;
        }
    }
</style>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Request Approval</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                    <li>
                         <a href="">Send Request</a>
                    </li>
                   
                    <li class="active">
                         Class Students (Subject: <?php echo $title; ?>)
                        
                    </li>
                </ol>
            </div>
        </div>
        
       
    
        <div class="row" id="contains">
           
        <div class="modal-body" id="contains2">
           
            <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <input type="text" class="form-control" name="teacher" value="<?php echo $row['firstname'].' '. $row['lastname']; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subjtitle" value="<?php echo $title; ?>" />
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subjcode" value="<?php echo $code; ?>" />
                </div>
                <div class="form-group">
                    <textarea name="request" class="form-control" placeholder="Enter request..."></textarea>
                </div>
                <label>Attach Files:</label> (<i>Request letter and Grade Sheet.</i>)
                <div>
                <input type="file" name="file2" class="form-control" /><br><input type="file" name="file3" class="form-control" /><br>
                
                </div>
        <div class="modal-footer" style="padding-right:0px;">
            <a href="student.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</button></a>
            <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-check"></i> Send Request</button>
            
           
        </div>
        </form>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
    

<!-- /#page-wrapper -->    
<?php include('include/footer.php');


