<?php
    include('include/header.php');
    include('include/sidebar.php');
    $username = isset($_GET['username']) ? $_GET['username'] : $_SESSION['id'];
    
     $user_id = $_SESSION['name'];
  // This will be called once form is submitted
    if (isset($_POST["updatepass"]))
    {
        // Get all input fields
        $current_password = $con->real_escape_string($_POST['current']);
        $new_password = $con->real_escape_string($_POST['new']);
        $confirm_password = $con->real_escape_string($_POST['confirm']);
 
        // Check if current password is correct
        $sql = "SELECT * FROM userdata WHERE username = '" . $username . "'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_object($result);
       
        if (password_verify($current_password, $row->password))
        {   
            // Check if password is same
            if ($new_password == $confirm_password)
            {
                // Change password
                $sql = "UPDATE userdata SET password = '" . password_hash($new_password, PASSWORD_DEFAULT) . "' WHERE username = '" . $username . "'";
                mysqli_query($con, $sql);
                
                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $user_id.' changed his/her password.';
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
                
                $msg = "<div class='alert alert-success'>
                            <strong>Password changed successfully!</strong>
                        </div>";
            }
            else
            {
                $msg = "<div class='alert alert-warning'>
                            <strong>Password entered did not match. Please try again!</strong>
                        </div>";  
            }
             
        }
        else
        {
                $msg = "<div class='alert alert-danger'>
                            <strong>Password entered is not found in the database!</strong>
                        </div>";   
        }
    }
?>
<style>
    @media(max-width:768px){
        #contains{
            width:90%;margin:auto;
        }
        #contains2{
            width:90%;margin:auto;
            -webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
            padding:25px;
            margin-bottom:40px;
            margin-top:30px;
            border:1px solid lightgrey;
            border-radius:20px;
            background-color:white;"

        }
    }
     @media(min-width:1024px){
        #contains{
            width:70%;margin:auto;
        }
        #contains2{
            width:70%;margin:auto;
            -webkit-box-shadow: 0 10px 6px -6px #777;
            -moz-box-shadow: 0 10px 6px -6px #777;
            box-shadow: 0 10px 6px -6px #777;
            padding:25px;
            margin-bottom:40px;
            margin-top:30px;
            border:1px solid lightgrey;
            border-radius:20px;
            background-color:white;"

        }
    }
</style>
<div id="page-wrapper" style="background:url(../image/abstract.png);">
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h3 class="page-header" style="color:gray;">
                    Change Password
                </h3>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row" id="contains">
            <div class="col-lg-12" id="contains2">
                <?php if ($msg != "") echo $msg; ?>
                <div class="alert alert-info">
                    <table>
                        <tr width="100"><b><span style="color:red;">Tip:</span></b><i> Create new password that is <u>unique</u> & <u>easy</u> for you to remember. (minimum of 4 digits/characters.)</i></tr>
                        
                    </table>     
                </div>
                <form action="" method="post">
                    <div class="form-group">
                        <input type="password" name="current" class="form-control" placeholder="Current Password..." required>
                    </div>
                    <div class="form-group">
                        <input type="password" name="new" class="form-control" placeholder="New Password..." required>
                    </div>
                    <div class="form-group">
                        <input type="password" name="confirm" class="form-control" placeholder="Confirm Password..." required>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm" name="updatepass" style="float:right;">Change Password</button><br>
                </form>  
             </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->    
<?php include('include/footer.php');