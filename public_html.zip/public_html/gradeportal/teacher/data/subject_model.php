<?php
    $subject = new Datasubject();
    if(isset($_GET['q'])){
        $function = $_GET['q'];
        $subject->$function();
    }
    class Datasubject {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
        function getsubject($sem,$id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select class.id,class.subject,class.teacher,class.course,class.year, subjectbsa.title, class.sy,class.semester from class INNER JOIN subjectbsa ON class.subject = subjectbsa.code where class.teacher=$id and class.semester='$sem' order by subject asc"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getallsubject($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from class where teacher=$id order by year asc";   
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getsubjectbyid($id){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from class where id=$id";   
            $r = mysqli_query($con,$q);
            return $r;
        }
        
        function getsubjectbycode($code){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from subjectbsa where code='$code'";
            $r = mysqli_query($con,$q);
            $data = mysqli_fetch_array($r);
            return $data;
        }
    }
?>