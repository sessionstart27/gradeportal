<?php
include('../admin/PHPMailer/PHPMailerAutoload.php');
$name = $_GET['name'];											
function Redirect_to($New_Location)
{header("Location:" . $New_Location);
    exit;
}

       
        $message = 'You have received an approval request to access the update grade feature. Kindly check your account on the IIST Grade Portal. Thank you!';

        // Email Functionality

        date_default_timezone_set('Etc/UTC');

        $mail = new PHPMailer();

    	$mail->IsSMTP();
    	$mail->CharSet = 'UTF-8';
    
        $mail->Host       = "mail.smtp2go.com"; // SMTP server example
    	$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
    	$mail->SMTPAuth   = true;                  // enable SMTP authentication
    	$mail->Port       = 2525;                    // set the SMTP port for the GMAIL server
    	$mail->Username   = "iistph"; 	// SMTP account username example
    	$mail->Password   = "Iist6801";        // SMTP account password example



        $mail->setFrom('schoolmail@iistph.com');
        $mail->addAddress('mleovirgil@gmail.com');

        // The subject of the message.
        $mail->Subject = 'Approval request from '.$name;

        $message = '<html><body>';

        $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';

        $message .= "<tr style='background: #eee;'><td><strong>Request Access for:</strong> </td><td>" . strip_tags('Update Grade Feature') . "</td></tr>";

        $message .= "<tr><td><strong>Message:</strong> </td><td>" . strip_tags('You have received an approval request to access the update grade feature of our system. Kindly check your account on the IIST Grade Portal to approve/deny the said request. Thank you and more power!') . "</td></tr>";

        $message .= "</table>";
        $message .= "</body></html>";

        $mail->Body = $message;

        $mail->isHTML(true);
        
        $result = $mail->Send();        // Send!  
        if ($result)
        {
          header('location:index.php');      
        }
        else {
            echo "sending mail failed: " . $mail->ErrorInfo;
        }
        unset($mail);
?>