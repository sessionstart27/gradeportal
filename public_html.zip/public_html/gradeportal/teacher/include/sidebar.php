<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="subject.php"><i class="fa fa-fw fa-bar-chart-o"></i> My Subjects</a>
                    </li>
                    <li>
                        <a href="student.php"><i class="fa fa-fw fa-table"></i> My Students</a>
                    </li>                    
                    <li>
                        <a href="settings.php"><i class= "fa fa-cog fa-spin"></i> Change Password</a>
                    </li> 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>