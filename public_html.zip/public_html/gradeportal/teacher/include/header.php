<?php 
    include('../config.php'); 
    $level = isset($_SESSION['level']) ? $_SESSION['level']: null;
    if($level == null){
        header('location:../index.php');
    }else if($level != 'teacher'){
        header('location:../'.$level.'');
    }
    $id = $_SESSION['id'];
    $name = $_SESSION['name'];
    $q = "select * from teacher where teachid='$id'";
    $r = mysqli_query($con,$q);
    if($row = mysqli_fetch_array($r)){
        $id = $row['id'];   
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">

    <title>Teacher Panel - Grading System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
         
.dropdown-item{
    color:steelblue;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    text-decoration: none;
}
 .dropdown-item:hover {
    color:gray;
    text-decoration: none;
}
        
    .dropdown-menu {
    height: auto;
    max-height: 180px;
    overflow-x: hidden;
}
    .dropdown-menu::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 4px;        
}    
    .dropdown-menu::-webkit-scrollbar-thumb {
    border-radius: 3px;
    background-color: lightgray;
    -webkit-box-shadow: 0 0 1px rgba(255,255,255,.75);        
}
    </style>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <img src="banner.png" height="48px" width="350px" style="margin-left:15px;float:left;" class="logo">
                <img src="banner2.png" class="logo1">
            </div>
            <!-- Top Menu Items -->
          
             
    <ul class="nav navbar-right top-nav">                
                
          <li class="dropdown" style="float:right;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Hi, <?php echo $_SESSION['name']; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="settings.php"><i class= "fa fa-cog fa-spin"></i> Change Password</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
          <li class="nav-item dropdown">
            <a class="nav-link" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Messages
                <?php
                $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                 mysqli_select_db($con,'u588883585_grading');
                $re = mysqli_query($con,"SELECT count(*) from `request` where `teacher_name` = '$name' and (viewed = 'unread' and status != 'Waiting for Approval')") or die( mysqli_error());
                $countr = mysqli_fetch_array($re);
                
                if($countr > 0){
                    
                ?>
                <span class="badge badge-light"><?php echo $countr[0]; ?></span>
              <?php
                }
                    ?>
              </a> 
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="padding:10px; width:300px;">
                <?php
                $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                mysqli_select_db($con,'u588883585_grading');
                $query = mysqli_query($con,"select * from `request` where `teacher_name` = '$name' and status != 'Waiting for Approval' order by `date_approved` DESC LIMIT 0,8");
                

                while($i=mysqli_fetch_array($query)):
                ?>
              <a style ="
                         <?php
                            if($i['viewed'] == 'unread'){
                                echo "font-weight:bold;";
                                echo "font-size:14px;";
                            }else{
                                echo "color:gray";
                            }
                         ?>
                         " class="dropdown-item" href="message.php?id=<?php echo $i['id'] ?>">
                <small><i><?php echo date('F j, Y, g:i a',strtotime($i['date_approved'])) ?></i></small><br/>
                  <?php 
                  
                if($i['status']=='Approved'){
                    echo "VPAA Approved your request for: ".ucfirst($i['subject_title']);
                }else if($i['status']=='Denied'){
                    echo "VPAA Denied your request: ".ucfirst($i['subject_title']);
                }else{
                    echo "Waiting for approval: ".ucfirst($i['subject_title']);
                }
                ?>
                
              <div class="divider"></div>
              <?php endwhile; ?>
              <?php if(mysqli_num_rows($query) < 1): 
                echo"<p style='text-align:center;color:red;'>*** No Available Message ***</p>"; ?>
                <div class="divider"></div>
              <?php endif; ?>
                </a> 
               
            </div>
          </li>
        
    </ul>
            
    