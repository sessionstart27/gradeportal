<?php
    session_start();
    $grade = new Datagrade();

    function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }

    class Datagrade {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
        function getid(){
        //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
            $studid = $_SESSION['id'];
            $r = mysqli_query($q,"select * from student where studid='$studid'");
            $row = mysqli_fetch_array($r);
            $id = $row['id'];
            return $id;
        }
        
        function getsubject($s_year,$sem){
         //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
         $studid = $_SESSION['id'];
         $quer= mysqli_query($q,"select * from student where studid='$studid' and school_year='$s_year'");
         $row = mysqli_fetch_array($quer);
         $myid = $row['id'];  
         
            $query = "select class.id,class.subject,class.teacher,class.course,class.year,studentsubject.studid, studentsubject.prelim, studentsubject.midterm,studentsubject.final,studentsubject.status, class.sy,class.semester from class INNER JOIN studentsubject ON class.id = studentsubject.classid where studentsubject.studid=$myid and (class.semester='$sem' and class.sy='$s_year') order by subject asc"; 
            $r = mysqli_query($q,$query);
            return $r;
        }
        
        function getsubject1(){
         //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
            $id = $this->getid();
            $query = "select * from studentsubject where studid=$id";
            $r = mysqli_query($q,$query);
            $data = array();
            while($row = mysqli_fetch_array($r)){
                $classid = $row['classid'];
                $q2 = "select * from class where id=$classid";   
                $r2 = mysqli_query($q,$q2);  
                $data[] = mysqli_fetch_array($r2);
            }
            return $data;
        }
        
        function getsubjectitle($code){
         //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
            $query = "select * from subjectbsa where code='$code'";
            $r = mysqli_query($q,$query);
            $data = array();
            $data[] = mysqli_fetch_array($r);
            return $data;
        }
        
        function getgrade($s_year,$classid){
         //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
         $studid = $_SESSION['id'];
         $quer= mysqli_query($q,"select * from student where studid='$studid' and school_year='$s_year'");
         $row = mysqli_fetch_array($quer);
         $myid = $row['id'];  
         
        
            $query = "select * from studentsubject where studid='$myid' and classid='$classid'";
            $r = mysqli_query($q,$query);
            if($row = mysqli_fetch_array($r)){
               
                $prelim = $row['prelim'];
                $midterm = $row['midterm'];
                $final = $row['final'];
                $status = $row['status'];
                $total = ($prelim * .30) + ($midterm * .30) + ($final * .40);
                
                $data = array(
                    'eqprelim' => $this->gradeconversion($prelim),
                    'eqmidterm' => $this->gradeconversion($midterm),
                    'eqfinal' => $this->gradeconversion($final),
                    'eqtotal' => $this->gradeconversion($total),
                    'prelim' => round($prelim),
                    'midterm' => round($midterm),
                    'final' => round($final),
                    'total' => round($total),
                    'status' => $status,
                    
                );
            }
            
            return $data;
        }
        function gradeconversion($grade){
           $grade = round($grade);
            if($grade==0){
                 $data = 0;
            }else{
                switch ($grade) {
                     case $grade > 98:
                         $data = number_format(1.00, 2);
                         break;
                     case 98:
                         $data = number_format(1.05, 2);
                         break;
                    case 97:
                         $data = number_format(1.10, 2);
                         break;
                    case 96:
                         $data = number_format(1.15, 2);
                         break;
                    case 95:
                         $data = number_format(1.20, 2);
                         break;
                    case 94:
                         $data = number_format(1.25, 2);
                         break;
                    case 93:
                         $data = number_format(1.30, 2);
                         break;
                    case 92:
                         $data = number_format(1.35, 2);
                         break;
                    case 91:
                         $data = number_format(1.40, 2);
                         break;
                    case 90:
                         $data = number_format(1.50, 2);
                         break;
                    case 89:
                         $data = number_format(1.60, 2);
                         break;
                    case 88:
                         $data = number_format(1.70, 2);
                         break;
                    case 87:
                         $data = number_format(1.80, 2);
                         break;
                    case 86:
                         $data = number_format(1.90, 2);
                         break;
                    case 85:
                         $data = number_format(2.00, 2);
                         break;
                    case 84:
                         $data = number_format(2.10, 2);
                         break;
                   case 83:
                         $data = number_format(2.20, 2);
                         break;
                    case 82:
                         $data = number_format(2.30, 2);
                         break;
                    case 81:
                         $data = number_format(2.40, 2);
                         break;
                    case 80:
                         $data = number_format(2.50, 2);
                         break;
                    case 79:
                         $data = number_format(2.60, 2);
                         break;    
                    case 78:
                         $data = number_format(2.70, 2);
                         break;   
                    case 77:
                         $data = number_format(2.80, 2);
                         break;   
                    case 76:
                         $data = number_format(2.90, 2);
                         break;   
                    case 75:
                         $data = number_format(3.00, 2);
                         break;  

                     default:
                         $data = number_format(5.00, 2);
                }
            }
            return $data;
        }
        function getteacher($teachid){
        //DB connection
         $q = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
         mysqli_select_db($q,'u588883585_grading');
         
            $r = mysqli_query($q,"select * from teacher where id=$teachid");
            $result = mysqli_fetch_array($r);
            $data = $result['firstname'].' '.$result['lastname'];
            return $data;
        }
    }
?>
