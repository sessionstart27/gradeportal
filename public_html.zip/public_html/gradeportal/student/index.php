<?php 
    include('../config.php'); 
    $level = isset($_SESSION['level']) ? $_SESSION['level']: null;
    if($level == null){
        header('location:../index.php');
    }else if($level != 'student'){
        header('location:../'.$level.'');
    }
    
    $user_id = $_SESSION['id'];
  // This will be called once form is submitted
    if (isset($_POST["submit"]))
    {
        // Get all input fields
        $current_password = $con->real_escape_string($_POST['current']);
        $new_password = $con->real_escape_string($_POST['new']);
        $confirm_password = $con->real_escape_string($_POST['confirm']);
 
        // Check if current password is correct
        $sql = "SELECT * FROM userdata WHERE username = '" . $user_id . "'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_object($result);
        $pass = $row->password;
       
        if (password_verify($current_password, $row->password))
        {   
            // Check if password is same
            if ($new_password == $confirm_password)
            {
                // Change password
                $sql = "UPDATE userdata SET password = '" . password_hash($new_password, PASSWORD_DEFAULT) . "' WHERE username = '" . $user_id . "'";
                mysqli_query($con, $sql);
                
                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $user_id.' changed his/her password.';
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
                $msg = "Password Changed!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
            }
            else
            {
                $msg = "Password did not match!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
            }
             
        }
        else
        {
                $msg = "Password is not found in the database!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
        }
    }
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">

    <title>Online Grading System</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/font-awesome.min.css" />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="mystyle.css" />
    <style>
    .disclaimer{
        text-align:center;
        color:gray;
    }
@media (max-width: 765px) {
    .disclaimer{
        text-align:justify;
        color:gray;
}
        
    </style>

  </head>

  <body>

     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation"  style="padding:2px;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <img src="banner.png" height="48px" width="350px" style="margin-left:15px;float:left;" class="logo">
          <img src="banner2.png" class="logo1">
          
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <div class="navbar-form navbar-right">
                <label class="text-primary">
                    Hi, <?php echo $_SESSION['name']; ?>&nbsp;&nbsp;
                </label>
                
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#studchangepass">Change Password</button>
                <a href="../logout.php"><button type="button" class="btn btn-success" name="submit">Logout</button></a>
            </div>
        </div><!--/.navbar-collapse -->
      </div>
    </nav>

<?php 
    include('grade.php');
    $firstsem = $grade->getsubject('1st Semester');    
    $secondsem = $grade->getsubject('2nd Semester');    
    
?>
    <div class="container" style="margin-top:60px;">
      <!-- Example row of columns -->
    <div class="row">
        <div class="col-lg-12">
            <h2 class="text-center">Report of Grades</h2>
            <?php 
            $id= $_SESSION['id'];
            $query = mysqli_query($con,"select * from student where studid='$id'");
            $r = mysqli_fetch_array($query);
            $sy = $r['school_year'];    
            ?>
            <h4 class="text-center">School Year: <?php echo $sy; ?></h4>
            
            <?php if(isset($_GET['msg'])): ?>
                    <?php
                        $r = $_GET['msg'];
                        if($r=='Password Changed!'){
                            $class='success';   
                            $m='Password Changed!';
                          
                        }else if($r=='Password did not match!'){
                            $class='danger';   
                            $m='Password did not match!';
                          
                        }else{
                            $class='danger';   
                            $m='Password is not found in the database!';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong><?php echo $m; ?>!</strong>    
                    </div>
                <?php endif; ?>
                   
           
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">First Semester</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Second Semester</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert alert-info">
                                    <th>Subject Code</th>
                                    <th>Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Finals</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th>Remarks</th>
                                    <th>Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($firstsem)): ?>
                            <tr>
                               
                                <td><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                    if($mygrade['status'] == 'Enrolled'){
                                if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                    $remarks = 'PASSED';
                                    $class = 'text-success';
                                }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                    $remarks = 'FAILED';
                                    $class = 'text-danger';  
                                }else{
                                    $remarks = 'No Submitted Grades';
                                    $class = 'text-danger';  
                                }
                            }else{
                                    $remarks = 'OFFICIALLY DROPPED';
                                    $class = 'text-danger';  
                                }
                                ?>
                                <td class="<?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                                </tbody>
                            </table>
                            </div>
                            <h4 class="text-center text-danger">*** DISCLAIMER: ***</h4>
                            <h6 class="disclaimer">*** The information provided by IIST Grade Portal is for general informational purposes only. Any use of information for personal interest neither in a hard copy nor digital format is unofficial. ***</h6>
                        </div>
                  
                    <div class="tab-pane" id="data2">
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped">
                                 <thead>
                                    <tr class="alert alert-info">
                                    <th>Subject Code</th>
                                    <th>Subject Title</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Finals</th>
                                    <th class="text-center">Final Grade</th>
                                    <th class="text-center">Equivalent</th>
                                    <th>Remarks</th>
                                    <th>Subject Teacher</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($secondsem)): ?>
                            <tr>
                                <td><?php echo $row['subject']; ?></td>
                                <?php $title = $grade->getsubjectitle($row['subject']);?>
                                <td><?php echo $title[0]['title']; ?></td>
                                <?php $mygrade = $grade->getgrade($row['id']); ?>
                                <td class="text-center"><?php echo $mygrade['prelim']; ?></td>
                                <td class="text-center"><?php echo $mygrade['midterm']; ?></td>
                                <td class="text-center"><?php echo $mygrade['final']; ?></td>
                                <td class="text-center"><?php echo $mygrade['total']; ?></td>
                                <td class="text-center"><?php echo $mygrade['eqtotal']; ?></td>
                                <?php
                                $var = 0;
                                if($mygrade['status'] == 'Enrolled'){
                                if($mygrade['eqtotal']>0.0 && $mygrade['eqtotal']<=3.0){
                                    $remarks = 'PASSED';
                                    $class = 'text-success';
                                }else if($mygrade['eqtotal']>3.0 && $mygrade['eqtotal']<=5.0){
                                    $remarks = 'FAILED';
                                    $class = 'text-danger';  
                                }else{
                                    $remarks = 'No Submitted Grades';
                                    $class = 'text-danger';  
                                }
                            }else{
                                    $remarks = 'OFFICIALLY DROPPED';
                                    $class = 'text-danger';  
                                }
                                
                                ?>
                                <td class="<?php echo $class;?>"><?php echo $remarks;?></td>
                                <?php $teacher = $grade->getteacher($row['teacher']); ?>
                                <td><?php echo $teacher; ?></td>
                               <!-- <td class="text-center"><?php echo $title[0]['unit']; ?></td>-->
                            </tr>
                        <?php endwhile; ?>
                                </tbody>
                            </table>
                            </div>
                            <h4 class="text-center text-danger">*** DISCLAIMER: ***</h4>
                            <h6 class="disclaimer">*** The information provided by IIST Grade Portal is for general informational purposes only. Any use of information for personal interest neither in a hard copy nor digital format is unofficial. ***</h6>
                        </div>
                    </div>
                </div> 
             
    <div>
        
        
<!-- add modal for change Password -->
<div class="modal fade" id="studchangepass" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Change Password</h3>
        </div>
        <div class="modal-body">
            <div class="alert alert-info">
                    <table>
                        <tr width="100"><b><span style="color:red;">Tip:</span></b><i> <span style="font-size:11px;">Create new password that is <u>unique</u> & <u>easy</u> for you to remember. (minimum of 4 digits/characters.)</span></i></tr>
                        
                    </table>     
                </div>
            <form action="index.php" method="post">
                <div class="form-group">
                    <input type="password" class="form-control" name="current" placeholder="Current Password" required />
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="new" placeholder="New Password" required/>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="confirm" placeholder="Confirm Password" required />
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="submit"><i class="fa fa-plus"></i> Change</button>
            </form>
        </div>
    </div>
  </div>
</div>
        

      <hr>

      <footer>
        <p style="text-align:center;">&copy; Imus Institute of Science & Technology 2021</p>
      </footer>
        </div></div>    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>
