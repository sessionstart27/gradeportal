<?php
    $approval = new Dataapproval();

    function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
  if(isset($_GET['q'])){
        $approval->$_GET['q']();
    }
    class Dataapproval {
        
        function __construct(){
            if(!isset($_SESSION['id'])){
                header('location:../../');   
            }
        }
        
        function getid(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $studid = $_SESSION['id'];
            $r = mysqli_query($con,"select * from student where studid='$studid'");
            $row = mysqli_fetch_array($r);
            $id = $row['id'];
            return $id;
        }
        
        function getrequest(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
            $q = "select * from request where status='Waiting for Approval'"; 
            $r = mysqli_query($con,$q);
            return $r;
        }
        function getsubject1(){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            $id = $this->getid();
            $q = "select * from studentsubject where studid=$id";
            $r = mysqli_query($con,$q);
            $data = array();
            while($row = mysqli_fetch_array($r)){
                $classid = $row['classid'];
                $q2 = "select * from class where id=$classid";   
                $r2 = mysqli_query($con,$q2);  
                $data[] = mysqli_fetch_array($r2);
            }
            return $data;
        }
        
        function getsubjectitle($code){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            $q = "select * from subjectbsa where code='$code'";
            $r = mysqli_query($con,$q);
            $data = array();
            $data[] = mysqli_fetch_array($r);
            return $data;
        }
        
       
        function getteacher($teachid){
            $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            $r = mysqli_query($con,"select * from teacher where id=$teachid");
            $result = mysqli_fetch_array($r);
            $data = $result['firstname'].' '.$result['lastname'];
            return $data;
        }
        
    }
?>