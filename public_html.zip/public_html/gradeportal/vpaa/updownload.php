<?php
$con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');
// Uploads files
 if(isset($_POST["submit"]))
    {   // if submit button on the form is clicked
    
            $file2 = $_FILES['file2'];
            // name of the uploaded file
            $fileName = $_FILES['file2']['name'];
            // the physical file on a temporary uploads directory on the server
            $fileTmpName = $_FILES['file2']['tmp_name'];
            $fileSize = $_FILES['file2']['size'];
            $fileError = $_FILES['file2']['error'];
            $fileType = $_FILES['file2']['type'];
            // get the file extension
            $fileExt = explode('.',$fileName);
            $fileActualExt = strtolower(end($fileExt));
     
     
            $file3 = $_FILES['file3'];
            // name of the uploaded file
            $fileName3 = $_FILES['file3']['name'];
            // the physical file on a temporary uploads directory on the server
            $fileTmpName3 = $_FILES['file3']['tmp_name'];
            $fileSize3 = $_FILES['file3']['size'];
            $fileError3 = $_FILES['file3']['error'];
            $fileType3 = $_FILES['file3']['type'];
            // get the file extension
            $fileExt3 = explode('.',$fileName3);
            $fileActualExt3 = strtolower(end($fileExt3));

            $allowed = array('pdf','docx','doc','txt','xlsx');
            if(in_array($fileActualExt, $allowed)){
              if(in_array($fileActualExt3, $allowed)){
                if($fileError === 0 && $fileError3 === 0){
                    if($fileSize < 5000000 && $fileSize3 < 5000000){// file shouldn't be larger than 5Megabyte
                        #use --uniqid('', true)-- for unique idcode if needed instead of random
                        #file name with a random number so that similar dont get replaced
                        $fileNameNew = rand(1000,10000)."_".$_FILES['file2']['name'];
                        $fileNameNew3 = rand(1000,10000)."_".$_FILES['file3']['name'];
                        // destination of the file on the server
                        $fileDestination = '../request/'.$fileNameNew;
                        $fileDestination3 = '../request/'.$fileNameNew3;
                        // move the uploaded (temporary) file to the specified destination
                        move_uploaded_file($fileTmpName, $fileDestination);    
                        move_uploaded_file($fileTmpName3, $fileDestination3);
                        
                        
                        date_default_timezone_set('Asia/Manila');
                        $date = date('Y-m-d H:i:s');
                        $teacher = $_POST['teacher'];    
                            
                        $sql="INSERT INTO `request`(`teacher_name`, `subject_title`, `subject_code`, `request`, `document`,`document2`, `status`,`viewed`,`admin_viewed`,`date_reg`,`date_approved`)VALUES ('{$_POST["teacher"]}','{$_POST["subjtitle"]}','{$_POST["subjcode"]}','{$_POST["request"]}','$fileNameNew','$fileNameNew3','Waiting for Approval','unread','unread','$date',' ')";
                           mysqli_query($con,$sql);
                        
                        ?>
                        <script type="text/javascript">
                        alert("Approval Request Sent!");
                        window.location="mailer.php?name=<?php echo $teacher; ?>"
                        </script>
                        <?php
                
                    }else{
                        ?>
                        <script type="text/javascript">
                        alert("Your document file is too big!");
                        window.location="index.php"
                        </script>
                        <?php
                                   
                        }

                }else{
                        ?>
                        <script type="text/javascript">
                        alert("There was an error uploading your document file!");
                        window.location="index.php"
                        </script>
                        <?php 
                                    
                        }

                }else{
                        
                        ?>
                        <script type="text/javascript">
                        alert("Please upload 2nd document file of this type! (.txt, .docx, .doc, .pdf)");
                        window.location="index.php"
                        </script>
                        <?php 
                        }      
                 }else{
                        
                        ?>
                        <script type="text/javascript">
                        alert("Please upload 1st document file of this type! (.txt, .docx, .doc, .pdf)");
                        window.location="index.php"
                        </script>
                        <?php 
                        }    
            
                    
}   

// Downloads file1
if (isset($_GET['file_id'])) {
    $id = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM request WHERE id=$id";
    $result = mysqli_query($con,$sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = '../request/' . $file['document'];

    if (file_exists($filepath)) {
         header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('../request/' . $file['document']));
        
        ob_clean();
        flush();
        readfile('../request/' . $file['document']);
        exit;

    }
    
}

// Downloads file2
if (isset($_GET['file_id2'])) {
    $id2 = $_GET['file_id2'];

    // fetch file to download from database
    
    $sql = "SELECT * FROM request WHERE id=$id2";
    $result = mysqli_query($con,$sql);

    $file = mysqli_fetch_assoc($result);
    $filepath2 = '../request/' . $file['document2'];

    if (file_exists($filepath2)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath2));
        header('Expires: 0');
        set_time_limit(0);
        output_buffering(0);
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('../request/' . $file['document2']));
        
        ob_clean();
        flush();
        readfile('../request/' . $file['document2']);
        exit;

    }
}

