<?php
/*approve request vpaa*/
if(isset($_POST["approveDeny"]))
{
        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
            mysqli_select_db($con,'u588883585_grading');  
            $id = $_GET['id'];
            $teacher = $_GET['name'];
            $subject = $_GET['subject'];
            $status = $_GET['status'];
            date_default_timezone_set('Asia/Manila');
            $date = date('Y-m-d H:i:s');
            
            $q = "UPDATE `request` SET `status`='$status',`date_approved`='$date' WHERE `id`='$id'";
            mysqli_query($con,$q);
            date_default_timezone_set('Asia/Manila');
            $date = date('m-d-Y h:i:s A'); 
            $act = "VPAA  $status teacher $teacher request on $subject subject .";
            $log = "insert into log(`date`, `activity`) values('$date','$act')";
            mysqli_query($con, $log);
            header('location:../index.php?id='.$id.'&status='.$status.'');   
}
            
            
            
?>