<?php 
    include('../config.php'); 
    $level = isset($_SESSION['level']) ? $_SESSION['level']: null;
    if($level == null){
        header('location:../index.php');
    }else if($level != 'vpaa'){
        header('location:../'.$level.'');
    }
    
     $user_id = $_SESSION['id'];
  // This will be called once form is submitted
    if (isset($_POST["changepass"]))
    {
        // Get all input fields
        $current_password = $con->real_escape_string($_POST['current']);
        $new_password = $con->real_escape_string($_POST['new']);
        $confirm_password = $con->real_escape_string($_POST['confirm']);
 
        // Check if current password is correct
        $sql = "SELECT * FROM userdata WHERE username = '" . $user_id . "'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_object($result);
        $pass = $row->password;
       
        if (password_verify($current_password, $row->password))
        {   
            // Check if password is same
            if ($new_password == $confirm_password)
            {
                // Change password
                $sql = "UPDATE userdata SET password = '" . password_hash($new_password, PASSWORD_DEFAULT) . "' WHERE username = '" . $user_id . "'";
                mysqli_query($con, $sql);
                
                date_default_timezone_set('Asia/Manila');
                $date = date('m-d-Y h:i:s A'); 
                $act = $user_id.'(VPAA) changed his/her password.';
                $log = "insert into log(`date`, `activity`) values('$date','$act')";
                mysqli_query($con, $log);
                $msg = "Password Changed!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
            }
            else
            {
                $msg = "Password did not match!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
            }
             
        }
        else
        {
                $msg = "Password is not found in the database!";
                header('location:index.php?msg='.$msg.'&username='.$user_id.'');   
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="../image/ii.png" sizes="16x16" type="images/png">

    <title>Online Grading System</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/font-awesome.min.css" />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="mystyle.css" />
    
<style>
    @media(max-width:768px){
        #audit1,table th, table td, #btn{
            font-size:11px;
        }
        #audit2{
            font-size:6px;
        }
    }
    table{
        border: .5px solid lightgray;
        border-collapse: collapse;
    }
</style>
  </head>

  <body>
       <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation"  style="padding:2px;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <img src="banner.png" height="48px" width="350px" style="margin-left:15px;float:left;" class="logo">
          <img src="banner2.png" class="logo1">
          
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <div class="navbar-form navbar-right">
                <label class="text-primary">
                    Hi, <?php echo $_SESSION['name']; ?>&nbsp;&nbsp;
                </label>
                
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#changepass">Change Password</button>
                <a href="../logout.php"><button type="button" class="btn btn-success" name="submit">Logout</button></a>
            </div>
        </div><!--/.navbar-collapse -->
      </div>
    </nav>
   

<?php
    include('updownload.php');
    include('approval.php');
    $request = $approval->getrequest();
?>
    <div class="container" style="margin-top:60px;">
      <!-- Example row of columns -->
    <div class="row">
        <div class="col-lg-12">
            <h2 class="text-center">Approval Page</h2>
            <?php if(isset($_GET['msg'])): ?>
                    <?php
                        $r = $_GET['msg'];
                        if($r=='Password Changed!'){
                            $class='success';   
                            $m='Password Changed Successfully!';
                          
                        }else if($r=='Password did not match!'){
                            $class='danger';   
                            $m='Password do not match. Please try again!';
                          
                        }else{
                            $class='danger';   
                            $m='Password is not found in the database!';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong><?php echo $m; ?>!</strong>    
                    </div>
                <?php endif; ?>
            <?php if(isset($_GET['status'])): ?>
                    <?php
                        $r = $_GET['status'];
                        if($r=='Approved'){
                            $class='success';   
                          
                        }else if($r=='Denied'){
                            $class='danger';   
                        
                        }else{
                            $class='hide';
                        }
                    ?>
                     
                    <div class="alert alert-<?php echo $class?> <?php echo $class; ?>">
                        <strong> Teacher Request <?php echo $r; ?>!</strong>    
                    </div>
                <?php endif; ?>
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active"><a href="#data1" role="tab" data-toggle="tab">Approval Request</a></li>
                    <li><a href="#data2" role="tab" data-toggle="tab">Activity History</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="data1">
                        <br />
                        <div class="table-responsive" style="overflow-x:auto;">
                            <table class="table table-striped">
                                <thead>
                                    <tr class="alert alert-info">
                                    <th>Teacher's Name</th>
                                    <th>Subject Code</th>
                                    <th>Subject Title</th>
                                    <th>Request</th>
                                    <th class="text-center" colspan="2">File Attachments</th>
                                    <th>Status</th>
                                    <th>Date Requested</th>
                                    <th class="text-center" colspan="2">Action</th>
                                   <!-- <th class="text-center">Units</th>-->
                                </tr>
                                </thead>
                                <tbody>
                           <?php while($row = mysqli_fetch_array($request)): ?>
                            <tr>
                                <td><?php echo $row['teacher_name']; ?></td>
                                <td><?php echo $row['subject_code']; ?></td>
                                <td><?php echo $row['subject_title']; ?></td>
                                <td><?php echo $row['request']; ?></td>
                                <td><a href='http://gradeportal.iistph.com/request/<?php echo $row['document'];?>' target='__blank' class='dwnload'><?php echo $row['document'];?></a></td>
                                <td><a href='http://gradeportal.iistph.com/request/<?php echo $row['document2'];?>' target='__blank' class='dwnload'><?php echo $row['document2'];?></a></td>
                                <td><?php echo $row['status']; ?></td>
                                <td><?php echo $row['date_reg']; ?></td>
                                <td class="text-center">
                                    <form action="approveDeny.php?status=Approved&id=<?php echo $row['id']?>&name=<?php echo $row['teacher_name']; ?>&subject=<?php echo $row['subject_title']; ?>" method="post">
                                           <button type="submit" title="Click to Approve Request" name="approveDeny"  class="btn btn-success approv" id="btn">Approve</button>
                                        </form>
                                     
                                </td>
                                <td class="text-center">
                                    <form action="approveDeny.php?status=Denied&id=<?php echo $row['id']?>&name=<?php echo $row['teacher_name']; ?>&subject=<?php echo $row['subject_title']; ?>" method="post">
                                           <button type="submit" title="Click to Deny Request" name="approveDeny"  class="btn btn-danger deny" id="btn">Deny</button>
                                        </form>
                                         &nbsp;
                                </td>
                            </tr>
                        <?php endwhile; ?>
                         <?php if(mysqli_num_rows($request) < 1): ?>
                                        <tr><td colspan="8" class="text-center text-danger" style="margin:0 auto;"><strong>***</strong> No available request to approve.  <strong>***</strong></td></tr>
                        <?php endif;?>
                                </tbody>
                            </table>
                            
                            </div>
                           
                        </div>
                  
                    <div class="tab-pane" id="data2">
                        <br />
                       <div class="row">           
                         <div class="col-lg-12">
                            <div class="panel panel-green" style=" border-color: #5cb85c;
                                    color: #31708f;
                                    background-color: #d9edf7;
                                    border-color: #bce8f1;">
                                <div class="panel-heading" style="
                                    color: #31708f;
                                    border-color: #bce8f1;padding: 10px 15px;
                                    border-bottom: 1px solid transparent;
                                    border-top-right-radius: 3px;
                                    border-top-left-radius: 3px;">
                                    <h3 class="panel-title"><i class="fa fa-clock-o fa-fw"></i> Latest Account Activity</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="list-group">
                                        <?php 
                                        $con = mysqli_connect('localhost','u588883585_iistph','Iist6801') or die(mysqli_error());
                                                mysqli_select_db($con,'u588883585_grading');
                                        $r = mysqli_query($con,"select * from log where activity like 'VPAA%' order by id desc limit 0,100");?>

                                        <?php while($row = mysqli_fetch_array($r)): ?>       
                                        <a href="#" class="list-group-item" style="color:gray;">
                                            <span class="badge" id="audit2"><?php echo $row['date']?></span>
                                            <i class="fa fa-fw fa-tasks" style="color:#46b8da;"></i> <span id="audit1"><?php echo $row['activity']?></span>
                                        </a>                                   
                                        <?php endwhile; ?>
                                        <?php if(mysqli_num_rows($r) < 1): ?>
                                        <tr><td colspan="8" class="text-center text-danger" style="margin:0 auto;"><strong>***</strong> No available request to approve. <strong>***</strong></td></tr>
                                        <?php endif;?>
                                    </div>        
                                </div>
                            </div>
                        </div>    
                        </div> 
                        </div>
                    </div>
                </div> 
    </div>
        
<!-- add modal for change Password -->
<div class="modal fade" id="changepass" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Change Password</h3>
        </div>
        <div class="modal-body">
            <div class="alert alert-info">
                    <table>
                        <tr width="100"><b><span style="color:red;">Tip:</span></b><i> <span style="font-size:11px;">Create new password that is <u>unique</u> & <u>easy</u> for you to remember. (minimum of 4 digits/characters.)</span></i></tr>
                        
                    </table>     
                </div>
            <form action="index.php" method="post">
                <div class="form-group">
                    <input type="password" class="form-control" name="current" placeholder="Current Password" required/>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="new" placeholder="New Password" required/>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="confirm" placeholder="Confirm Password" required/>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" name="changepass"><i class="fa fa-plus"></i> Change</button>
            </form>
        </div>
    </div>
  </div>
</div>
        

      <hr>

      <footer>
        <p style="text-align:center;">&copy; Imus Institute of Science & Technology 2021</p>
      </footer>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/jquery.js"></script>
    <script src="../js/myscript.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>
