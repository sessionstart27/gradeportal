<?php
	$msg = "";

	if (isset($_POST['submit'])) {
		$con = new mysqli('localhost', 'u588883585_iistph', 'Iist6801', 'u588883585_grading');

		$username = $con->real_escape_string($_POST['username']);
		$fname = $con->real_escape_string($_POST['firstname']);
		$lname = $con->real_escape_string($_POST['lastname']);
		$level = $con->real_escape_string($_POST['level']);
		$password = $con->real_escape_string($_POST['password']);
		$cPassword = $con->real_escape_string($_POST['cPassword']);

		if ($password != $cPassword)
			$msg = "Please Check Your Passwords!";
		else {
			$hash = password_hash($password, PASSWORD_BCRYPT);
			$con->query("INSERT INTO userdata (username,password,firstname,lastname,level) VALUES ('$username', '$hash', '$fname', '$lname', '$level')");
			$msg = "You have been registered!";
		}
	}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP Password Hashing - Register</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
	<div class="container" style="margin-top: 100px;">
		<div class="row justify-content-center">
			<div class="col-md-6 col-md-offset-3" align="center">
				<img src="image/ii.png"><br><br>

				<?php if ($msg != "") echo $msg . "<br><br>"; ?>

				<form method="post" action="register.php">
					<input class="form-control" minlength="3" name="username" placeholder="User ID..."><br>
					<input class="form-control" name="firstname" type="text" placeholder="Firstname..."><br>
					<input class="form-control" name="lastname" type="text" placeholder="Lastname..."><br>
					<input class="form-control" name="level" type="text" placeholder="Level..."><br>
					<input class="form-control" minlength="4" name="password" type="password" placeholder="Password..."><br>
					<input class="form-control" minlength="4" name="cPassword" type="password" placeholder="Confirm Password..."><br>
					<input class="btn btn-primary" name="submit" type="submit" value="Register..."><br>
				</form>

			</div>
		</div>
	</div>
</body>
</html>