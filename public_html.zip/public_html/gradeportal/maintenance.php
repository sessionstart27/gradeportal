<?php    
    include('config.php');
    
    $query = mysqli_query($con, "select * from maintenance");
    $row = mysqli_fetch_array($query);
    $access = $row['access'];
    if($access == 'on'){
       header('location:index.php'); 
    }else{

    if(isset($_POST['submit'])){
        $con = new mysqli('localhost', 'u588883585_iistph', 'Iist6801', 'u588883585_grading');

		$user = $con->real_escape_string($_POST['user']);
		$password = $con->real_escape_string($_POST['pass']);
        
        $sql = $con->query("SELECT * FROM userdata WHERE username='$user' and level='admin'");
        
        if ($sql->num_rows > 0) {
		    $data = $sql->fetch_array();
		    if (password_verify($password, $data['password'])) {
		        $msg = "You have been logged IN!";
                $_SESSION['level'] = $data['level'];
                $_SESSION['id'] = $data['username'];
                $_SESSION['name'] = $data['firstname'].' '.$data['lastname'];
                header('location:'.$data['level'].'');
            } else
			    echo "<script>alert('Incorrect Password!'); window.location='index.php'</script>";
        } else
            echo "<script>alert('Access Denied!'); window.location='index.php'</script>";
	}

    if(isset($_SESSION['level'])){
        header('location:'.$_SESSION['level'].'');   
    }
   
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="image/ii.png" sizes="16x16" type="images/png">

    <title>IIST Grade Portal</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <!-- Custom styles for this template -->
<style>

    .events-sect{
	max-width:100%; 
	padding:40px;
	background-color:#ffffff;
	color:#1d1d1d;
    background-image: url("image/abstract.png");
	width:100%;height:100%;
    background-repeat: no-repeat;
    background-size: cover;
}
    .global-container{
	max-width:80%;
	margin:0 auto;
	height:auto;
}
    .event-wrapper{
    max-width:100%;
    display:flex;
}
    .event-wrapper::-webkit-scrollbar {
    cursor: pointer;
    height: 8px;
    background-color: #cccc;
    border-radius: 100px;
    /* border: 1px solid #bbbb; */
}
    .events-content img{
	width:300px;
}
    /* scroll bar for the slide panels*/
    ::-webkit-scrollbar-thumb {
    background-color: whitesmoke;
    border-radius: 10px;
    border: 1px solid lightgray;
}

    /* Track */
::-webkit-scrollbar-track {
  border-radius: 10px;
}

* {
    box-sizing: border-box;
}
.events-content{
	flex: 0 0 auto;
    cursor: grab; 
	box-shadow:2px 1px 10px 1px #aaaaaa;
	width:300px;
    margin:20px;
    box-sizing:border;
    color:#1d1d1d;
}
.txt-cont {
    background-color: #ffffff;
}
    element.style {
    max-width: 100%;
    display: inline-block;
    padding: 20px;
    text-align: center;
    margin: 0 auto;
}
@media (max-width:424px){
    .global-container{
	max-width:100%;
	height:auto;
}   .events-sect{
	max-width:100%; 
	padding:20px;

}}
@media (max-width:425px){
    footer .homefooter p{
    font-size:5px;}}
    
@media only screen and (max-width:768px){
        h1{
           text-align:center;color:#1d1d1d;font-size:16px;
        }
       
    }
     @media only screen and (min-width:1024px){
        h1{
          text-align:center;padding:40px;color:#1d1d1d;font-size:30px;
        }
       
    }

@media(max-width:768px){
    .flex-container {
            display: inline-block;
            width:75%;
            margin-left:13%;
            margin-right:12%;
            font-size:14px;
            
        }
         .flex-child:first-child {
            margin-bottom:20px;
            margin-top:20px;
}
 .flex-child:first-child {
            width:100%;
            padding-left:0px;
            padding-right:0px;
}
}
@media(min-width:1024px){
     .flex-container {
            display: flex;
            width:75%;
            margin-left:13%;
            margin-right:12%;
        }
        .flex-child:first-child {
    margin-right: 20px;
    margin-top:20px;
}
}
.flex-child {
    flex: 1;
    padding:20px;
    
}  


 
@media(max-width:425px){
    footer .homefooter p{
    font-size:5px;}
    .bgbanner{
        display:none;
    }
    .global-container{
	max-width:100%;
	height:auto;
}   .events-sect{
	max-width:100%; 
	padding:20px;

}
.smbanner{
    padding:30px;margin-bottom:-160px;margin-top: 50px;color:inherit;background-image: url(image/mtenance.png);
    width: 100%;height:500px;
    background-repeat: no-repeat;
    background-size: contain;

    }
}
    
@media(min-width:768px){
    .smbanner{
            display:none;
        }
     .bgbanner{
    padding:140px;margin-bottom:0px;margin-top:50px;background-image: url(image/bigmtnance.png);
    width:100%;height:100%;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    }
    }
      </style>
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button><img src="image/banner.png" height="49px" width="350px" style="margin-left:15px;float:left;" class="logo">
            <img src="image/banner2.png" class="logo1">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
        <div id="navbar" class="navbar-form navbar-right">
          <button type="button" id="adjust-blue" class="btn btn-success" data-toggle="modal" data-target="#adminpass">Admin Access</button>
        </div><!--/.navbar-collapse -->
      </div>
      </div>
    </nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="bgbanner">
      <div class="container">
       
      </div>
    </div>
      <div class="smbanner">
      <div class="container">
        
      </div>
    </div>
    <section class="events-sect" id="eventsect">
			<div class="global-container" id="adjusth1">
				<h1><b>Learn More About the IIST Grade Portal </b></h1>
				<div class="event-wrapper" style="align-items:center;overflow-x:scroll;" >
					<br>
					<div class="events-content">
						<img src="image/2.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>IIST Grade Portal</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">An online grading system that will help students, teachers and the registrar in managing student grades and information. Users login credentials will be provided upon request in the registrar's office.<br><a href="event1.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
					
						<div class="events-content">
						<img src="image/3.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Teacher Access</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">Teachers will be able to upload and manage student grades by logging in to their account. Teachers can also view their subject load and monitor students performance online using the grade portal.<br><a href="event3.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
					
						<div class="events-content">
						<img src="image/4.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Student Access</b></article>
							<article style="text-align:justify;text-indent:20px;display:inline-block;max-width:100%;">IIST students may now access their grades without doing the hassle of going to school to inquire. With IIST Grade Portal they can login to their account and keep track on their grades in any devices online. <a href="event4.html" style="text-decoration: none;color: blue"></a></article>
						</div>
					</div>
										<div class="events-content">
						<img src="image/5.png"width="100%"height="200px">
						<br>
					
						<div class="article txt-cont" style="max-width:100%;display:inline-block;padding:20px;text-align:center;margin:0 auto;">
							<article style="text-align:center;font-size:20px;padding:10px;display:inline-block;max-width:100%;"><b>Contacts</b></article>
							<article style="text-align:left;display:inline-block;max-width:100%;"><ul style="list-style-type:none;">
							    <p><b>E-mail:</b>  iistedu2020@gmail.com</p>
                                <p style="text-indent:50px;">  schoolmail@iistph.com</p>
                                <p><b>Phone:</b>  (046)471 - 2624</p>
                                <p><b>Address:</b> Nueño Ave. Imus, Cavite</p><a href="event2.html" style="text-decoration: none;color: blue"></a> </article>
						</div>
					</div>
					
				</div>
			</div>
		</section>

<!-- add modal for change Password -->
<div class="modal fade" id="adminpass" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Admin Access</h3>
        </div>
        <div class="modal-body">
            <div class="alert alert-info">
                    <table>
                        <tr width="100"><b><span style="color:red;">Note:</span></b><i> <span style="font-size:11px;">This is only for administrative access. If you are a regular user, please bear with us and we will be right back. Thank you!</span></i></tr>
                        
                    </table>     
                </div>
            <form action="maintenance.php" method="post">
                <div class="form-group">
                <?php if(isset($_GET['login'])): ?>
                    <label class="text-danger">Invalid User ID/Password</label>&nbsp;
                <?php endif; ?>
            </div>
            <div class="form-group">
              <input type="text" placeholder="User ID" class="form-control" name="user" autocomplete="off">
            </div>
            <div class="form-group">
              <input type="password" placeholder="Password" class="form-control" name="pass">
            </div>
            
         
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success" name="submit">Sign in</button>
            </form>
        </div>
    </div>
  </div>
</div>
    

    <footer style="background-color:#09447f;">
    <div  style="background-color:#09447f;padding:3px;">
    <div class="flex-container">

      <div class="flex-child magenta" style="padding:0px;">
         <h4 style="color:#aaaaaa;text-align:center;font-weight:bold;font-family:calibri;color:lightgray;">For more info, please contact us at :</h4>
                <p style="color:lightgray;text-align:center;"><b>Contact No.:</b>  (046)471 - 2624</p>
				<p style="color:lightgray;text-align:center;"><b>E-mail:</b>  schoolmail@iistph.com</p>
                <p style="color:lightgray;text-align:center;"><b>Address:</b> Nueño Ave. Imus City, Cavite</p>
         <p class="center" style="color:lightgray;padding-top:10px;">Designed & Developed By: JPCS IIST - Chapter 2021</p>    
      </div>
     
      
      <div class="flex-child green">
        
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3864.013141323466!2d120.93576431435451!3d14.426405989913551!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d2f43a2ba711%3A0xb48c61cb289a189!2sImus%20Institute%20Of%20Science%20And%20Technology!5e0!3m2!1sen!2sph!4v1569644440955!5m2!1sen!2sph"  height="200" frameborder="1" style="width:100%;border:0;" allowfullscreen=""></iframe>

      </div>
        </div>
        </div>
    <div  style="background-color:#001177;padding:3px;">
        <p class="center" style="color:white;padding-top:10px;font-weight:bold;">&copy; Imus Institute of Science and Technology 2021</p>
    </div>
      </footer>
    <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
